(function () {
	  'use strict';

	  var BL = window.BL = window.BL || {};
	  BL.Net = BL.Net || {};
	  BL.PolicyNetwork = BL.PolicyNetwork || {};

	  // ============================================================================
	  // Runtime status (for Installer → Network → Status)
	  // ============================================================================
	  var __netStatus = {
	    interceptors: {
	      fetch: false,
	      xhr: false,
	      ws: false,
	      eventsource: false,
	      beacon: false,
	      iframe_src: false,
	      img_src: false,
	      script_src: false,
	      link_href: false,
	      open: false,
	      location: false
	    },
	    lastBlocked: null
	  };

	  function setInterceptorActive(id, on) {
	    try { __netStatus.interceptors[String(id || '')] = !!on; } catch (_) { }
	  }

	  function snapshotInterceptors() {
	    var out = {};
	    try {
	      var keys = Object.keys(__netStatus.interceptors || {});
	      for (var i = 0; i < keys.length; i++) {
	        var k = keys[i];
	        out[k] = !!__netStatus.interceptors[k];
	      }
	    } catch (_) { }
	    return out;
	  }

	  function snapshotLastBlocked() {
	    try {
	      if (!__netStatus.lastBlocked) return null;
	      var lb = __netStatus.lastBlocked;
	      return {
	        url: String(lb.url || ''),
	        channel: String(lb.channel || ''),
	        ruleId: String(lb.ruleId || ''),
	        ruleLabel: String(lb.ruleLabel || ''),
	        ts: Number(lb.ts || 0)
	      };
	    } catch (_) {
	      return null;
	    }
	  }

	  BL.PolicyNetwork.getStatus = BL.PolicyNetwork.getStatus || function () {
	    return { interceptors: snapshotInterceptors(), lastBlocked: snapshotLastBlocked() };
	  };

	  function logCall(log, method, source, message, extra) {
	    try {
	      if (!log) return;
	      var fn = log[method];
      if (typeof fn === 'function') fn.call(log, source, message, extra);
    } catch (_) { }
  }

  // ============================================================================
  // NETWORK POLICY (как в старом autoplugin)
  //
  // Цель:
  // - блокировать трекеры/статистику и нежелательные домены (Yandex / Google / Stats)
  // - блокировать BWA CORS check (/cors/check) чтобы не засорять сеть
  // - подменять CUB blacklist на [] (чтобы внешние blacklist не отключали плагины)
  //
  // Важно: install() должен быть идемпотентным — он вызывается и в PHASE 0 (до auth),
  // и позже из AutoPlugin (на всякий случай).
  // ============================================================================
  var BLOCK_YANDEX_RE =
    /(^|\.)((yandex\.(ru|com|net|by|kz|ua|uz|tm|tj))|(ya\.ru)|(yastatic\.net)|(yandex\.(net|com)\.tr))$/i;

  var BLOCK_GOOGLE_YT_RE =
    /(^|\.)((google\.com)|(google\.[a-z.]+)|(gstatic\.com)|(googlesyndication\.com)|(googleadservices\.com)|(doubleclick\.net)|(googletagmanager\.com)|(google-analytics\.com)|(analytics\.google\.com)|(api\.google\.com)|(accounts\.google\.com)|(recaptcha\.net)|(youtube\.com)|(ytimg\.com)|(googlevideo\.com)|(youtu\.be)|(youtube-nocookie\.com))$/i;

  var BLOCK_STATS_RE =
    /(^|\.)((scorecardresearch\.com)|(quantserve\.com)|(cdn\.quantserve\.com)|(hotjar\.com)|(static\.hotjar\.com)|(mixpanel\.com)|(api\.mixpanel\.com)|(sentry\.io)|(o\\d+\\.ingest\\.sentry\\.io)|(datadoghq\\.com)|(segment\\.com)|(api\\.segment\\.io)|(amplitude\\.com)|(api\\.amplitude\\.com)|(branch\\.io)|(app-measurement\\.com))$/i;

  // ============================================================================
  // Blocklist settings (localStorage)
  // ============================================================================
  var LS_BUILTIN_YANDEX = 'bl_net_block_yandex_v1';
  var LS_BUILTIN_GOOGLE = 'bl_net_block_google_v1';
  var LS_BUILTIN_STATS = 'bl_net_block_stats_v1';
  var LS_BUILTIN_BWA_CORS = 'bl_net_block_bwa_cors_v1';
  var LS_USER_RULES = 'bl_net_user_rules_v1';

	  function lsGet(key) {
	    try {
	      if (window.Lampa && Lampa.Storage && typeof Lampa.Storage.get === 'function') {
	        var v = Lampa.Storage.get(String(key));
	        if (v !== undefined && v !== null) return String(v);
	      }
	    } catch (_) { }
	    try { return localStorage.getItem(String(key)); } catch (_) { return null; }
	  }
	  function lsSet(key, val) {
	    try { localStorage.setItem(String(key), String(val)); } catch (_) { }
	    try { if (window.Lampa && Lampa.Storage && typeof Lampa.Storage.set === 'function') Lampa.Storage.set(String(key), String(val)); } catch (_) { }
	  }

  function lsGetBool(key, def) {
    try {
      var v = lsGet(key);
      if (v == null || v === '') return !!def;
      var s = String(v).toLowerCase();
      if (s === '0' || s === 'false' || s === 'off' || s === 'no') return false;
      return true;
    } catch (_) {
      return !!def;
    }
  }

	  function lsSetBool(key, on) { lsSet(key, on ? '1' : '0'); }

	  // ============================================================================
	  // Master enable toggle (Network policy)
	  //
	  // IMPORTANT:
	  // - Default is OFF (0): no blocking/sanitizing rules are applied.
	  // - Interceptors (fetch/xhr/etc) may still be installed, but act as pass-through.
	  // ============================================================================
	  var LS_NET_POLICY_ENABLED = 'bl_net_policy_enabled';
	  var __netPolicyEnabledCache = null;

	  function isPolicyEnabledFast() {
	    try {
	      if (__netPolicyEnabledCache === null) __netPolicyEnabledCache = lsGetBool(LS_NET_POLICY_ENABLED, false);
	      return !!__netPolicyEnabledCache;
	    } catch (_) {
	      return false;
	    }
	  }

	  function setPolicyEnabled(on) {
	    __netPolicyEnabledCache = !!on;
	    try { lsSetBool(LS_NET_POLICY_ENABLED, __netPolicyEnabledCache); } catch (_) { }
	    return __netPolicyEnabledCache;
	  }

	  BL.NetPolicy = BL.NetPolicy || {};
	  if (typeof BL.NetPolicy.key !== 'string') BL.NetPolicy.key = LS_NET_POLICY_ENABLED;
	  if (typeof BL.NetPolicy.isEnabled !== 'function') {
	    BL.NetPolicy.isEnabled = function () { return isPolicyEnabledFast(); };
	  }
	  if (typeof BL.NetPolicy.setEnabled !== 'function') {
	    BL.NetPolicy.setEnabled = function (on) { return setPolicyEnabled(!!on); };
	  }

  // ============================================================================
  // JS query params rewrite (localStorage / Lampa.Storage)
  //
  // - only for *.js (by pathname or regex)
  // - rewrite/remove: origin/logged/reset
  // ============================================================================
  var LS_JSQP_ENABLED = 'bl_jsqp_enabled';
  var LS_JSQP_FORCE = 'bl_jsqp_force';
  var LS_JSQP_ORIGIN_MODE = 'bl_jsqp_origin_mode';
  var LS_JSQP_ORIGIN_VALUE = 'bl_jsqp_origin_value';
  var LS_JSQP_LOGGED_MODE = 'bl_jsqp_logged_mode';
  var LS_JSQP_LOGGED_VALUE = 'bl_jsqp_logged_value';
  var LS_JSQP_RESET_MODE = 'bl_jsqp_reset_mode';
  var LS_JSQP_RESET_VALUE = 'bl_jsqp_reset_value';
  var LS_JSQP_MATCH = 'bl_jsqp_match';
  var LS_JSQP_PARAMS = 'bl_jsqp_params';

  var __jsqpDefaultsEnsured = false;
  var __jsqpCache = { matchRaw: null, matchRe: null, paramsRaw: null, paramsSet: null };

  function jsqpStorageGet(key) {
    try { if (window.Lampa && Lampa.Storage && Lampa.Storage.get) return Lampa.Storage.get(String(key)); } catch (_) { }
    return lsGet(key);
  }

  function jsqpStorageSet(key, val) {
    try { if (window.Lampa && Lampa.Storage && Lampa.Storage.set) return Lampa.Storage.set(String(key), String(val)); } catch (_) { }
    lsSet(key, val);
  }

  function jsqpSetIfMissing(key, def) {
    try {
      var v = jsqpStorageGet(key);
      if (v === undefined || v === null) jsqpStorageSet(key, def);
    } catch (_) { }
  }

  function jsqpEnsureDefaultsOnce() {
    if (__jsqpDefaultsEnsured) return;
    __jsqpDefaultsEnsured = true;
    jsqpSetIfMissing(LS_JSQP_ENABLED, '1');
    jsqpSetIfMissing(LS_JSQP_FORCE, '0');
    jsqpSetIfMissing(LS_JSQP_ORIGIN_MODE, 'remove');
    jsqpSetIfMissing(LS_JSQP_ORIGIN_VALUE, '');
    jsqpSetIfMissing(LS_JSQP_LOGGED_MODE, 'remove');
    jsqpSetIfMissing(LS_JSQP_LOGGED_VALUE, 'false');
    jsqpSetIfMissing(LS_JSQP_RESET_MODE, 'remove');
    jsqpSetIfMissing(LS_JSQP_RESET_VALUE, '0');
    jsqpSetIfMissing(LS_JSQP_MATCH, '\\\\.js(\\\\?|$)');
    jsqpSetIfMissing(LS_JSQP_PARAMS, 'origin,logged,reset');
  }

  function jsqpGetBool(key, def) {
    try {
      var v = jsqpStorageGet(key);
      if (v == null || v === '') return !!def;
      var s = String(v).toLowerCase();
      if (s === '0' || s === 'false' || s === 'off' || s === 'no') return false;
      return true;
    } catch (_) {
      return !!def;
    }
  }

  function jsqpGetStr(key, def) {
    try {
      var v = jsqpStorageGet(key);
      if (v === undefined || v === null) return String(def || '');
      return String(v);
    } catch (_) {
      return String(def || '');
    }
  }

  function jsqpCompileMatchRe(raw) {
    raw = String(raw || '');
    if (__jsqpCache.matchRaw === raw && __jsqpCache.matchRe) return __jsqpCache.matchRe;
    __jsqpCache.matchRaw = raw;
    __jsqpCache.matchRe = null;
    if (!raw) return null;

    // Support /pattern/flags input (optional)
    try {
      if (raw[0] === '/' && raw.length > 2) {
        var lastSlash = raw.lastIndexOf('/');
        if (lastSlash > 0) {
          var pat = raw.slice(1, lastSlash);
          var flags = raw.slice(lastSlash + 1);
          if (pat) {
            __jsqpCache.matchRe = new RegExp(pat, flags);
            return __jsqpCache.matchRe;
          }
        }
      }
    } catch (_) { __jsqpCache.matchRe = null; }

    try { __jsqpCache.matchRe = new RegExp(raw); } catch (_) { __jsqpCache.matchRe = null; }
    return __jsqpCache.matchRe;
  }

  function jsqpParseParams(raw) {
    raw = String(raw || '');
    if (__jsqpCache.paramsRaw === raw && __jsqpCache.paramsSet) return __jsqpCache.paramsSet;
    __jsqpCache.paramsRaw = raw;
    __jsqpCache.paramsSet = { origin: false, logged: false, reset: false };

    try {
      var parts = raw.split(',');
      for (var i = 0; i < parts.length; i++) {
        var n = String(parts[i] || '').trim().toLowerCase();
        if (!n) continue;
        if (n === 'origin' || n === 'logged' || n === 'reset') __jsqpCache.paramsSet[n] = true;
      }
    } catch (_) { }

    return __jsqpCache.paramsSet;
  }

  function b64utf8(s) {
    try {
      if (typeof btoa !== 'function') return String(s || '');
      try { return btoa(unescape(encodeURIComponent(String(s || '')))); } catch (e) { return btoa(String(s || '')); }
    } catch (_) {
      return String(s || '');
    }
  }

  BL.Net.rewriteJsQuery = BL.Net.rewriteJsQuery || function (url) {
    var orig = String(url || '');
    try { jsqpEnsureDefaultsOnce(); } catch (_) { }

    // Enabled gate (fast)
    if (!jsqpGetBool(LS_JSQP_ENABLED, true)) return orig;

    var u = null;
    try { u = new URL(orig, location.href); } catch (_) { return orig; }

    // Is JS?
    var isJs = false;
    try {
      var p = String(u.pathname || '');
      isJs = p.slice(-3).toLowerCase() === '.js';
    } catch (_) { isJs = false; }

    if (!isJs) {
      var re = null;
      try { re = jsqpCompileMatchRe(jsqpGetStr(LS_JSQP_MATCH, '\\\\.js(\\\\?|$)')); } catch (_) { re = null; }
      if (re) {
        try { re.lastIndex = 0; } catch (_) { }
        try {
          var s1 = String(u.pathname || '') + String(u.search || '');
          isJs = re.test(s1);
          if (!isJs) {
            try { re.lastIndex = 0; } catch (_) { }
            isJs = re.test(String(u.href || ''));
          }
        } catch (_) { isJs = false; }
      }
    }

    if (!isJs) return orig;

    var managed = jsqpParseParams(jsqpGetStr(LS_JSQP_PARAMS, 'origin,logged,reset'));
    var force = jsqpGetBool(LS_JSQP_FORCE, false);

    if (!force) {
      var hasAny = false;
      try { if (managed.origin && u.searchParams.has('origin')) hasAny = true; } catch (_) { }
      try { if (!hasAny && managed.logged && u.searchParams.has('logged')) hasAny = true; } catch (_) { }
      try { if (!hasAny && managed.reset && u.searchParams.has('reset')) hasAny = true; } catch (_) { }
      if (!hasAny) return orig;
    }

    var changed = false;
    var changedOrigin = false;
    var changedLogged = false;
    var changedReset = false;
    var beforeAbs = '';
    try { beforeAbs = u.toString(); } catch (_) { beforeAbs = ''; }

    // origin
    if (managed.origin) {
      var om = jsqpGetStr(LS_JSQP_ORIGIN_MODE, 'remove');
      if (om === 'set') {
        var ov = jsqpGetStr(LS_JSQP_ORIGIN_VALUE, '');
        var curO = null;
        try { curO = u.searchParams.get('origin'); } catch (_) { curO = null; }
        try { u.searchParams.set('origin', String(ov)); } catch (_) { }
        if (String(curO) !== String(ov)) { changed = true; changedOrigin = true; }
      } else if (om === 'set_b64') {
        var ovb = jsqpGetStr(LS_JSQP_ORIGIN_VALUE, '');
        var enc = '';
        try { enc = b64utf8(ovb); } catch (_) { enc = String(ovb); }
        var curOb = null;
        try { curOb = u.searchParams.get('origin'); } catch (_) { curOb = null; }
        try { u.searchParams.set('origin', String(enc)); } catch (_) { }
        if (String(curOb) !== String(enc)) { changed = true; changedOrigin = true; }
      } else if (om === 'remove') {
        var hadO = false;
        try { hadO = u.searchParams.has('origin'); } catch (_) { hadO = false; }
        try { u.searchParams.delete('origin'); } catch (_) { }
        if (hadO) { changed = true; changedOrigin = true; }
      }
    }

    // logged
    if (managed.logged) {
      var lm = jsqpGetStr(LS_JSQP_LOGGED_MODE, 'remove');
      if (lm === 'set') {
        var lv = jsqpGetStr(LS_JSQP_LOGGED_VALUE, 'false');
        var curL = null;
        try { curL = u.searchParams.get('logged'); } catch (_) { curL = null; }
        try { u.searchParams.set('logged', String(lv)); } catch (_) { }
        if (String(curL) !== String(lv)) { changed = true; changedLogged = true; }
      } else if (lm === 'remove') {
        var hadL = false;
        try { hadL = u.searchParams.has('logged'); } catch (_) { hadL = false; }
        try { u.searchParams.delete('logged'); } catch (_) { }
        if (hadL) { changed = true; changedLogged = true; }
      }
    }

    // reset
    if (managed.reset) {
      var rm = jsqpGetStr(LS_JSQP_RESET_MODE, 'remove');
      if (rm === 'random') {
        var rnd = String(Math.random());
        try { u.searchParams.set('reset', rnd); } catch (_) { }
        changed = true;
        changedReset = true;
      } else if (rm === 'set') {
        var rv = jsqpGetStr(LS_JSQP_RESET_VALUE, '0');
        var curR = null;
        try { curR = u.searchParams.get('reset'); } catch (_) { curR = null; }
        try { u.searchParams.set('reset', String(rv)); } catch (_) { }
        if (String(curR) !== String(rv)) { changed = true; changedReset = true; }
      } else if (rm === 'remove') {
        var hadR = false;
        try { hadR = u.searchParams.has('reset'); } catch (_) { hadR = false; }
        try { u.searchParams.delete('reset'); } catch (_) { }
        if (hadR) { changed = true; changedReset = true; }
      }
    }

    if (!changed) return orig;

    var afterAbs = '';
    try { afterAbs = u.toString(); } catch (_) { afterAbs = beforeAbs; }

    // Log only real rewrites (no pass-through). Cheap + deduped.
    try {
      if (afterAbs && afterAbs !== beforeAbs && BL.Log && typeof BL.Log.push === 'function') {
        var rule = '';
        if (changedOrigin) rule = rule ? (rule + ',origin') : 'origin';
        if (changedLogged) rule = rule ? (rule + ',logged') : 'logged';
        if (changedReset) rule = rule ? (rule + ',reset') : 'reset';

        BL.Log.push({
          ts: Date.now(),
          type: 'jsqp',
          action: 'rewrite',
          channel: 'jsqp',
          from: beforeAbs || orig,
          to: afterAbs || orig,
          rule: rule || null,
          dedupMs: 5000
        });
      }
    } catch (_) { }

    // Optional debug log (OFF by default)
    try {
      if (BL.cfg && BL.cfg.PERF_DEBUG && afterAbs && afterAbs !== beforeAbs) {
        if (BL.Console && BL.Console.info) BL.Console.info('[JSQP] ' + orig + ' -> ' + afterAbs);
        else if (window.console && console.log) console.log('[JSQP] ' + orig + ' -> ' + afterAbs);
      }
    } catch (_) { }

    return afterAbs || orig;
  };

  var BUILTIN_RULES = [
    { id: 'yandex', title: 'Yandex', reason: 'Yandex', lsKey: LS_BUILTIN_YANDEX, description: 'Блокировка доменов Yandex/ya.ru/yastatic.' },
    { id: 'google', title: 'Google/YouTube', reason: 'Google/YouTube', lsKey: LS_BUILTIN_GOOGLE, description: 'Блокировка Google/YouTube/Analytics/Ads.' },
    { id: 'stats', title: 'Statistics', reason: 'Statistics', lsKey: LS_BUILTIN_STATS, description: 'Блокировка трекеров/статистики.' },
    { id: 'bwa_cors', title: 'BWA:CORS', reason: 'BWA:CORS', lsKey: LS_BUILTIN_BWA_CORS, description: 'Блокировка bwa.to /cors/check.' }
  ];

  function getBuiltinRule(id) {
    try {
      var t = String(id || '');
      for (var i = 0; i < BUILTIN_RULES.length; i++) if (BUILTIN_RULES[i].id === t) return BUILTIN_RULES[i];
    } catch (_) { }
    return null;
  }

  function isBuiltinEnabled(id) {
    var r = getBuiltinRule(id);
    if (!r) return true;
    return lsGetBool(r.lsKey, true);
  }

  function setBuiltinEnabled(id, enabled) {
    var r = getBuiltinRule(id);
    if (!r) return false;
    lsSetBool(r.lsKey, !!enabled);
    return true;
  }

  function getBuiltinRulesForUi() {
    var out = [];
    try {
      for (var i = 0; i < BUILTIN_RULES.length; i++) {
        var r = BUILTIN_RULES[i];
        out.push({
          id: r.id,
          title: r.title,
          description: r.description || '',
          enabled: isBuiltinEnabled(r.id)
        });
      }
    } catch (_) { }
    return out;
  }

  // ============================================================================
  // User rules (localStorage)
  // ============================================================================
  var __userRulesCache = null;
  var __userRulesCacheRaw = null;

  function isPlainObject(x) {
    try { return !!x && typeof x === 'object' && !Array.isArray(x); } catch (_) { return false; }
  }

  function makeRuleId() {
    try {
      var t = Date.now().toString(36);
      var r = Math.random().toString(36).slice(2, 7);
      return 'r_' + t + '_' + r;
    } catch (_) {
      return 'r_' + String(+new Date());
    }
  }

  function escapeRe(s) {
    try { return String(s || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
    catch (_) { try { return String(s || ''); } catch (__e) { return ''; } }
  }

  function matchPattern(urlStr, pattern) {
    try {
      var u = String(urlStr || '');
      var p = String(pattern || '').trim();
      if (!u || !p) return false;

      // Compile once per unique pattern string (perf).
      if (!matchPattern.__cache) matchPattern.__cache = Object.create(null);
      var cache = matchPattern.__cache;
      var c = cache[p];

      if (!c) {
        c = null;

        // /regex/i
        try {
          if (p.charAt(0) === '/' && p.lastIndexOf('/') > 1) {
            var last = p.lastIndexOf('/');
            var body = p.slice(1, last);
            var flags = p.slice(last + 1);
            // Only treat as regex when flags look valid; otherwise it's a normal substring like "/path/to".
            if (!flags || /^[gimsuy]*$/.test(flags)) {
              if (!flags) flags = 'i';
              try { c = { kind: 're', re: new RegExp(body, flags) }; } catch (_) { c = null; }
            }
          }
        } catch (_) { c = null; }

        // wildcard (*)
        if (!c) {
          try {
            if (p.indexOf('*') !== -1) {
              var re = escapeRe(p).replace(/\\\*/g, '.*');
              try { c = { kind: 're', re: new RegExp(re, 'i') }; } catch (_) { c = null; }
            }
          } catch (_) { c = null; }
        }

        // substring
        if (!c) {
          c = { kind: 'substr', lc: p.toLowerCase() };
        }

        cache[p] = c || 0;
      }

      if (c === 0) return false;
      if (!c) return false;
      if (c.kind === 'substr') return u.toLowerCase().indexOf(String(c.lc || '')) !== -1;
      if (c.kind === 're' && c.re) {
        try { c.re.lastIndex = 0; } catch (_) { }
        try { return c.re.test(u); } catch (_) { return false; }
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  var ADV_CT_MAP = {
    'application/json': 'application/json; charset=utf-8',
    'application/javascript': 'application/javascript; charset=utf-8',
    'text/css': 'text/css; charset=utf-8',
    'text/html': 'text/html; charset=utf-8',
    'image/svg+xml': 'image/svg+xml; charset=utf-8',
    'image/png': 'image/png',
    'image/jpeg': 'image/jpeg',
    'image/gif': 'image/gif',
    'image/webp': 'image/webp',
    'image/x-icon': 'image/x-icon',
    'text/plain': 'text/plain; charset=utf-8'
  };

  function normalizeAdvancedContentType(ct) {
    try {
      var s = String(ct || '').trim();
      if (!s) return '';
      var base = s.split(';')[0].trim().toLowerCase();
      return ADV_CT_MAP[base] || s;
    } catch (_) {
      return '';
    }
  }

  function normalizeBodyMode(m) {
    try {
      var s = String(m || '').toLowerCase();
      if (s === 'minimal') return 'minimal';
      if (s === 'empty') return 'empty';
      return '';
    } catch (_) {
      return '';
    }
  }

  function normalizeUserRule(rule, idx) {
    try {
      if (!isPlainObject(rule)) return null;
      var pat = '';
      try { pat = String(rule.pattern || '').trim(); } catch (_) { pat = ''; }
      if (!pat) return null;

      var id = '';
      try { id = String(rule.id || '').trim(); } catch (_) { id = ''; }
      if (!id) id = 'legacy_' + String(idx != null ? idx : makeRuleId());

      var type = 'simple';
      try { type = String(rule.type || 'simple'); } catch (_) { type = 'simple'; }
      if (type !== 'advanced') type = 'simple';

      var enabled = true;
      try {
        if (typeof rule.enabled === 'boolean') enabled = rule.enabled;
        else if (typeof rule.enabled === 'number') enabled = rule.enabled !== 0;
        else if (typeof rule.enabled === 'string') enabled = !/^(0|false|off|no)$/i.test(String(rule.enabled || ''));
        else enabled = !!rule.enabled;
      } catch (_) { enabled = true; }

      var out = { id: id, enabled: enabled, pattern: pat, type: type };

      if (type === 'advanced') {
        var ct = '';
        var bm = '';
        try { if (rule.advanced && rule.advanced.contentType) ct = String(rule.advanced.contentType || ''); } catch (_) { ct = ''; }
        try { if (rule.advanced && rule.advanced.bodyMode) bm = String(rule.advanced.bodyMode || ''); } catch (_) { bm = ''; }
        ct = normalizeAdvancedContentType(ct);
        bm = normalizeBodyMode(bm) || 'empty';
        out.advanced = { contentType: ct, bodyMode: bm };
      }

      return out;
    } catch (_) {
      return null;
    }
  }

  function loadUserRules() {
    var raw = null;
    try { raw = lsGet(LS_USER_RULES); } catch (_) { raw = null; }
    if (raw === __userRulesCacheRaw && __userRulesCache) return __userRulesCache;

    __userRulesCacheRaw = raw;
    var arr = [];
    try { arr = raw ? JSON.parse(raw) : []; } catch (_) { arr = []; }
    if (!Array.isArray(arr)) arr = [];

    var out = [];
    var touched = false;
    for (var i = 0; i < arr.length; i++) {
      var r = normalizeUserRule(arr[i], i);
      if (r) {
        out.push(r);
        try {
          if (!arr[i] || !arr[i].id || String(arr[i].id || '').trim() !== String(r.id)) touched = true;
        } catch (_) { }
      }
    }

    __userRulesCache = out;
    if (touched) {
      try { saveUserRules(out); } catch (_) { }
    }
    return out;
  }

  function saveUserRules(list) {
    try {
      var out = Array.isArray(list) ? list : [];
      var raw = JSON.stringify(out);
      __userRulesCache = out;
      __userRulesCacheRaw = raw;
      lsSet(LS_USER_RULES, raw);
    } catch (_) { }
  }

  function getUserRulesForUi() {
    var list = [];
    try { list = loadUserRules(); } catch (_) { list = []; }
    var out = [];
    for (var i = 0; i < list.length; i++) {
      try {
        var r = list[i];
        out.push({
          id: String(r.id || ''),
          enabled: !!r.enabled,
          pattern: String(r.pattern || ''),
          type: String(r.type || 'simple'),
          advanced: r.advanced ? { contentType: String(r.advanced.contentType || ''), bodyMode: String(r.advanced.bodyMode || '') } : null
        });
      } catch (_) { }
    }
    return out;
  }

  function addUserRule(rule) {
    try {
      var r = normalizeUserRule(rule, null);
      if (!r) return null;
      if (!r.id || r.id.indexOf('legacy_') === 0) r.id = makeRuleId();

      var list = loadUserRules();
      list.push(r);
      saveUserRules(list);
      return r.id;
    } catch (_) {
      return null;
    }
  }

  function setUserRuleEnabled(id, enabled) {
    try {
      var t = String(id || '');
      if (!t) return false;
      var list = loadUserRules();
      for (var i = 0; i < list.length; i++) {
        if (String(list[i].id || '') === t) {
          list[i].enabled = !!enabled;
          saveUserRules(list);
          return true;
        }
      }
    } catch (_) { }
    return false;
  }

  function removeUserRule(id) {
    try {
      var t = String(id || '');
      if (!t) return false;
      var list = loadUserRules();
      var out = [];
      var removed = false;
      for (var i = 0; i < list.length; i++) {
        if (String(list[i].id || '') === t) removed = true;
        else out.push(list[i]);
      }
      if (removed) saveUserRules(out);
      return removed;
    } catch (_) {
      return false;
    }
  }

  function isBwaCorsCheck(url) {
    try {
      var host = String(url.hostname || '').toLowerCase();
      var path = String(url.pathname || '').toLowerCase();
      var isBwa = (host === 'bwa.to') || (host.length > 7 && host.slice(host.length - 7) === '.bwa.to');
      if (!isBwa) return false;
      return path.indexOf('/cors/check') === 0;
    } catch (_) {
      return false;
    }
  }

  function classifyBlocked(url) {
    try {
      if (!url) return null;
      if (isBwaCorsCheck(url) && isBuiltinEnabled('bwa_cors')) return { id: 'bwa_cors', label: 'BWA:CORS', reason: 'BWA:CORS' };

      var h = String(url.hostname || '').toLowerCase();
      if (!h) return null;

      if (isBuiltinEnabled('yandex') && BLOCK_YANDEX_RE.test(h)) return { id: 'yandex', label: 'Yandex', reason: 'Yandex' };
      if (isBuiltinEnabled('google') && BLOCK_GOOGLE_YT_RE.test(h)) return { id: 'google', label: 'Google/YouTube', reason: 'Google/YouTube' };
      if (isBuiltinEnabled('stats') && BLOCK_STATS_RE.test(h)) return { id: 'stats', label: 'Statistics', reason: 'Statistics' };

      return null;
    } catch (_) {
      return null;
    }
  }

  function parseUrlSafe(u) {
    try { return new URL(String(u), location.href); } catch (_) { }
    // Old webview fallback: <a href>
    try {
      if (!document || !document.createElement) return null;
      var a = document.createElement('a');
      a.href = String(u || '');
      return {
        protocol: a.protocol,
        hostname: a.hostname,
        pathname: a.pathname,
        href: a.href
      };
    } catch (_) { }
    return null;
  }

	  function getBlockContext(u) {
	    try {
	      if (!u) return null;
	      if (!isPolicyEnabledFast()) return null;
	      var url = parseUrlSafe(u);
	      if (!url) return null;
	      var proto = String(url.protocol || '');
      // Allow HTTP(S) + WS(S) channels (WebSocket URLs are ws:/wss:).
      if (proto !== 'http:' && proto !== 'https:' && proto !== 'ws:' && proto !== 'wss:') return null;

      var urlAbs = '';
      try { urlAbs = String(url.href || ''); } catch (_) { urlAbs = String(u || ''); }

      // User rules first (more specific).
      var ur = loadUserRules();
      for (var i = 0; i < ur.length; i++) {
        var r = ur[i];
        if (!r || !r.enabled) continue;
        if (!r.pattern) continue;
        if (!matchPattern(urlAbs, r.pattern)) continue;

        var ctx = {
          url: urlAbs,
          reason: 'User:' + String(r.id || i),
          ruleId: String(r.id || ''),
          ruleLabel: String(r.pattern || '')
        };

        if (r.type === 'advanced' && r.advanced) {
          var ct = '';
          var bm = '';
          try { if (r.advanced.contentType) ct = String(r.advanced.contentType || ''); } catch (_) { ct = ''; }
          try { if (r.advanced.bodyMode) bm = String(r.advanced.bodyMode || ''); } catch (_) { bm = ''; }
          ct = normalizeAdvancedContentType(ct);
          bm = normalizeBodyMode(bm);
          if (ct) ctx.overrideContentType = ct;
          if (bm) ctx.overrideBodyMode = bm;
        }

        return ctx;
      }

      var why = classifyBlocked(url);
      if (why && why.reason) return { url: urlAbs, reason: String(why.reason), ruleId: String(why.id || ''), ruleLabel: String(why.label || '') };
      return null;
    } catch (_) {
      return null;
    }
  }

  function isBlockedUrl(u) {
    try {
      var ctx = getBlockContext(u);
      return ctx && ctx.reason ? String(ctx.reason) : null;
    } catch (_) {
      return null;
	    }
	  }

	  // ============================================================================
	  // Unified blocking model:
	  //   block => fake "OK" response + mandatory WRN log
	  // ============================================================================
	  function normalizeUrlString(u) { try { return String(u || ''); } catch (_) { return ''; } }

		  // Perf counters + rate-limited logging (must be ultra-cheap).
		  var __perfNetReq = 0;
		  var __perfNetBlocked = 0;
		  var __perfDebugLastTs = 0;
		  var __perfDebugLastReq = 0;

	  var NET_LOG_LIMIT_PER_SEC = 8;
	  var __netLogWinTs = 0;
	  var __netLogInWin = 0;
	  var __netLogSuppressed = 0;
	  var __netLogFlushTimer = null;

	  function getLogModeFast() {
	    try { if (BL.cfg && typeof BL.cfg.LOG_MODE === 'number') return BL.cfg.LOG_MODE || 0; } catch (_) { }
	    try {
	      var c = null;
	      try { c = (BL.Config && typeof BL.Config.get === 'function') ? BL.Config.get() : BL.Config; } catch (_) { c = BL.Config; }
	      if (c && typeof c.LOG_MODE === 'number') return c.LOG_MODE || 0;
	    } catch (_) { }
	    return 0;
	  }

		  // Logging is always recorded (ring buffer). Mode only affects auto-popup/UI.
		  function isLogEnabledFast() { return true; }

		  function flushNetLogSuppressed() {
		    try {
		      if (!__netLogSuppressed) return;
		      var n = __netLogSuppressed;
		      __netLogSuppressed = 0;
		      var line = '[BlackLampa][NET][BLOCK] +' + String(n) + ' logs suppressed (1s)';
		      if (BL.Log && typeof BL.Log.raw === 'function') return BL.Log.raw('WRN', line);
	      try { if (BL.Console && BL.Console.warn) return BL.Console.warn(line); } catch (_) { }
	      try { if (BL.Console && BL.Console.log) return BL.Console.log(line); } catch (_) { }
	    } catch (_) { }
	  }

	  function netLogAllow() {
	    try {
	      var now = Date.now();
	      if (!__netLogWinTs || (now - __netLogWinTs) >= 1000) {
	        __netLogWinTs = now;
	        __netLogInWin = 0;
	        flushNetLogSuppressed();
	      }

	      if (__netLogInWin < NET_LOG_LIMIT_PER_SEC) {
	        __netLogInWin++;
	        return true;
	      }

	      __netLogSuppressed++;
	      if (!__netLogFlushTimer) {
	        __netLogFlushTimer = setTimeout(function () {
	          __netLogFlushTimer = null;
	          flushNetLogSuppressed();
	        }, 1100);
	      }
	    } catch (_) { }
	    return false;
	  }

	  function guessFakePayload(context) {
	    context = context || {};
	    var urlStr = normalizeUrlString(context.url);
	    var reason = String(context.reason || '');
	    var overrideCt = '';
	    var overrideBody = '';
	    try { overrideCt = normalizeAdvancedContentType(context.overrideContentType || ''); } catch (_) { overrideCt = ''; }
	    try { overrideBody = normalizeBodyMode(context.overrideBodyMode || ''); } catch (_) { overrideBody = ''; }

	    var contentType = 'text/plain; charset=utf-8';
	    var bodyText = '';

	    try {
	      var url = new URL(urlStr, location.href);
	      var path = String(url.pathname || '').toLowerCase();

	      var isJson = (path.lastIndexOf('.json') === (path.length - 5));
	      var isJs = (path.lastIndexOf('.js') === (path.length - 3)) || (path.lastIndexOf('.mjs') === (path.length - 4));
	      var isCss = (path.lastIndexOf('.css') === (path.length - 4));
	      var isHtml = (path.lastIndexOf('.html') === (path.length - 5)) || (path.lastIndexOf('.htm') === (path.length - 4));

	      var ext = '';
	      try {
	        var dot = path.lastIndexOf('.');
	        if (dot >= 0) ext = path.slice(dot + 1);
	      } catch (_) { ext = ''; }

	      var isPng = ext === 'png';
	      var isJpg = ext === 'jpg' || ext === 'jpeg';
	      var isGif = ext === 'gif';
	      var isWebp = ext === 'webp';
	      var isSvg = ext === 'svg';
	      var isIco = ext === 'ico';

	      if (isJson || /blacklist/i.test(path) || String(reason).indexOf('CUB:blacklist') === 0) {
	        contentType = 'application/json; charset=utf-8';
	        bodyText = (/blacklist/i.test(path) || String(reason).indexOf('CUB:blacklist') === 0) ? '[]' : '{}';
	      } else if (isJs) {
	        contentType = 'application/javascript; charset=utf-8';
	        bodyText = '';
	      } else if (isCss) {
	        contentType = 'text/css; charset=utf-8';
	        bodyText = '';
	      } else if (isHtml) {
	        contentType = 'text/html; charset=utf-8';
	        bodyText = '';
	      } else if (isSvg) {
	        contentType = 'image/svg+xml; charset=utf-8';
	        bodyText = '<svg xmlns="http://www.w3.org/2000/svg"></svg>';
	      } else if (isPng) {
	        contentType = 'image/png';
	        bodyText = '';
	      } else if (isJpg) {
	        contentType = 'image/jpeg';
	        bodyText = '';
	      } else if (isGif) {
	        contentType = 'image/gif';
	        bodyText = '';
	      } else if (isWebp) {
	        contentType = 'image/webp';
	        bodyText = '';
	      } else if (isIco) {
	        contentType = 'image/x-icon';
	        bodyText = '';
	      } else {
	        contentType = 'text/plain; charset=utf-8';
	        bodyText = '';
	      }
	    } catch (_) { }

	    // Advanced overrides (user rules).
	    try { if (overrideCt) contentType = overrideCt; } catch (_) { }
	    try {
	      if (overrideBody === 'empty') bodyText = '';
	      else if (overrideBody === 'minimal') {
	        var base = String(contentType || '').split(';')[0].trim().toLowerCase();
	        if (base === 'application/json') bodyText = '{}';
	        else if (base === 'image/svg+xml') bodyText = '<svg xmlns="http://www.w3.org/2000/svg"></svg>';
	        else bodyText = '';
	      }
	    } catch (_) { }

	    return { contentType: contentType, bodyText: bodyText, url: urlStr };
	  }

	  function makeEventSafe(type) {
	    try { return new Event(type); } catch (_) { }
	    try {
	      var e = document.createEvent('Event');
	      e.initEvent(type, false, false);
	      return e;
	    } catch (_) { }
	    return null;
	  }

		  function noteBlocked(context) {
		    try {
		      context = context || {};
		      var url = normalizeUrlString(context.url);
		      var channel = String(context.type || context.channel || '');
		      var ruleId = '';
		      var ruleLabel = '';
		      try { ruleId = String(context.ruleId || ''); } catch (_) { ruleId = ''; }
		      try { ruleLabel = String(context.ruleLabel || ''); } catch (_) { ruleLabel = ''; }
		      if (!ruleId) {
		        var rr = String(context.reason || '');
		        if (rr.indexOf('User:') === 0) ruleId = rr.slice(5);
		      }
		      if (!ruleLabel) {
		        try { ruleLabel = String(context.reason || ''); } catch (_) { ruleLabel = ''; }
		      }
		      __netStatus.lastBlocked = { url: url, channel: channel, ruleId: ruleId, ruleLabel: ruleLabel, ts: Date.now() };
		    } catch (_) { }
		  }

		  BL.Net.noteBlocked = BL.Net.noteBlocked || noteBlocked;

			  BL.Net.logBlocked = BL.Net.logBlocked || function (context) {
			    try {
			      try { if (BL.cfg && BL.cfg.PERF_DEBUG) __perfNetBlocked++; } catch (_) { }
			      try { noteBlocked(context); } catch (_) { }
			      if (!netLogAllow()) return;

		      context = context || {};
		      var u = normalizeUrlString(context.url);
		      var t = String(context.type || '');
		      var r = String(context.reason || '');
		      var ruleId = '';
		      var ruleLabel = '';
		      try { ruleId = String(context.ruleId || ''); } catch (_) { ruleId = ''; }
		      try { ruleLabel = String(context.ruleLabel || ''); } catch (_) { ruleLabel = ''; }

		      // Unified event format (preferred).
		      try {
		        if (BL.Log && typeof BL.Log.push === 'function') {
		          var channel = 'other';
		          if (t === 'fetch') channel = 'fetch';
		          else if (t === 'xhr') channel = 'xhr';
		          else if (t === 'ws') channel = 'ws';
		          else if (t === 'script') channel = 'script';
		          else if (t === 'iframe') channel = 'iframe';

		          var type = 'block';
		          if (t === 'script') type = 'script';
		          else if (t === 'iframe') type = 'iframe';

		          var action = 'block';
		          if (t === 'script' || t === 'iframe' || t === 'img' || t === 'link') action = 'sanitize';

		          var rule = '';
		          if (ruleId && ruleLabel) rule = ruleId + ':' + ruleLabel;
		          else if (ruleId) rule = ruleId;
		          else if (ruleLabel) rule = ruleLabel;
		          else rule = r;
		          if (channel === 'other' && t) rule = String(t) + ':' + String(rule || '');

		          BL.Log.push({
		            ts: Date.now(),
		            type: type,
		            action: action,
		            channel: channel,
		            from: u,
		            to: (context && context.to !== undefined) ? context.to : null,
		            rule: rule || null,
		            dedupMs: 3000
		          });
		          return;
		        }
		      } catch (_) { }

		      var line = '[BlackLampa][NET][BLOCK][' + t + '] ' + r + ' ' + u;

		      // Prefer popup logger (and its console mirror) when available.
		      try {
			        if (BL.Log && typeof BL.Log.raw === 'function') {
			          BL.Log.raw('WRN', line);
		          return;
	        }
	      } catch (_) { }

	      try { if (BL.Console && BL.Console.warn) return BL.Console.warn(line); } catch (_) { }
	      try { if (BL.Console && BL.Console.log) return BL.Console.log(line); } catch (_) { }
	    } catch (_) { }
		  };

	  function makeFetchResponse(payload) {
	    var bodyText = String(payload.bodyText || '');
	    var contentType = String(payload.contentType || 'text/plain; charset=utf-8');
	    var url = normalizeUrlString(payload.url);

	    try {
	      if (typeof Response === 'function') {
	        return new Response(bodyText, { status: 200, headers: { 'Content-Type': contentType } });
	      }
	    } catch (_) { }

	    return {
	      ok: true,
	      status: 200,
	      statusText: 'OK',
	      url: url,
	      headers: {
	        get: function (k) {
	          try {
	            if (!k) return null;
	            return (/content-type/i.test(String(k))) ? contentType : null;
	          } catch (_) { return null; }
	        }
	      },
	      text: function () { return Promise.resolve(bodyText); },
	      json: function () {
	        try { return Promise.resolve(JSON.parse(bodyText || '{}')); }
	        catch (_) { return Promise.resolve(null); }
	      },
	      clone: function () { return makeFetchResponse(payload); }
	    };
	  }

	  function applyFakeOkToXhr(xhr, payload) {
	    try {
	      var bodyText = String(payload.bodyText || '');
	      var contentType = String(payload.contentType || '');
	      var url = normalizeUrlString(payload.url);

	      try { Object.defineProperty(xhr, 'readyState', { value: 4, configurable: true }); } catch (_) { }
	      try { Object.defineProperty(xhr, 'status', { value: 200, configurable: true }); } catch (_) { }
	      try { Object.defineProperty(xhr, 'statusText', { value: 'OK', configurable: true }); } catch (_) { }
	      try { Object.defineProperty(xhr, 'responseURL', { value: url, configurable: true }); } catch (_) { }

	      var respVal = bodyText;
	      try {
	        if (xhr && xhr.responseType === 'json') respVal = JSON.parse(bodyText || 'null');
	      } catch (_) { respVal = null; }

	      try { Object.defineProperty(xhr, 'responseText', { value: bodyText, configurable: true }); } catch (_) { }
	      try { Object.defineProperty(xhr, 'response', { value: respVal, configurable: true }); } catch (_) { }

	      // Best-effort header getter.
	      try {
	        if (typeof xhr.getResponseHeader !== 'function') {
	          xhr.getResponseHeader = function (k) {
	            try {
	              if (!k) return null;
	              return (/content-type/i.test(String(k))) ? contentType : null;
	            } catch (_) { return null; }
	          };
	        }
	      } catch (_) { }

	      try { if (xhr.onreadystatechange) xhr.onreadystatechange(); } catch (_) { }
	      try { if (xhr.onload) xhr.onload(); } catch (_) { }

	      try {
	        if (xhr.dispatchEvent) {
	          var e1 = makeEventSafe('readystatechange');
	          if (e1) xhr.dispatchEvent(e1);
	          var e2 = makeEventSafe('load');
	          if (e2) xhr.dispatchEvent(e2);
	        }
	      } catch (_) { }
	    } catch (_) { }
	  }

	  function makeFakeWebSocket(url, why) {
	    var ws = null;
	    try { ws = Object.create(window.WebSocket && window.WebSocket.prototype ? window.WebSocket.prototype : {}); }
	    catch (_) { ws = {}; }

	    try { ws.url = normalizeUrlString(url); } catch (_) { }
	    try { ws.readyState = 3; } catch (_) { } // CLOSED
	    try { ws.bufferedAmount = 0; } catch (_) { }
	    try { ws.extensions = ''; } catch (_) { }
	    try { ws.protocol = ''; } catch (_) { }
	    try { ws.binaryType = 'blob'; } catch (_) { }

	    ws.send = function () { };
	    ws.close = function () { };
	    ws.addEventListener = function () { };
	    ws.removeEventListener = function () { };
	    ws.dispatchEvent = function () { return false; };

	    ws.onopen = null;
	    ws.onmessage = null;
	    ws.onerror = null;
	    ws.onclose = null;

	    setTimeout(function () {
	      try {
	        if (typeof ws.onclose === 'function') {
	          ws.onclose({ type: 'close', code: 1000, reason: String(why || 'Blocked'), wasClean: true });
	        }
	      } catch (_) { }
	    }, 0);

	    return ws;
	  }

	  BL.Net.makeFakeOkResponse = BL.Net.makeFakeOkResponse || function (context) {
	    context = context || {};
	    var type = String(context.type || '');
	    var payload = guessFakePayload(context);

	    if (type === 'fetch') return makeFetchResponse(payload);
	    if (type === 'xhr') {
	      return {
	        ok: true,
	        status: 200,
	        statusText: 'OK',
	        url: payload.url,
	        contentType: payload.contentType,
	        bodyText: payload.bodyText,
	        applyToXhr: function (xhr) { applyFakeOkToXhr(xhr, payload); }
	      };
	    }
	    if (type === 'beacon') return true;
	    if (type === 'ws') return makeFakeWebSocket(payload.url, context.reason);

	    return { ok: true, status: 200, statusText: 'OK' };
	  };

  // [ADDED] CUB blacklist override (return empty array)
  function isCubBlacklistUrl(u) {
    try {
      if (!u) return false;
      var url = new URL(String(u), location.href);
      var host = String(url.hostname || '').toLowerCase();
      var path = String(url.pathname || '').toLowerCase();
      return (host === 'cub.rip') && (path === '/api/plugins/blacklist');
    } catch (_) {
      return false;
    }
  }

		  function install(log) {
	    // idempotency guard (do not wrap fetch/xhr/ws twice)
	    if (BL.PolicyNetwork.__installed) {
	      if (isLogEnabledFast()) logCall(log, 'showDbg', 'Policy', 'already installed', '');
	      return;
	    }
    BL.PolicyNetwork.__installed = true;

    // Reset status snapshot for this session install.
    try {
      setInterceptorActive('fetch', false);
      setInterceptorActive('xhr', false);
      setInterceptorActive('ws', false);
      setInterceptorActive('eventsource', false);
      setInterceptorActive('beacon', false);
      setInterceptorActive('iframe_src', false);
      setInterceptorActive('img_src', false);
      setInterceptorActive('script_src', false);
      setInterceptorActive('link_href', false);
      setInterceptorActive('open', false);
      setInterceptorActive('location', false);
    } catch (_) { }

    // Config flags (read once at install)
    var cfg0 = null;
    try { cfg0 = (BL.Config && typeof BL.Config.get === 'function') ? BL.Config.get() : BL.Config; } catch (_) { cfg0 = BL.Config; }
    cfg0 = cfg0 || {};
    var PERF_DEBUG = false;
    try { PERF_DEBUG = !!cfg0.PERF_DEBUG; } catch (_) { PERF_DEBUG = false; }

    // Ensure JSQP defaults exist (localStorage/Lampa.Storage)
    try { jsqpEnsureDefaultsOnce(); } catch (_) { }

    // User-Agent header override (best-effort; browser environments may block it).
    var UA_APPLY_FETCH = null;
    var UA_APPLY_XHR = null;
    try { UA_APPLY_FETCH = (window.BL && BL.UA && typeof BL.UA.applyHeadersToFetch === 'function') ? BL.UA.applyHeadersToFetch : null; } catch (_) { UA_APPLY_FETCH = null; }
    try { UA_APPLY_XHR = (window.BL && BL.UA && typeof BL.UA.applyHeadersToXhr === 'function') ? BL.UA.applyHeadersToXhr : null; } catch (_) { UA_APPLY_XHR = null; }

	    if (window.fetch) {
	      var origFetch = window.fetch.bind(window);
	      window.fetch = function (input, init) {
	        if (PERF_DEBUG) __perfNetReq++;
	        var u = (typeof input === 'string') ? input : (input && input.url) ? input.url : '';

          // JS query params rewrite (only for *.js)
          try {
            if (u && BL.Net && typeof BL.Net.rewriteJsQuery === 'function') {
              var nu = BL.Net.rewriteJsQuery(u);
              if (nu && nu !== u) {
                var applied = false;
                try {
                  if (typeof input === 'string') {
                    input = nu;
                    applied = true;
                  } else if (typeof URL !== 'undefined' && input instanceof URL) {
                    input = nu;
                    applied = true;
                  } else if (typeof Request !== 'undefined' && input instanceof Request) {
                    input = new Request(nu, input);
                    applied = true;
                  }
                } catch (_) { applied = false; }
                if (applied) u = nu;
              }
            }
          } catch (_) { }

          // Best-effort UA header override (may be unsupported in browser env).
          try {
            if (UA_APPLY_FETCH) {
              var uaR = UA_APPLY_FETCH(input, init);
              if (uaR && uaR.init) init = uaR.init;
              if (uaR && uaR.input !== undefined) input = uaR.input;
            }
          } catch (_) { }

				        if (isPolicyEnabledFast() && isCubBlacklistUrl(u)) {
				          try {
				            if (log && typeof log.push === 'function') {
				              log.push({
			                ts: Date.now(),
			                type: 'network',
			                action: 'sanitize',
			                channel: 'fetch',
			                from: String(u),
			                to: '[]',
			                rule: 'CUB:blacklist',
			                dedupMs: 10000
			              });
			            } else if (isLogEnabledFast()) {
			              logCall(log, 'showOk', 'CUB', 'blacklist overridden', 'fetch | ' + String(u));
			            }
			          } catch (_) { }
			          return Promise.resolve(BL.Net.makeFakeOkResponse({ url: u, type: 'fetch', reason: 'CUB:blacklist' }));
			        }

	        var ctx = getBlockContext(u);
	        if (ctx && ctx.reason) {
	          var c = { url: ctx.url || u, type: 'fetch', reason: ctx.reason, ruleId: ctx.ruleId || '', ruleLabel: ctx.ruleLabel || '' };
	          try { if (ctx.overrideContentType) c.overrideContentType = ctx.overrideContentType; } catch (_) { }
	          try { if (ctx.overrideBodyMode) c.overrideBodyMode = ctx.overrideBodyMode; } catch (_) { }
	          BL.Net.logBlocked(c);
	          return Promise.resolve(BL.Net.makeFakeOkResponse(c));
	        }
	        return origFetch(input, init);
	      };
	      setInterceptorActive('fetch', true);
	    }

	    if (window.XMLHttpRequest) {
      var XHR = window.XMLHttpRequest;
      var origOpen = XHR.prototype.open;
      var origSend = XHR.prototype.send;

      XHR.prototype.open = function (method, url) {
        if (PERF_DEBUG) __perfNetReq++;
        var u = url;

        // JS query params rewrite (only for *.js)
        try { if (u && BL.Net && typeof BL.Net.rewriteJsQuery === 'function') u = BL.Net.rewriteJsQuery(u); } catch (_) { u = url; }

        this.__ap_url = u;
	        this.__ap_mock_cub_blacklist = isPolicyEnabledFast() && isCubBlacklistUrl(u);
        this.__ap_block_ctx = getBlockContext(u);
        try { arguments[1] = u; } catch (_) { }
        return origOpen.apply(this, arguments);
      };

	      XHR.prototype.send = function () {
	        if (this.__ap_mock_cub_blacklist) {
	          var xhr0 = this;
	          var u0 = this.__ap_url;

			          setTimeout(function () {
			            try {
			              try {
			                if (log && typeof log.push === 'function') {
			                  log.push({
			                    ts: Date.now(),
			                    type: 'network',
			                    action: 'sanitize',
			                    channel: 'xhr',
			                    from: String(u0),
			                    to: '[]',
			                    rule: 'CUB:blacklist',
			                    dedupMs: 10000
			                  });
			                } else if (isLogEnabledFast()) {
			                  logCall(log, 'showOk', 'CUB', 'blacklist overridden', 'XHR | ' + String(u0));
			                }
			              } catch (_) { }
			              var fake = BL.Net.makeFakeOkResponse({ url: u0, type: 'xhr', reason: 'CUB:blacklist' });
			              if (fake && fake.applyToXhr) fake.applyToXhr(xhr0);
			            } catch (_) { }
			          }, 0);
		          return;
		        }

	        if (this.__ap_block_ctx && this.__ap_block_ctx.reason) {
	          var u = this.__ap_url;
	          var ctx = this.__ap_block_ctx;
	          var c = { url: ctx.url || u, type: 'xhr', reason: ctx.reason, ruleId: ctx.ruleId || '', ruleLabel: ctx.ruleLabel || '' };
	          try { if (ctx.overrideContentType) c.overrideContentType = ctx.overrideContentType; } catch (_) { }
	          try { if (ctx.overrideBodyMode) c.overrideBodyMode = ctx.overrideBodyMode; } catch (_) { }
	          BL.Net.logBlocked(c);

	          var xhr = this;
	          setTimeout(function () {
	            try {
	              var fake = BL.Net.makeFakeOkResponse(c);
	              if (fake && fake.applyToXhr) fake.applyToXhr(xhr);
	            } catch (_) { }
	          }, 0);
	          return;
	        }

          // Best-effort UA header override (may be unsupported in browser env).
          try { if (UA_APPLY_XHR) UA_APPLY_XHR(this); } catch (_) { }

	        return origSend.apply(this, arguments);
	      };
	      setInterceptorActive('xhr', true);
	    }

      // Script src hook (covers <script src="..."> dynamic loads)
      try {
        if (window.HTMLScriptElement && HTMLScriptElement.prototype && !BL.PolicyNetwork.__jsqpScriptHooked) {
          BL.PolicyNetwork.__jsqpScriptHooked = true;
          setInterceptorActive('script_src', true);

          // setAttribute('src', ...)
          try {
            var _setAttr = HTMLScriptElement.prototype.setAttribute;
            if (typeof _setAttr === 'function') {
              HTMLScriptElement.prototype.setAttribute = function (name, value) {
                try {
                  if (String(name || '').toLowerCase() === 'src') {
                    // JS query params rewrite (only for *.js)
                    try {
                      if (BL.Net && typeof BL.Net.rewriteJsQuery === 'function') value = BL.Net.rewriteJsQuery(value);
                    } catch (_) { }

                    // Hard block (script loads must not escape the policy).
                    var ctx = null;
                    try { ctx = getBlockContext(value); } catch (_) { ctx = null; }
                    if (ctx && ctx.reason) {
                      try { BL.Net.logBlocked({ url: ctx.url || value, type: 'script', reason: ctx.reason, ruleId: ctx.ruleId || '', ruleLabel: ctx.ruleLabel || '' }); } catch (_) { }
                      return;
                    }
                  }
                } catch (_) { }
                return _setAttr.call(this, name, value);
              };
            }
          } catch (_) { }

          // src = ...
          try {
            var d = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, 'src');
            if (d && d.set && d.configurable) {
              Object.defineProperty(HTMLScriptElement.prototype, 'src', {
                configurable: true,
                enumerable: d.enumerable,
                get: d.get,
                set: function (v) {
                  // JS query params rewrite (only for *.js)
                  try { if (BL.Net && typeof BL.Net.rewriteJsQuery === 'function') v = BL.Net.rewriteJsQuery(v); } catch (_) { }

                  // Hard block
                  try {
                    var ctx = getBlockContext(v);
                    if (ctx && ctx.reason) {
                      try { BL.Net.logBlocked({ url: ctx.url || v, type: 'script', reason: ctx.reason, ruleId: ctx.ruleId || '', ruleLabel: ctx.ruleLabel || '' }); } catch (_) { }
                      return;
                    }
                  } catch (_) { }
                  return d.set.call(this, v);
                }
              });
            }
          } catch (_) { }
        }
      } catch (_) { }

      // DOM setAttribute hook (src/href) for elements that bypass fetch/XHR (img/link/iframe/etc.)
      try {
        if (window.Element && Element.prototype && !BL.PolicyNetwork.__domSetAttrHooked) {
          var _elSetAttr = Element.prototype.setAttribute;
          if (typeof _elSetAttr === 'function') {
            BL.PolicyNetwork.__domSetAttrHooked = true;
            Element.prototype.setAttribute = function (name, value) {
              try {
                var n = String(name || '').toLowerCase();
                if (n === 'src' || n === 'href') {
                  var tag = '';
                  try { tag = this && this.tagName ? String(this.tagName).toLowerCase() : ''; } catch (_) { tag = ''; }
                  var channel = '';
                  if (tag === 'img') channel = 'img';
                  else if (tag === 'iframe') channel = 'iframe';
                  else if (tag === 'script') channel = 'script';
                  else if (tag === 'link') channel = 'link';

                  // JSQP for script/src (only for *.js)
                  if (channel === 'script' && n === 'src') {
                    try { if (BL.Net && typeof BL.Net.rewriteJsQuery === 'function') value = BL.Net.rewriteJsQuery(value); } catch (_) { }
                  }

                  // Hard block only for known channels (avoid surprising behavior for random elements).
                  if (channel) {
                    var ctx = null;
                    try { ctx = getBlockContext(value); } catch (_) { ctx = null; }
                    if (ctx && ctx.reason) {
                      try { BL.Net.logBlocked({ url: ctx.url || value, type: channel, reason: ctx.reason, ruleId: ctx.ruleId || '', ruleLabel: ctx.ruleLabel || '' }); } catch (_) { }
                      return;
                    }
                  }
                }
              } catch (_) { }
              return _elSetAttr.call(this, name, value);
            };
          }
        }
      } catch (_) { }

      // Element property hooks (src/href) — cheapest reliable path for dynamic loads.
      function patchUrlProp(proto, prop, channel, statusKey) {
        try {
          if (!proto || !Object.getOwnPropertyDescriptor || !Object.defineProperty) return false;
          var d0 = Object.getOwnPropertyDescriptor(proto, prop);
          if (!d0 || !d0.set || !d0.configurable) return false;
          if (d0.set && d0.set.__blNetWrapped) return true;

          var origSet = d0.set;
          var wrapped = function (v) {
            try {
              var ctx = getBlockContext(v);
              if (ctx && ctx.reason) {
                try { BL.Net.logBlocked({ url: ctx.url || v, type: channel, reason: ctx.reason, ruleId: ctx.ruleId || '', ruleLabel: ctx.ruleLabel || '' }); } catch (_) { }
                return;
              }
            } catch (_) { }
            return origSet.call(this, v);
          };
          try { wrapped.__blNetWrapped = true; } catch (_) { }

          Object.defineProperty(proto, prop, {
            configurable: true,
            enumerable: d0.enumerable,
            get: d0.get,
            set: wrapped
          });
          setInterceptorActive(statusKey, true);
          return true;
        } catch (_) {
          return false;
        }
      }

      try { if (window.HTMLIFrameElement && HTMLIFrameElement.prototype && !BL.PolicyNetwork.__iframeSrcHooked) { BL.PolicyNetwork.__iframeSrcHooked = true; patchUrlProp(HTMLIFrameElement.prototype, 'src', 'iframe', 'iframe_src'); } } catch (_) { }
      try { if (window.HTMLImageElement && HTMLImageElement.prototype && !BL.PolicyNetwork.__imgSrcHooked) { BL.PolicyNetwork.__imgSrcHooked = true; patchUrlProp(HTMLImageElement.prototype, 'src', 'img', 'img_src'); } } catch (_) { }
      try { if (window.HTMLLinkElement && HTMLLinkElement.prototype && !BL.PolicyNetwork.__linkHrefHooked) { BL.PolicyNetwork.__linkHrefHooked = true; patchUrlProp(HTMLLinkElement.prototype, 'href', 'link', 'link_href'); } } catch (_) { }

      // Fallback for environments where prototype setters are not configurable:
      // MutationObserver to sanitize late-bound src/href attributes (best-effort).
      try {
        function ensureDomObserver() {
          try {
            if (BL.PolicyNetwork.__domObserverInstalled) return true;
            if (!window.MutationObserver) return false;
            if (!document || !document.documentElement) return false;

            function sanitizeEl(el) {
              try {
                if (!el || el.nodeType !== 1) return;
                var tag = '';
                try { tag = el.tagName ? String(el.tagName).toLowerCase() : ''; } catch (_) { tag = ''; }

                var attr = '';
                var channel = '';
                if (tag === 'iframe') { attr = 'src'; channel = 'iframe'; }
                else if (tag === 'img') { attr = 'src'; channel = 'img'; }
                else if (tag === 'script') { attr = 'src'; channel = 'script'; }
                else if (tag === 'link') { attr = 'href'; channel = 'link'; }
                else return;

                var v = '';
                try { v = el.getAttribute(attr); } catch (_) { v = ''; }
                if (!v) return;

                var ctx = null;
                try { ctx = getBlockContext(v); } catch (_) { ctx = null; }
                if (!ctx || !ctx.reason) return;

                // Remove attribute ASAP to stop/abort the load.
                try { el.removeAttribute(attr); } catch (_) { }
	                // For iframes: force about:blank to avoid reload loops in some webviews.
	                if (tag === 'iframe') {
	                  try { el.setAttribute('src', 'about:blank'); } catch (_) { }
	                }

	                try { BL.Net.logBlocked({ url: ctx.url || v, type: channel, to: (tag === 'iframe') ? 'about:blank' : null, reason: ctx.reason, ruleId: ctx.ruleId || '', ruleLabel: ctx.ruleLabel || '' }); } catch (_) { }
	              } catch (_) { }
	            }

            function sanitizeNode(node) {
              try {
                if (!node) return;
                if (node.nodeType !== 1) return;
                sanitizeEl(node);
                if (node.querySelectorAll) {
                  var list = null;
                  try { list = node.querySelectorAll('iframe[src],img[src],script[src],link[href]'); } catch (_) { list = null; }
                  if (list && list.length) {
                    for (var i = 0; i < list.length; i++) sanitizeEl(list[i]);
                  }
                }
              } catch (_) { }
            }

            var mo = new MutationObserver(function (mutations) {
              try {
                for (var i = 0; i < mutations.length; i++) {
                  var m = mutations[i];
                  if (!m) continue;
                  if (m.type === 'attributes') {
                    sanitizeEl(m.target);
                  } else if (m.type === 'childList') {
                    var added = m.addedNodes || null;
                    if (!added || !added.length) continue;
                    for (var j = 0; j < added.length; j++) sanitizeNode(added[j]);
                  }
                }
              } catch (_) { }
            });

            mo.observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ['src', 'href'] });
            BL.PolicyNetwork.__domObserverInstalled = true;
            BL.PolicyNetwork.__domObserver = mo;
            return true;
          } catch (_) {
            return false;
          }
        }

        // Only enable observer if at least one key DOM channel is not hooked via setters.
        var needObserver = false;
        try { needObserver = !__netStatus.interceptors.iframe_src || !__netStatus.interceptors.img_src || !__netStatus.interceptors.link_href; } catch (_) { needObserver = true; }
        if (needObserver && ensureDomObserver()) {
          if (!__netStatus.interceptors.iframe_src) setInterceptorActive('iframe_src', true);
          if (!__netStatus.interceptors.img_src) setInterceptorActive('img_src', true);
          if (!__netStatus.interceptors.link_href) setInterceptorActive('link_href', true);
          if (!__netStatus.interceptors.script_src) setInterceptorActive('script_src', true);
        }
      } catch (_) { }

	    if (navigator.sendBeacon) {
	      var origBeacon = navigator.sendBeacon.bind(navigator);
	      navigator.sendBeacon = function (url, data) {
	        if (PERF_DEBUG) __perfNetReq++;
	        var ctx = getBlockContext(url);
	        if (ctx && ctx.reason) {
	          var c = { url: ctx.url || url, type: 'beacon', reason: ctx.reason, ruleId: ctx.ruleId || '', ruleLabel: ctx.ruleLabel || '' };
	          BL.Net.logBlocked(c);
	          return !!BL.Net.makeFakeOkResponse(c);
	        }
	        return origBeacon(url, data);
	      };
	      setInterceptorActive('beacon', true);
	    }

	    if (window.WebSocket) {
	      try {
	        if (!BL.PolicyNetwork.__wsHooked) {
	          BL.PolicyNetwork.__wsHooked = true;
	          var OrigWS = window.WebSocket;
	          window.WebSocket = function (url, protocols) {
	            if (PERF_DEBUG) __perfNetReq++;
	            var ctx = getBlockContext(url);
		            if (ctx && ctx.reason) {
		              var c = { url: ctx.url || url, type: 'ws', reason: ctx.reason, ruleId: ctx.ruleId || '', ruleLabel: ctx.ruleLabel || '' };
		              try {
		                if (BL.Net && typeof BL.Net.logBlocked === 'function') BL.Net.logBlocked(c);
		                else if (BL.Net && typeof BL.Net.noteBlocked === 'function') BL.Net.noteBlocked(c);
		              } catch (_) { }
		              return BL.Net.makeFakeOkResponse(c);
		            }
	            return (protocols !== undefined) ? new OrigWS(url, protocols) : new OrigWS(url);
	          };
	          window.WebSocket.prototype = OrigWS.prototype;
	          setInterceptorActive('ws', true);
	        }
	      } catch (_) { setInterceptorActive('ws', false); }
	    }

	    if (window.EventSource) {
	      try {
	        if (!BL.PolicyNetwork.__esHooked) {
	          BL.PolicyNetwork.__esHooked = true;
	          var OrigES = window.EventSource;

	          function makeFakeEventSource(url, why) {
	            var es = null;
	            try { es = Object.create(OrigES && OrigES.prototype ? OrigES.prototype : {}); } catch (_) { es = {}; }
	            try { es.url = normalizeUrlString(url); } catch (_) { }
	            try { es.readyState = 2; } catch (_) { } // CLOSED
	            es.onopen = null;
	            es.onmessage = null;
	            es.onerror = null;
	            es.close = function () { };
	            es.addEventListener = function () { };
	            es.removeEventListener = function () { };
	            setTimeout(function () {
	              try { if (typeof es.onerror === 'function') es.onerror({ type: 'error', message: String(why || 'Blocked') }); } catch (_) { }
	            }, 0);
	            return es;
	          }

	          window.EventSource = function (url, config) {
	            if (PERF_DEBUG) __perfNetReq++;
	            var ctx = getBlockContext(url);
	            if (ctx && ctx.reason) {
	              var c = { url: ctx.url || url, type: 'eventsource', reason: ctx.reason, ruleId: ctx.ruleId || '', ruleLabel: ctx.ruleLabel || '' };
	              try { BL.Net.logBlocked(c); } catch (_) { }
	              return makeFakeEventSource(c.url, c.reason);
	            }
	            return (config !== undefined) ? new OrigES(url, config) : new OrigES(url);
	          };
	          window.EventSource.prototype = OrigES.prototype;
	          setInterceptorActive('eventsource', true);
	        }
	      } catch (_) { setInterceptorActive('eventsource', false); }
	    }

	    // open()/location redirects (best-effort; must be minimal and safe).
	    try {
	      if (window.open && !BL.PolicyNetwork.__openHooked) {
	        BL.PolicyNetwork.__openHooked = true;
	        var _open = window.open;
	        window.open = function (url) {
	          try {
	            var ctx = getBlockContext(url);
	            if (ctx && ctx.reason) {
	              try { BL.Net.logBlocked({ url: ctx.url || url, type: 'open', reason: ctx.reason, ruleId: ctx.ruleId || '', ruleLabel: ctx.ruleLabel || '' }); } catch (_) { }
	              return null;
	            }
	          } catch (_) { }
	          return _open.apply(window, arguments);
	        };
	        setInterceptorActive('open', true);
	      }
	    } catch (_) { setInterceptorActive('open', false); }

	    try {
	      if (window.Location && Location.prototype && !BL.PolicyNetwork.__locHooked) {
	        BL.PolicyNetwork.__locHooked = true;
	        var _assign = Location.prototype.assign;
	        var _replace = Location.prototype.replace;
	        if (typeof _assign === 'function') {
	          Location.prototype.assign = function (url) {
	            try {
	              var ctx = getBlockContext(url);
	              if (ctx && ctx.reason) {
	                try { BL.Net.logBlocked({ url: ctx.url || url, type: 'location', reason: ctx.reason, ruleId: ctx.ruleId || '', ruleLabel: ctx.ruleLabel || '' }); } catch (_) { }
	                return;
	              }
	            } catch (_) { }
	            return _assign.apply(this, arguments);
	          };
	        }
	        if (typeof _replace === 'function') {
	          Location.prototype.replace = function (url) {
	            try {
	              var ctx = getBlockContext(url);
	              if (ctx && ctx.reason) {
	                try { BL.Net.logBlocked({ url: ctx.url || url, type: 'location', reason: ctx.reason, ruleId: ctx.ruleId || '', ruleLabel: ctx.ruleLabel || '' }); } catch (_) { }
	                return;
	              }
	            } catch (_) { }
	            return _replace.apply(this, arguments);
	          };
	        }
	        setInterceptorActive('location', true);
	      }
	    } catch (_) { setInterceptorActive('location', false); }

    // Optional perf diagnostics (disabled by default)
    try {
      if (PERF_DEBUG && !BL.PolicyNetwork.__perfDebugInstalled) {
        BL.PolicyNetwork.__perfDebugInstalled = true;
        __perfDebugLastTs = Date.now();
        __perfDebugLastReq = __perfNetReq;

        setInterval(function () {
          try {
            var now = Date.now();
            var dt = now - (__perfDebugLastTs || now);
            var curReq = __perfNetReq;
            var dReq = curReq - (__perfDebugLastReq || 0);
            __perfDebugLastTs = now;
            __perfDebugLastReq = curReq;

            var rps = dt > 0 ? (dReq * 1000 / dt) : 0;
            var lp = null;
            try { if (BL.Log && typeof BL.Log.perf === 'function') lp = BL.Log.perf(); } catch (_) { lp = null; }

            var mode = lp ? lp.mode : getLogModeFast();
            var lines = lp ? lp.lines : 0;
            var vis = lp ? lp.visible : false;
            var ws = !!BL.PolicyNetwork.__wsHooked;

            var msg = '[BlackLampa][PERF] NET:' + rps.toFixed(1) + ' req/s'
              + ' | BLOCK:' + String(__perfNetBlocked)
              + ' | LOG:mode=' + String(mode) + ' lines=' + String(lines)
              + ' | POPUP:' + (vis ? '1' : '0')
              + ' | WS:' + (ws ? '1' : '0');

            if (BL.Console && BL.Console.info) return BL.Console.info(msg);
            try { if (window.console && console.log) console.log(msg); } catch (_) { }
          } catch (_) { }
        }, 2000);
      }
    } catch (_) { }

    if (isLogEnabledFast()) logCall(log, 'showOk', 'Policy', 'installed', 'Yandex + Google/YouTube + Statistics + BWA:CORS(/cors/check) + CUB:blacklist([])');
	  }

  BL.PolicyNetwork.install = install;
  BL.PolicyNetwork.isBlockedUrl = isBlockedUrl;

  // UI/API for AutoPlugin Installer → URL Blocklist
  BL.PolicyNetwork.blocklist = BL.PolicyNetwork.blocklist || {};
  BL.PolicyNetwork.blocklist.builtin = BL.PolicyNetwork.blocklist.builtin || {};
  BL.PolicyNetwork.blocklist.user = BL.PolicyNetwork.blocklist.user || {};
  BL.PolicyNetwork.blocklist.storage = BL.PolicyNetwork.blocklist.storage || {};

  BL.PolicyNetwork.blocklist.builtin.getAll = getBuiltinRulesForUi;
  BL.PolicyNetwork.blocklist.builtin.setEnabled = setBuiltinEnabled;
  BL.PolicyNetwork.blocklist.user.getAll = getUserRulesForUi;
  BL.PolicyNetwork.blocklist.user.add = addUserRule;
  BL.PolicyNetwork.blocklist.user.setEnabled = setUserRuleEnabled;
  BL.PolicyNetwork.blocklist.user.remove = removeUserRule;

  BL.PolicyNetwork.blocklist.storage.lsBuiltinYandex = LS_BUILTIN_YANDEX;
  BL.PolicyNetwork.blocklist.storage.lsBuiltinGoogle = LS_BUILTIN_GOOGLE;
  BL.PolicyNetwork.blocklist.storage.lsBuiltinStats = LS_BUILTIN_STATS;
  BL.PolicyNetwork.blocklist.storage.lsBuiltinBwaCors = LS_BUILTIN_BWA_CORS;
  BL.PolicyNetwork.blocklist.storage.lsUserRules = LS_USER_RULES;
})();
