(function () {
  'use strict';

  var BL = window.BL = window.BL || {};
  BL.MenuRegistry = BL.MenuRegistry || {};

  var API = BL.MenuRegistry;
  if (API.__blMenuRegistryLoaded) return;
  API.__blMenuRegistryLoaded = true;

  function safe(fn, fallback) { try { return fn(); } catch (_) { return fallback; } }
  function isPlainObject(x) { try { return !!x && typeof x === 'object' && !Array.isArray(x); } catch (_) { return false; } }
  function t(ctx, key, vars) {
    try { return ctx && typeof ctx.t === 'function' ? String(ctx.t(String(key || ''), vars) || '') : String(key || ''); } catch (_) { return String(key || ''); }
  }

  function sGet(k, fallback) {
    var v = null;
    try { if (window.Lampa && Lampa.Storage && Lampa.Storage.get) v = Lampa.Storage.get(String(k)); } catch (_) { v = null; }
    if (v === undefined || v === null) { try { if (window.localStorage) v = localStorage.getItem(String(k)); } catch (_) { v = null; } }
    return (v === undefined || v === null) ? fallback : v;
  }

  function sSet(k, v) {
    try { if (window.Lampa && Lampa.Storage && Lampa.Storage.set) return Lampa.Storage.set(String(k), String(v)); } catch (_) { }
    try { if (window.localStorage) localStorage.setItem(String(k), String(v)); } catch (_) { }
  }

  function shortStr(s, max) {
    s = String(s || '');
    max = Number(max || 160);
    return (s.length <= max) ? s : (s.slice(0, max - 1) + '…');
  }

  function addParam(ctx, param, field, onRender, onChange) {
    try {
      Lampa.SettingsApi.addParam({
        component: ctx.componentId,
        param: param,
        field: field,
        onRender: onRender,
        onChange: onChange
      });
    } catch (_) { }
  }

  function optKey(opt) {
    if (!opt) return '';
    try { if (opt.key) return String(opt.key); } catch (_) { }
    var id = '';
    try { id = String(opt.id || ''); } catch (_) { id = ''; }
    if (!id) return '';
    return (id.indexOf('bl_') === 0) ? id : ('bl_' + id);
  }

  function parseBool(v, def) {
    if (v === undefined || v === null || v === '') return !!def;
    try { return !/^(0|false|off|no)$/i.test(String(v || '').trim()); } catch (_) { return !!def; }
  }

  function valuesMap(values) {
    if (!values) return null;
    if (Array.isArray(values)) {
      var out = {};
      for (var i = 0; i < values.length; i++) out[i] = String(values[i]);
      return out;
    }
    if (typeof values === 'object') return values;
    return null;
  }

  function P(ctx, opt) {
    try {
      if (!window.Lampa || !Lampa.SettingsApi || !Lampa.SettingsApi.addParam) return null;
      opt = opt || {};

      var key = optKey(opt);
      if (!key) return null;

      var type = String(opt.type || 'static');
      var lType = (type === 'toggle') ? 'select' : type;

      var param = { name: key, type: lType };
      if (lType === 'static') { if (opt.values !== undefined) param.values = opt.values; }
      else if (lType === 'select') param.values = valuesMap(opt.values) || ((type === 'toggle') ? { 0: 'OFF', 1: 'ON' } : null);
      else if (lType === 'input') {
        if (opt.values !== undefined) param.values = opt.values;
        if (opt.placeholder !== undefined) param.placeholder = opt.placeholder;
      }

      if (opt["default"] !== undefined) param["default"] = opt["default"];
      else if (lType === 'static') param["default"] = (param.values !== undefined) ? param.values : true;
      else if (lType === 'select') param["default"] = 0;
      else if (lType === 'input') param["default"] = '';

      var name = '';
      var desc = '';
      try { name = (opt.name !== undefined && opt.name !== null) ? String(opt.name) : ''; } catch (_) { name = ''; }
      try { desc = (opt.desc !== undefined && opt.desc !== null) ? String(opt.desc) : ''; } catch (_) { desc = ''; }
      if (!name && opt.nameKey) name = t(ctx, opt.nameKey);
      if (!desc && opt.descKey) desc = t(ctx, opt.descKey);

      var onRender = null;
      if (typeof opt.onEnter === 'function' || typeof opt.onRender === 'function') {
        onRender = function (item) {
          try { if (typeof opt.onRender === 'function') opt.onRender(item, ctx); } catch (_) { }
          if (typeof opt.onEnter === 'function') {
            try { if (item && item.on) item.on('hover:enter', function () { opt.onEnter(item, ctx); }); } catch (_) { }
          }
        };
      }

      var onChange = null;
      if (typeof opt.onChange === 'function') {
        onChange = function () {
          var v = sGet(key, null);
          if (type === 'toggle') v = parseBool(v, false) ? 1 : 0;
          opt.onChange(v, ctx);
        };
      }

      addParam(ctx, param, { name: name, description: desc }, onRender, onChange);
      return key;
    } catch (_) {
      return null;
    }
  }

  function callMod(modName, fnName, ctx, fallbackTitleKey) {
    try {
      var mod = null;
      try { mod = (window.BL && BL[modName]) ? BL[modName] : null; } catch (_) { mod = null; }
      if (mod && typeof mod[fnName] === 'function') return mod[fnName](ctx);
    } catch (_) { }
    if (fallbackTitleKey) P(ctx, { id: 'mod_missing_' + String(modName || '') + '_' + String(fnName || ''), type: 'static', values: 'Module missing', name: t(ctx, fallbackTitleKey), desc: 'Module missing: ' + String(modName || '') });
  }

  function rootStatusRender(ctx, item) {
    try {
      if (!window.$ || !item) return;
      var ss = null;
      try { ss = (ctx && ctx.opts && typeof ctx.opts.statusStrings === 'function') ? (ctx.opts.statusStrings() || null) : null; } catch (_) { ss = null; }
      var raw = ss && ss.raw ? String(ss.raw) : '';
      var help = ss && ss.help ? String(ss.help) : '';
      var short = ss && ss.short ? String(ss.short) : '';

      var $d = item.find('.settings-param__descr');
      if (!$d.length) {
        item.append('<div class=\"settings-param__descr\"></div>');
        $d = item.find('.settings-param__descr');
      }
      $d.empty();
      if (short) $d.append($('<div></div>').text(short));
      if (raw && raw !== short) $d.append($('<div></div>').text(raw));
      if (help) $d.append($('<div style=\"opacity:0.85;margin-top:0.35em;white-space:pre-wrap;\"></div>').text(help));
    } catch (_) { }
  }

  function dfPluginDetail(ctx, payload) {
    try {
      if (window.BL && BL.ModuleInstaller && typeof BL.ModuleInstaller.defaultFocusPluginDetail === 'function') {
        return BL.ModuleInstaller.defaultFocusPluginDetail(ctx, payload || null) || 0;
      }
    } catch (_) { }
    return 0;
  }

  // ---------------------------------------------------------------------------
  // SSOT: Menu topology (route graph)
  // ---------------------------------------------------------------------------
  var TOP = BL.MenuTopology = {
    root: { id: 'root', children: ['plugins', 'network', 'ua', 'logs', 'backup', 'filesystem_scan', 'query_params', 'danger', 'ui', 'status'] },

    plugins: { id: 'plugins', parent: 'root', titleKey: 'menu.root.plugins.title', descKey: 'menu.root.plugins.desc', children: ['managed', 'extras'] },
    managed: { id: 'managed', parent: 'plugins', title: 'Managed', desc: 'Плагины из bl.autoplugin.json → plugins[].', screen: 'managed' },
    extras: { id: 'extras', parent: 'plugins', title: 'Extras', desc: 'Дополнительные плагины из bl.autoplugin.json → disabled[].', screen: 'extras' },
    plugin_detail: { id: 'plugin_detail', parent: 'plugins', menu: false, screen: 'plugin_detail', defaultFocus: dfPluginDetail },

    network: { id: 'network', parent: 'root', titleKey: 'menu.root.network.title', descKey: 'menu.root.network.desc', children: ['net_policy', 'net_builtin', 'net_rules', 'network_status', 'jsqp'] },
    net_policy: { id: 'net_policy', parent: 'network', title: 'Сетевая политика', desc: 'Вкл/выкл применение правил/блокировок.', screen: 'net_policy' },
    net_builtin: { id: 'net_builtin', parent: 'network', title: 'Встроенные блокировки', desc: 'Yandex / Google / Stats / BWA:CORS.', screen: 'net_builtin' },
    net_rules: { id: 'net_rules', parent: 'network', title: 'Пользовательские правила', desc: 'bl_net_user_rules_v1 (JSON array).', screen: 'net_rules' },
    network_status: { id: 'network_status', parent: 'network', title: 'Interceptors Status', desc: 'Coverage matrix + lastBlocked.', screen: 'network_status' },
    jsqp: { id: 'jsqp', parent: 'network', title: 'JSQP', desc: 'JS query rewrite (origin/logged/reset).', screen: 'jsqp' },

    ua: { id: 'ua', parent: 'root', titleKey: 'menu.root.ua.title', descKey: 'menu.root.ua.desc', children: ['ua_presets', 'ua_effective'] },
    ua_presets: { id: 'ua_presets', parent: 'ua', title: 'Presets', desc: 'Выбор пресета UA. Включает Original(system).', screen: 'ua_presets' },
    ua_effective: { id: 'ua_effective', parent: 'ua', title: 'Effective (now)', desc: 'Показывает текущий effective UA и поддержку подмены заголовка.', screen: 'ua_effective' },

    logs: { id: 'logs', parent: 'root', titleKey: 'menu.root.logs.title', descKey: 'menu.root.logs.desc', children: ['logs_view', 'logging'] },
    logs_view: { id: 'logs_view', parent: 'logs', title: 'View logs', desc: 'Открывает viewer логов BlackLampa.', screen: 'action', action: function () { try { if (window.BL && BL.Log && BL.Log.openViewer) BL.Log.openViewer(); } catch (_) { } } },
    logging: { id: 'logging', parent: 'logs', title: 'Log mode', desc: 'silent / popup (не влияет на блокировки).', screen: 'logging' },

    backup: { id: 'backup', parent: 'root', titleKey: 'menu.root.backup.title', descKey: 'menu.root.backup.desc', screen: 'backup' },
    filesystem_scan: { id: 'filesystem_scan', parent: 'root', titleKey: 'menu.root.filescan.title', descKey: 'menu.root.filescan.desc', screen: 'action', action: function () { try { if (window.BL && BL.FileScanner && BL.FileScanner.open) BL.FileScanner.open(); } catch (_) { } } },
    query_params: { id: 'query_params', parent: 'root', titleKey: 'menu.root.query_params.title', descKey: 'menu.root.query_params.desc', screen: 'query_params' },
    danger: { id: 'danger', parent: 'root', titleKey: 'menu.root.danger.title', descKey: 'menu.root.danger.desc', screen: 'danger' },
    ui: { id: 'ui', parent: 'root', titleKey: 'menu.root.ui.title', descKey: 'menu.root.ui.desc', screen: 'ui' },
    status: { id: 'status', parent: 'root', titleKey: 'menu.root.status.title', param: { name: 'bl_pi_root_status', type: 'static', values: '', default: '' }, screen: 'status', rootRender: rootStatusRender }
  };

  function node(id) { try { return TOP[String(id || '')] || null; } catch (_) { return null; } }
  function has(route) { return !!node(route); }

  function nodeTitle(ctx, n, id) {
    var s = '';
    try { s = n.titleKey ? t(ctx, n.titleKey) : ''; } catch (_) { s = ''; }
    if (!s) try { s = (n.title !== undefined && n.title !== null) ? String(n.title) : ''; } catch (_) { s = ''; }
    return s || String(id || '');
  }

  function nodeDesc(ctx, n) {
    var s = '';
    try { s = n.descKey ? t(ctx, n.descKey) : ''; } catch (_) { s = ''; }
    if (!s) try { s = (n.desc !== undefined && n.desc !== null) ? String(n.desc) : ''; } catch (_) { s = ''; }
    return s || '';
  }

  function menuParamName(parentId, childId) {
    return 'bl_pi_' + String(parentId || 'root') + '_' + String(childId || '');
  }

  function buildMenu(ctx, routeId) {
    var n = node(routeId);
    var kids = (n && Array.isArray(n.children)) ? n.children : [];

    for (var i = 0; i < kids.length; i++) {
      (function (childId, idx) {
        childId = String(childId || '');
        if (!childId) return;
        var c = node(childId);
        if (!c || c.menu === false) return;

        var title = nodeTitle(ctx, c, childId);
        var desc = nodeDesc(ctx, c);

        var param = c.param || { name: menuParamName(routeId, childId), type: 'static', default: true };
        if (!param.name) param.name = menuParamName(routeId, childId);
        if (!param.type) param.type = 'static';
        if (param["default"] === undefined) param["default"] = true;

        addParam(ctx, param, { name: title, description: desc }, function (item) {
          try {
            if (item && item.on) {
              item.on('hover:enter', function () {
                try {
                  if (c.action) return c.action(ctx, item, idx);
                  ctx.push(childId, null, 0, idx);
                } catch (_) { }
              });
            }
          } catch (_) { }
          try { if (c.rootRender) c.rootRender(ctx, item, idx); } catch (_) { }
        });
      })(kids[i], i);
    }
  }

  function actionScreen(ctx) {
    try {
      var n = node(ctx && ctx.route ? ctx.route : '');
      if (n && n.action) n.action(ctx || null);
      else P(ctx, { id: 'action_none', type: 'static', values: '—', name: 'Action', desc: 'No action.' });
    } catch (_) { }
  }

  var Screens = {
    action: actionScreen,
    managed: function (ctx) { callMod('ModuleInstaller', 'buildManagedScreen', ctx); },
    extras: function (ctx) { callMod('ModuleInstaller', 'buildExtrasScreen', ctx); },
    plugin_detail: function (ctx) { callMod('ModuleInstaller', 'buildPluginDetailScreen', ctx); },
    danger: function (ctx) { callMod('ModuleInstaller', 'buildDangerScreen', ctx); },
    net_policy: buildNetPolicyScreen,
    net_builtin: buildNetBuiltinScreen,
    net_rules: buildNetRulesScreen,
    network_status: buildNetworkStatusScreen,
    jsqp: buildJsqpScreen,
    ui: buildUiScreen,
    logging: buildLoggingScreen,
    ua_presets: buildUaPresetsScreen,
    ua_effective: buildUaEffectiveScreen,
    query_params: buildQueryParamsScreen,
    status: buildStatusScreen,
    backup: buildBackupScreen
  };

  API.has = has;
  API.normalizeRoute = function (route) {
    route = String(route || 'root');
    return has(route) ? route : 'root';
  };

  API.defaultFocus = function (route, payload, ctx) {
    try {
      var n = node(route);
      if (n && typeof n.defaultFocus === 'function') return n.defaultFocus(ctx || null, payload || null) || 0;
    } catch (_) { }
    return 0;
  };

  API.build = function (route, ctx) {
    route = API.normalizeRoute(route);
    var n = node(route) || node('root');
    if (!n) return;
    try { if (n.guard && typeof n.guard === 'function' && !n.guard(ctx || null)) { route = 'root'; n = node('root'); } } catch (_) { route = 'root'; n = node('root'); }
    if (!n) return;
    if (n.children && n.children.length) return buildMenu(ctx, route);
    if (n.screen && Screens[n.screen]) return Screens[n.screen](ctx || null);
    buildMenu(ctx, 'root');
  };

  // ---------------------------------------------------------------------------
  // Non-installer screens (kept mostly as-is, but routed through registry/core)
  // ---------------------------------------------------------------------------
  function buildNetPolicyScreen(ctx) {
    try {
      P(ctx, {
        key: 'bl_net_policy_enabled',
        type: 'toggle',
        values: { 0: 'OFF', 1: 'ON' },
        default: 0,
        name: 'Сетевая политика',
        desc: 'OFF => правила не применяются (UI остаётся доступен).',
        onChange: function (v) {
          try { if (window.BL && BL.NetPolicy && BL.NetPolicy.setEnabled) BL.NetPolicy.setEnabled(!!v); } catch (_) { }
        }
      });

      var on = parseBool(sGet('bl_net_policy_enabled', '0'), false) ? 'ON' : 'OFF';
      P(ctx, { id: 'net_policy_status', type: 'static', values: on, name: 'Status', desc: on });
    } catch (_) { }
  }

  function buildNetBuiltinScreen(ctx) {
    try {
      P(ctx, { key: 'bl_net_block_yandex_v1', type: 'toggle', values: { 0: 'OFF', 1: 'ON' }, default: 1, name: 'Yandex', desc: 'Блокировка доменов Yandex/ya.ru/yastatic.' });
      P(ctx, { key: 'bl_net_block_google_v1', type: 'toggle', values: { 0: 'OFF', 1: 'ON' }, default: 1, name: 'Google/YouTube', desc: 'Google/YouTube/Analytics/Ads.' });
      P(ctx, { key: 'bl_net_block_stats_v1', type: 'toggle', values: { 0: 'OFF', 1: 'ON' }, default: 1, name: 'Statistics', desc: 'Трекеры/статистика.' });
      P(ctx, { key: 'bl_net_block_bwa_cors_v1', type: 'toggle', values: { 0: 'OFF', 1: 'ON' }, default: 1, name: 'BWA:CORS', desc: 'bwa.to /cors/check.' });
    } catch (_) { }
  }

  function buildNetRulesScreen(ctx) {
    try {
      var LS = 'bl_net_user_rules_v1';
      var raw = sGet(LS, null);
      if (raw === undefined || raw === null) { raw = '[]'; sSet(LS, raw); }

      var arr = null;
      try { arr = raw ? JSON.parse(String(raw)) : []; } catch (_) { arr = null; }
      if (!Array.isArray(arr)) {
        P(ctx, { id: 'net_rules_parse_err', type: 'static', values: 'ERR', name: 'User rules', desc: 'Ошибка парсинга bl_net_user_rules_v1 (JSON). Ключ не перезаписывается.' });
        return;
      }

      var touched = false;
      var used = {};
      for (var i = 0; i < arr.length; i++) {
        try {
          var r0 = arr[i];
          if (!isPlainObject(r0)) continue;

          var id0 = r0.id;
          var id = Math.floor(+id0);
          if (!(id > 0 && isFinite(id))) { id = 0; touched = true; }
          if (!id) id = (Date.now ? Date.now() : +new Date());
          while (used[id]) { id++; touched = true; }
          used[id] = 1;
          if (String(id0) !== String(id)) { r0.id = id; touched = true; }

          var en0 = r0.enabled;
          var en = (typeof en0 === 'boolean') ? en0 : parseBool(en0, true);
          if (en !== en0) touched = true;
          r0.enabled = en;

          var tp0 = String(r0.type || 'simple');
          var tp = (tp0 === 'advanced') ? 'advanced' : 'simple';
          if (tp !== tp0) touched = true;
          r0.type = tp;
        } catch (_) { }
      }

      if (touched) { try { sSet(LS, JSON.stringify(arr)); } catch (_) { } }

      var list = [];
      for (var j = 0; j < arr.length; j++) {
        var r = arr[j];
        if (!isPlainObject(r)) continue;
        var pat = '';
        try { pat = String(r.pattern || '').trim(); } catch (_) { pat = ''; }
        if (!pat) continue;
        list.push({ i: j, id: String(r.id || ''), pattern: pat, enabled: !!r.enabled, type: String(r.type || 'simple') });
      }

      if (!list.length) {
        P(ctx, { id: 'net_rules_empty', type: 'static', values: '—', name: 'User rules', desc: 'Нет правил.' });
      } else {
        for (var k = 0; k < list.length; k++) {
          (function (it) {
            var title = (it.enabled ? '✓ ' : '') + it.pattern;
            var desc = 'id=' + it.id + ' | type=' + it.type + ' | Enter: toggle | Long: remove';
            P(ctx, {
              id: 'net_rule_' + it.id,
              type: 'static',
              name: title,
              desc: desc,
              onEnter: function () {
                try { arr[it.i].enabled = !arr[it.i].enabled; sSet(LS, JSON.stringify(arr)); } catch (_) { }
                ctx.refresh();
              },
              onRender: function (item) {
                try {
                  if (!item || !item.on) return;
                  item.on('hover:long', function () {
                    ctx.runOnce('Rule', 'Remove rule?\n\n' + it.pattern, function () {
                      try { arr.splice(it.i, 1); sSet(LS, JSON.stringify(arr)); } catch (_) { }
                    });
                  });
                } catch (_) { }
              }
            });
          })(list[k]);
        }
      }

      P(ctx, { key: 'bl_net_rule_new_pattern', type: 'input', values: '', default: '', placeholder: 'example.com | /regexp/', name: 'Add rule (pattern)', desc: '' });
      P(ctx, {
        id: 'net_rule_add_btn',
        type: 'button',
        name: 'Add rule',
        desc: 'Добавить simple rule в bl_net_user_rules_v1.',
        onChange: function () {
          try {
            var pat = String(sGet('bl_net_rule_new_pattern', '') || '').trim();
            if (!pat) return ctx.notify('[[BlackLampa]] Укажите Pattern');

            var used = {};
            for (var i3 = 0; i3 < arr.length; i3++) { try { used[Math.floor(+arr[i3].id)] = 1; } catch (_) { } }
            var id = (Date.now ? Date.now() : +new Date());
            while (used[id]) id++;
            arr.push({ id: id, enabled: true, pattern: pat, type: 'simple' });
            sSet(LS, JSON.stringify(arr));

            sSet('bl_net_rule_new_pattern', '');
            ctx.refresh();
          } catch (_) { }
        }
      });
    } catch (_) { }
  }

		  function buildNetworkStatusScreen(ctx) {
		    try {
	      var st = null;
	      try { st = (window.BL && BL.PolicyNetwork && typeof BL.PolicyNetwork.getStatus === 'function') ? BL.PolicyNetwork.getStatus() : null; } catch (_) { st = null; }
	      st = st || {};
	      var m = st.interceptors || {};

      var keys = [
        { k: 'fetch', title: 'fetch' },
        { k: 'xhr', title: 'xhr' },
        { k: 'ws', title: 'ws' },
        { k: 'eventsource', title: 'eventsource' },
        { k: 'beacon', title: 'beacon' },
        { k: 'iframe_src', title: 'iframe/src' },
        { k: 'img_src', title: 'img/src' },
        { k: 'script_src', title: 'script/src' },
        { k: 'link_href', title: 'link/href' },
        { k: 'open', title: 'window.open' },
        { k: 'location', title: 'location redirects' }
      ];

		      for (var i = 0; i < keys.length; i++) {
		        (function (row) {
		          try {
		            var active = false;
		            try { active = !!m[row.k]; } catch (_) { active = false; }
		            var line = active ? 'yes' : 'no';
		            P(ctx, { id: 'pi_net_matrix_' + row.k, type: 'static', values: line, name: row.title, desc: line });
		          } catch (_) { }
		        })(keys[i]);
		      }

      var lb = st.lastBlocked || null;
      var lbLine = '—';
	      var ruleLine = '—';
	      try {
	        if (lb && lb.url) {
	          lbLine = String(lb.channel || '') + ' | ' + shortStr(String(lb.url || ''), 220);
	          ruleLine = String(lb.ruleId || '') + (lb.ruleLabel ? (' | ' + shortStr(String(lb.ruleLabel || ''), 160)) : '');
	        }
	      } catch (_) { }

		      P(ctx, { id: 'pi_net_last_blocked', type: 'static', values: lbLine, name: 'Last blocked', desc: lbLine });
		      P(ctx, { id: 'pi_net_rule', type: 'static', values: ruleLine, name: 'Rule matched', desc: ruleLine });
		    } catch (_) { }
		  }

	  function buildQueryParamsScreen(ctx) {
	    try {
	      var raw = '';
	      try { raw = String(location.search || ''); } catch (_) { raw = ''; }

      try {
        var head = raw ? raw : '(empty)';
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_qp_raw', type: 'static', values: head, default: head },
          field: { name: 'location.search', description: head }
        });
      } catch (_) { }

      var qs = raw;
      if (qs && qs.charAt(0) === '?') qs = qs.slice(1);
      if (!qs) return;

      var parts = [];
      try { parts = qs.split('&'); } catch (_) { parts = []; }
      for (var i = 0; i < parts.length; i++) {
        try {
          var kv = String(parts[i] || '');
          if (!kv) continue;
          var eq = kv.indexOf('=');
          var k = eq >= 0 ? kv.slice(0, eq) : kv;
          var v = eq >= 0 ? kv.slice(eq + 1) : '';
          try { k = decodeURIComponent(k); } catch (_) { }
          try { v = decodeURIComponent(v); } catch (_) { }
          k = String(k || '').trim();
          if (!k) continue;
          v = String(v || '');

          Lampa.SettingsApi.addParam({
            component: ctx.componentId,
            param: { name: 'bl_pi_qp_' + String(i), type: 'static', values: v, default: v },
            field: { name: k, description: v || '(empty)' }
          });
        } catch (_) { }
      }
    } catch (_) { }
  }

  function buildStatusScreen(ctx) {
    try {
      function yn(v) { return v ? 'yes' : 'no'; }

      // Lampa version/build (best-effort)
      try {
        var av = '';
        var cv = '';
        try { av = (window.Lampa && Lampa.Manifest && Lampa.Manifest.app_version) ? String(Lampa.Manifest.app_version) : ''; } catch (_) { av = ''; }
        try { cv = (window.Lampa && Lampa.Manifest && Lampa.Manifest.css_version) ? String(Lampa.Manifest.css_version) : ''; } catch (_) { cv = ''; }
        var ver = (av ? ('app ' + av) : '') + (cv ? (' | css ' + cv) : '');
        if (ver) {
          Lampa.SettingsApi.addParam({
            component: ctx.componentId,
            param: { name: 'bl_pi_status_lampa_ver', type: 'static', values: ver, default: ver },
            field: { name: 'Lampa version', description: ver }
          });
        }
      } catch (_) { }

      // AutoPlugin status strings (legacy)
      try {
        var ss = null;
        try { ss = (ctx && ctx.opts && typeof ctx.opts.statusStrings === 'function') ? (ctx.opts.statusStrings() || null) : null; } catch (_) { ss = null; }
        var raw = ss && ss.raw ? String(ss.raw) : '';
        var help = ss && ss.help ? String(ss.help) : '';
        var short = ss && ss.short ? String(ss.short) : '';
        var sline = short || raw || '';
        if (sline) {
          Lampa.SettingsApi.addParam({
            component: ctx.componentId,
            param: { name: 'bl_pi_status_autoplugin', type: 'static', values: sline, default: sline },
            field: { name: 'AutoPlugin', description: sline }
          });
        }
        if (help) {
          Lampa.SettingsApi.addParam({
            component: ctx.componentId,
            param: { name: 'bl_pi_status_help', type: 'static', values: help, default: help },
            field: { name: 'Help', description: help }
          });
        }
      } catch (_) { }

      // Log mode
      try {
        var mode = 'silent';
        try { mode = (window.BL && BL.Log && typeof BL.Log.getMode === 'function') ? String(BL.Log.getMode() || 'silent') : 'silent'; } catch (_) { mode = 'silent'; }
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_status_log_mode', type: 'static', values: mode, default: mode },
          field: { name: 'Log mode', description: mode }
        });
      } catch (_) { }

      // UA preset
      try {
        var uaId = '';
        var uaTitle = '';
        try { uaId = (window.BL && BL.UA && typeof BL.UA.getSelectedPresetId === 'function') ? String(BL.UA.getSelectedPresetId() || '') : ''; } catch (_) { uaId = ''; }
        try { uaTitle = (window.BL && BL.UA && BL.UA.effective && BL.UA.effective.title) ? String(BL.UA.effective.title || '') : ''; } catch (_) { uaTitle = ''; }
        var uaLine = (uaId ? uaId : 'unknown') + (uaTitle ? (' — ' + uaTitle) : '');
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_status_ua', type: 'static', values: uaLine, default: uaLine },
          field: { name: 'UA preset', description: uaLine }
        });
      } catch (_) { }

      // Network interceptors summary
      try {
        var st = null;
        try { st = (window.BL && BL.PolicyNetwork && typeof BL.PolicyNetwork.getStatus === 'function') ? BL.PolicyNetwork.getStatus() : null; } catch (_) { st = null; }
        st = st || {};
        var m = st.interceptors || {};
        var sum = 'fetch=' + yn(!!m.fetch)
          + ' xhr=' + yn(!!m.xhr)
          + ' ws=' + yn(!!m.ws)
          + ' iframe=' + yn(!!m.iframe_src);
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_status_net', type: 'static', values: sum, default: sum },
          field: { name: 'Network', description: sum }
        });
      } catch (_) { }

      // FS concurrency (config)
      try {
        var conc = '';
        try { conc = window.localStorage ? String(localStorage.getItem('bl_fs_concurrency_v1') || '') : ''; } catch (_) { conc = ''; }
        if (!conc) conc = '(default)';
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_status_fs_conc', type: 'static', values: conc, default: conc },
          field: { name: 'FS concurrency', description: 'bl_fs_concurrency_v1 = ' + conc }
        });
      } catch (_) { }

      // Effective UA string (short)
      try {
        var effUa = '';
        try { effUa = String(navigator && navigator.userAgent ? navigator.userAgent : '') || ''; } catch (_) { effUa = ''; }
        effUa = shortStr(effUa, 180);
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_status_ua_eff', type: 'static', values: effUa, default: effUa },
          field: { name: 'UA effective', description: effUa }
        });
      } catch (_) { }
    } catch (_) { }
  }

	  function buildUiScreen(ctx) {
	    try {
	      P(ctx, {
	        id: 'ext_filters',
	        type: 'toggle',
	        values: { 0: 'OFF', 1: 'ON' },
	        default: 0,
	        nameKey: 'ui.extfilters.title',
	        descKey: 'ui.extfilters.desc',
	        onChange: function () {
	          try {
	            if (window.BL && BL.ModuleExtFilters && BL.ModuleExtFilters.refresh) return BL.ModuleExtFilters.refresh();
	            if (window.BL && BL.ExtFilters && BL.ExtFilters.refresh) return BL.ExtFilters.refresh();
	          } catch (_) { }
	        }
	      });
	    } catch (_) { }
	  }

	  function buildLoggingScreen(ctx) {
	    try {
	      var mode = 'silent';
	      try { mode = (window.BL && BL.Log && BL.Log.getMode) ? String(BL.Log.getMode() || 'silent') : 'silent'; } catch (_) { mode = 'silent'; }
	      if (mode !== 'popup') mode = 'silent';

	      // 0) No popup (default)
	      P(ctx, {
	        id: 'pi_logging_silent',
	        type: 'static',
	        name: (mode === 'silent' ? '✓ No popup (default)' : 'No popup (default)'),
	        desc: 'Popup не открывается автоматически. Логи всё равно пишутся в память.',
	        onEnter: function () {
	          try { if (window.BL && BL.Log && BL.Log.setMode) BL.Log.setMode('silent'); } catch (_) { }
	          ctx.refresh();
	        }
	      });

	      // 1) Auto popup
	      P(ctx, {
	        id: 'pi_logging_popup',
	        type: 'static',
	        name: (mode === 'popup' ? '✓ Auto popup' : 'Auto popup'),
	        desc: 'Разрешает авто-показ popup при логах/ошибках.',
	        onEnter: function () {
	          try { if (window.BL && BL.Log && BL.Log.setMode) BL.Log.setMode('popup'); } catch (_) { }
	          ctx.refresh();
	        }
	      });
	    } catch (_) { }
	  }

	  function buildJsqpScreen(ctx) {
	    try {
	      function p(opt) { P(ctx, opt); }

	      var DEF = {
	        bl_jsqp_enabled: '1',
	        bl_jsqp_force: '0',
	        bl_jsqp_origin_mode: 'remove',
	        bl_jsqp_origin_value: '',
	        bl_jsqp_logged_mode: 'remove',
	        bl_jsqp_logged_value: 'false',
	        bl_jsqp_reset_mode: 'remove',
	        bl_jsqp_reset_value: '0',
	        bl_jsqp_match: '\\\\.js(\\\\?|$)',
	        bl_jsqp_params: 'origin,logged,reset'
	      };

	      function sEnsure(k, def) { if (sGet(k, null) === null) sSet(k, def); }

      // Seed defaults
      try {
        sEnsure('bl_jsqp_enabled', DEF.bl_jsqp_enabled);
        sEnsure('bl_jsqp_force', DEF.bl_jsqp_force);
        sEnsure('bl_jsqp_origin_mode', DEF.bl_jsqp_origin_mode);
        sEnsure('bl_jsqp_origin_value', DEF.bl_jsqp_origin_value);
        sEnsure('bl_jsqp_logged_mode', DEF.bl_jsqp_logged_mode);
        sEnsure('bl_jsqp_logged_value', DEF.bl_jsqp_logged_value);
        sEnsure('bl_jsqp_reset_mode', DEF.bl_jsqp_reset_mode);
        sEnsure('bl_jsqp_reset_value', DEF.bl_jsqp_reset_value);
        sEnsure('bl_jsqp_match', DEF.bl_jsqp_match);
        sEnsure('bl_jsqp_params', DEF.bl_jsqp_params);
      } catch (_) { }

      var resetMode = String(sGet('bl_jsqp_reset_mode', DEF.bl_jsqp_reset_mode) || DEF.bl_jsqp_reset_mode);
      resetMode = resetMode.toLowerCase();
      if (resetMode !== 'remove' && resetMode !== 'set' && resetMode !== 'random') resetMode = DEF.bl_jsqp_reset_mode;

	      // Info
	      var info = 'Подмена/удаление GET параметров (origin/logged/reset) в запросах на *.js';
	      p({ id: 'jsqp_info', type: 'static', values: info, name: 'JS query params', desc: info });

	      // Enabled
	      p({ id: 'jsqp_enabled', type: 'toggle', values: { 0: 'OFF', 1: 'ON' }, default: 1, name: 'Enabled', desc: 'Включить переписывание URL для *.js.' });

	      // Force apply
	      p({ id: 'jsqp_force', type: 'toggle', values: { 0: 'OFF', 1: 'ON' }, default: 0, name: 'Force apply', desc: 'Переписывать даже если params отсутствуют в URL.' });

	      // Match regex
	      p({
	        id: 'jsqp_match',
	        type: 'input',
	        values: '',
	        default: DEF.bl_jsqp_match,
	        placeholder: DEF.bl_jsqp_match,
	        name: 'Match regex',
	        desc: 'RegExp (string) для матчинга URL. По умолчанию: \\\\.js(\\\\?|$)'
	      });

	      // Params list
	      p({
	        id: 'jsqp_params',
	        type: 'input',
	        values: '',
	        default: DEF.bl_jsqp_params,
	        placeholder: DEF.bl_jsqp_params,
	        name: 'Params list (csv)',
	        desc: 'Список управляемых параметров (origin,logged,reset).'
	      });

	      // Origin mode
	      p({
	        id: 'jsqp_origin_mode',
	        type: 'select',
	        values: { remove: 'remove', set: 'set', set_b64: 'set (base64)' },
	        default: DEF.bl_jsqp_origin_mode,
	        name: 'Origin mode',
	        desc: 'remove => удалить | set => задать значение | set (base64) => btoa(utf8).'
	      });

	      // Origin value
	      p({
	        id: 'jsqp_origin_value',
	        type: 'input',
	        values: '',
	        default: DEF.bl_jsqp_origin_value,
	        placeholder: 'example.com',
	        name: 'Origin value',
	        desc: 'Если origin_mode=set: ставим как есть (без base64).'
	      });

	      // Logged mode
	      p({
	        id: 'jsqp_logged_mode',
	        type: 'select',
	        values: { remove: 'remove', set: 'set' },
	        default: DEF.bl_jsqp_logged_mode,
	        name: 'Logged mode',
	        desc: 'remove => удалить | set => задать значение.'
	      });

	      // Logged value
	      p({
	        id: 'jsqp_logged_value',
	        type: 'input',
	        values: '',
	        default: DEF.bl_jsqp_logged_value,
	        placeholder: 'false',
	        name: 'Logged value',
	        desc: 'Если logged_mode=set (строка, например 0/false).'
	      });

	      // Reset mode
	      p({
	        id: 'jsqp_reset_mode',
	        type: 'select',
	        values: { remove: 'remove', set: 'set', random: 'random' },
	        default: DEF.bl_jsqp_reset_mode,
	        name: 'Reset mode',
	        desc: 'remove => удалить | set => value | random => Math.random().',
	        onChange: function () { ctx.go('jsqp', null, ctx.getFocusIndex()); }
	      });

	      // Reset value (hidden when random)
	      if (resetMode !== 'random') {
	        p({
	          id: 'jsqp_reset_value',
	          type: 'input',
	          values: '',
	          default: DEF.bl_jsqp_reset_value,
	          placeholder: '0',
	          name: 'Reset value',
	          desc: 'Если reset_mode=set.'
	        });
	      }

	      // Test URL (optional)
	      var ex = '/x.js?logged=false&reset=0.123&origin=YmxhY2tsYW1wYS5naXRodWIuaW8%3D';
	      p({ id: 'jsqp_test_url', type: 'input', values: '', default: ex, placeholder: ex, name: 'Test URL', desc: 'URL для теста (опционально).' });

	      // Test rewrite
	      p({
	        id: 'jsqp_test',
	        type: 'button',
	        name: 'Test rewrite',
	        desc: 'Показывает результат BL.Net.rewriteJsQuery().',
	        onChange: function () {
	          try {
	            var sample = String(sGet('bl_jsqp_test_url', '') || '').trim();
	            if (!sample) sample = String(location.href || '');

	            var after = sample;
	            try {
	              if (window.BL && BL.Net && typeof BL.Net.rewriteJsQuery === 'function') after = BL.Net.rewriteJsQuery(sample);
	            } catch (_) { after = sample; }

	            if (String(after) === String(sample)) ctx.notify('[[BlackLampa]] JSQP: no change');
	            else ctx.notify('[[BlackLampa]] JSQP: ' + shortStr(after, 240));
	          } catch (_) { }
	        }
	      });

	      // Reset to defaults
	      p({
	        id: 'jsqp_reset_defaults',
	        type: 'button',
	        name: 'Reset to defaults',
	        desc: 'Сбрасывает настройки JSQP.',
	        onChange: function () {
	          try {
	            sSet('bl_jsqp_enabled', DEF.bl_jsqp_enabled);
	            sSet('bl_jsqp_force', DEF.bl_jsqp_force);
	            sSet('bl_jsqp_origin_mode', DEF.bl_jsqp_origin_mode);
	            sSet('bl_jsqp_origin_value', DEF.bl_jsqp_origin_value);
	            sSet('bl_jsqp_logged_mode', DEF.bl_jsqp_logged_mode);
	            sSet('bl_jsqp_logged_value', DEF.bl_jsqp_logged_value);
	            sSet('bl_jsqp_reset_mode', DEF.bl_jsqp_reset_mode);
	            sSet('bl_jsqp_reset_value', DEF.bl_jsqp_reset_value);
	            sSet('bl_jsqp_match', DEF.bl_jsqp_match);
	            sSet('bl_jsqp_params', DEF.bl_jsqp_params);
	          } catch (_) { }
	          ctx.notify('[[BlackLampa]] JSQP: defaults restored');
	          ctx.go('jsqp', null, ctx.getFocusIndex());
	        }
	      });
	    } catch (_) { }
	  }

	  function buildUaPresetsScreen(ctx) {
	    try {
      var uaApi = null;
      try { uaApi = (window.BL && BL.UA) ? BL.UA : null; } catch (_) { uaApi = null; }
      try { if (uaApi && uaApi.ensureOriginalStored) uaApi.ensureOriginalStored(); } catch (_) { }

      var selectedId = '';
      try { if (uaApi && typeof uaApi.getSelectedPresetId === 'function') selectedId = String(uaApi.getSelectedPresetId() || ''); } catch (_) { selectedId = ''; }
      if (!selectedId) {
        try { selectedId = window.localStorage ? String(localStorage.getItem('bl_ua_preset_id_v1') || '') : ''; } catch (_) { selectedId = ''; }
      }

      var presets = [];
      try { if (uaApi && typeof uaApi.getPresets === 'function') presets = uaApi.getPresets() || []; } catch (_) { presets = []; }
      if (!Array.isArray(presets)) presets = [];

	      for (var i = 0; i < presets.length; i++) {
	        (function (p) {
	          try {
	            if (!p || !p.id) return;
	            var id = String(p.id || '');
	            var title = String(p.title || id);
	            var desc = String(p.desc || '');
	            var ua = String(p.ua || '');
	            var isSel = (id === selectedId);

            var d = desc || '';
            if (ua) d = d ? (d + '\n' + shortStr(ua, 120)) : shortStr(ua, 120);
            if (!d) d = ' ';

		            P(ctx, {
		              id: 'pi_ua_preset_' + id,
		              type: 'static',
		              name: (isSel ? '✓ ' : '') + title,
	              desc: d,
	              onEnter: function () {
	                try {
	                  if (uaApi && typeof uaApi.setSelectedPresetId === 'function') uaApi.setSelectedPresetId(id);
	                  else if (window.localStorage) localStorage.setItem('bl_ua_preset_id_v1', id);
	                } catch (_) { }

	                try { if (uaApi && typeof uaApi.apply === 'function') uaApi.apply(); } catch (_) { }
	                ctx.notify('[[BlackLampa]] UA preset: ' + title);
	                ctx.refresh();
	              }
	            });
	          } catch (_) { }
	        })(presets[i]);
	      }

      // Custom UA input (only when custom selected)
	      if (String(selectedId || '') === 'custom') {
	        var curCustom = '';
	        try { if (uaApi && typeof uaApi.getCustomUa === 'function') curCustom = String(uaApi.getCustomUa() || ''); } catch (_) { curCustom = ''; }

		        P(ctx, {
		          id: 'ua_custom_v1',
		          type: 'input',
	          values: '',
	          default: curCustom,
	          placeholder: 'Mozilla/5.0 ...',
	          name: 'Custom UA',
	          desc: 'Используется только когда выбран preset=Custom.',
	          onChange: function (v) {
	            try {
	              v = String(v || '').trim();
	              if (uaApi && typeof uaApi.setCustomUa === 'function') uaApi.setCustomUa(v);
	              else try { if (window.localStorage) localStorage.setItem('bl_ua_custom_v1', v); } catch (_) { }

	              try { if (uaApi && typeof uaApi.apply === 'function') uaApi.apply(); } catch (_) { }
	              ctx.notify('[[BlackLampa]] UA: custom applied');
	            } catch (_) { }
	          }
	        });
	      }
	    } catch (_) { }
	  }

	  function buildUaEffectiveScreen(ctx) {
	    try {
	      var uaApi = null;
	      try { uaApi = (window.BL && BL.UA) ? BL.UA : null; } catch (_) { uaApi = null; }

      var original = '';
      try { if (uaApi && typeof uaApi.getOriginalUa === 'function') original = String(uaApi.getOriginalUa() || ''); } catch (_) { original = ''; }
      if (!original) {
        try { original = window.localStorage ? String(localStorage.getItem('bl_ua_original_v1') || '') : ''; } catch (_) { original = ''; }
      }

      var selectedId = '';
      var selectedTitle = '';
      try { if (uaApi && typeof uaApi.getSelectedPresetId === 'function') selectedId = String(uaApi.getSelectedPresetId() || ''); } catch (_) { selectedId = ''; }
      try { if (uaApi && uaApi.effective && uaApi.effective.title) selectedTitle = String(uaApi.effective.title || ''); } catch (_) { selectedTitle = ''; }

      var effUa = '';
      try { effUa = String(navigator && navigator.userAgent ? navigator.userAgent : '') || ''; } catch (_) { effUa = ''; }

      // Header override support (best-effort + cached)
      try { if (uaApi && typeof uaApi.ensureHeaderSupport === 'function') uaApi.ensureHeaderSupport(); } catch (_) { }
      var hdrFlag = '';
      try { hdrFlag = window.localStorage ? String(localStorage.getItem('bl_ua_header_override_supported_v1') || '') : ''; } catch (_) { hdrFlag = ''; }
      var hdrLine = (hdrFlag === '0') ? 'UA header override: unsupported' : 'UA header override: supported';

	      P(ctx, { id: 'ua_eff_orig', type: 'static', values: original, name: 'Original UA (stored)', desc: original });

	      try {
	        var selLine = (selectedId ? selectedId : 'unknown') + (selectedTitle ? (' — ' + selectedTitle) : '');
		        P(ctx, { id: 'ua_eff_sel', type: 'static', values: selLine, name: 'Selected preset', desc: selLine });
	      } catch (_) { }

	      P(ctx, { id: 'ua_eff_now', type: 'static', values: effUa, name: 'Effective navigator.userAgent', desc: effUa });

	      P(ctx, { id: 'ua_eff_hdr', type: 'static', values: hdrLine, name: 'UA header override', desc: hdrLine });

	      var note = 'Some channels cannot override UA headers in browser environment.';
	      P(ctx, { id: 'ua_eff_note', type: 'static', values: note, name: 'Note', desc: note });
	    } catch (_) { }
	  }

  function buildBackupScreen(ctx) {
    try {
      if (!window.BL || !BL.Backup) {
        var na = 'BL.Backup missing (bl.backup.js not loaded).';
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_na', type: 'static', values: na, default: na },
          field: { name: 'Backup / Transfer', description: na }
        });
        return;
      }

      var CFG_KEY = 'bl_backup_cfg_v1';

      function normPrefixes(arr) {
        var out = [];
        try {
          if (!Array.isArray(arr)) arr = [];
          for (var i = 0; i < arr.length; i++) {
            var p = String(arr[i] || '').trim();
            if (p) out.push(p);
          }
        } catch (_) { }
        if (!out.length) out = ['bl_'];
        return out;
      }

      function parsePrefixesString(str) {
        var out = [];
        try {
          var parts = String(str || '').split(',');
          for (var i = 0; i < parts.length; i++) {
            var p = String(parts[i] || '').trim();
            if (p) out.push(p);
          }
        } catch (_) { }
        if (!out.length) out = ['bl_'];
        return out;
      }

      function loadCfgSafe() {
        var def = { prefixes: ['bl_'], provider: 'paste_rs', keyHint: '', unsafe_store_key: 0 };
        var raw = safe(function () { return window.localStorage ? localStorage.getItem(CFG_KEY) : ''; }, '');
        if (!raw) return def;
        var obj = safe(function () { return JSON.parse(String(raw || '')); }, null);
        if (!isPlainObject(obj)) return def;
        def.prefixes = normPrefixes(obj.prefixes);
        def.provider = String(obj.provider || def.provider) || def.provider;
        def.keyHint = String(obj.keyHint || '');
        def.unsafe_store_key = (String(obj.unsafe_store_key || '0') === '1') ? 1 : 0;
        return def;
      }

      function saveCfgSafe(cfg) {
        try {
          if (!window.localStorage) return;
          localStorage.setItem(CFG_KEY, JSON.stringify(cfg || {}));
        } catch (_) { }
      }

      function pad2(n) { n = Number(n || 0); return (n < 10 ? '0' : '') + String(n); }

      function fmtTs(ms) {
        try {
          var d = new Date(Number(ms) || 0);
          return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
        } catch (_) { return ''; }
      }

      function shortId(idOrUrl) {
        var s = String(idOrUrl || '');
        try {
          if (s.indexOf('://') > 0) {
            var u = new URL(s, location.href);
            var p = String(u.pathname || '');
            var segs = p.split('/');
            var last = segs[segs.length - 1] || '';
            var prev = segs.length > 1 ? (segs[segs.length - 2] || '') : '';
            var id = last || prev || '';
            return id || s;
          }
        } catch (_) { }
        return s;
      }

      function syncCfgFromUi(currentCfg) {
        var provider = String(sGet('bl_backup_provider_v1', currentCfg.provider) || currentCfg.provider);
        var keyHint = String(sGet('bl_backup_key_hint_v1', currentCfg.keyHint) || '');
        var unsafe = String(sGet('bl_backup_unsafe_store_key_v1', currentCfg.unsafe_store_key ? '1' : '0') || '0');
        var prefixesStr = String(sGet('bl_backup_prefixes_v1', (currentCfg.prefixes || ['bl_']).join(',')) || '');
        var prefixes = parsePrefixesString(prefixesStr);
        var cfg = { prefixes: prefixes, provider: provider, keyHint: keyHint, unsafe_store_key: (unsafe === '1') ? 1 : 0 };
        saveCfgSafe(cfg);
        return cfg;
      }

      var cfg = loadCfgSafe();
      saveCfgSafe(cfg);

      var hist = [];
      try { hist = (BL.Backup.history && BL.Backup.history.list) ? (BL.Backup.history.list() || []) : []; } catch (_) { hist = []; }
      if (!Array.isArray(hist)) hist = [];

      // Status
      try {
        var st = 'history: ' + String(hist.length) + ' | prefixes: ' + String((cfg.prefixes || ['bl_']).join(','));
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_status', type: 'static', values: st, default: st },
          field: { name: 'Backup / Transfer', description: 'Экспорт/импорт настроек BlackLampa (localStorage) + шифрование + history.' }
        });
      } catch (_) { }

      // Encryption key (input)
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_key_input_v1', type: 'input', values: '', default: '', placeholder: 'Enter key / PIN' },
          field: { name: 'Encryption key', description: 'Используется для AES-GCM. Не хранится в history по умолчанию.' }
        });
      } catch (_) { }

      // Key label / hint (input)
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_key_hint_v1', type: 'input', values: '', default: String(cfg.keyHint || ''), placeholder: 'home-tv / phone / test' },
          field: { name: 'Key label / hint', description: '' },
          onChange: function () { cfg = syncCfgFromUi(cfg); }
        });
      } catch (_) { }

      // Prefixes (input)
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_prefixes_v1', type: 'input', values: '', default: String((cfg.prefixes || ['bl_']).join(',')), placeholder: 'bl_' },
          field: { name: 'Prefixes', description: 'Какие ключи localStorage экспортировать (prefix list, через ,).' },
          onChange: function () { cfg = syncCfgFromUi(cfg); }
        });
      } catch (_) { }

      // Provider (select)
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_provider_v1', type: 'select', values: { paste_rs: 'paste.rs', dpaste_org: 'dpaste.org' }, default: String(cfg.provider || 'paste_rs') },
          field: { name: 'Provider', description: '' },
          onChange: function () { cfg = syncCfgFromUi(cfg); }
        });
      } catch (_) { }

      // Unsafe: store key in history (select)
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_unsafe_store_key_v1', type: 'select', values: { 0: 'OFF (safe)', 1: 'ON (unsafe)' }, default: (cfg.unsafe_store_key ? 1 : 0) },
          field: { name: 'Unsafe: store key in history', description: 'Если ON — ключ сохранится вместе с paste ID в history.' },
          onChange: function () { cfg = syncCfgFromUi(cfg); }
        });
      } catch (_) { }

      function keyHash(pass) {
        try {
          if (window.BL && BL.Backup && typeof BL.Backup.__keyHash === 'function') return BL.Backup.__keyHash(String(pass || ''));
        } catch (_) { }
        return Promise.resolve('');
      }

      // Export button
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_export_btn', type: 'button' },
          field: { name: 'Export', description: 'Шифрует конфиг и загружает в выбранный provider. Запись добавляется в history.' },
          onChange: function () {
            var pass = String(sGet('bl_backup_key_input_v1', '') || '').trim();
            if (!pass) {
              ctx.notify('[[BlackLampa]] Set encryption key');
              return;
            }
            ctx.runAsync('Exporting...', function () {
              cfg = syncCfgFromUi(cfg);

              var cfgObj = null;
              try { cfgObj = BL.Backup.collectConfig(); } catch (_) { cfgObj = { meta: {}, data: {} }; }

              var provider = String(cfg.provider || 'paste_rs');
              var hint = String(cfg.keyHint || '');
              var unsafeFlag = !!cfg.unsafe_store_key;

              return BL.Backup.encrypt(cfgObj, pass).then(function (payloadStr) {
                return BL.Backup.upload(provider, payloadStr).then(function (up) {
                  var storedId = '';
                  try { storedId = (up && up.url) ? String(up.url || '') : String(up && up.id ? up.id : ''); } catch (_) { storedId = ''; }
                  if (!storedId) storedId = String(up && up.id ? up.id : '');

                  return keyHash(pass).then(function (kh) {
                    try {
                      var item = {
                        ts: Date.now(),
                        provider: provider,
                        id: storedId,
                        bytes: payloadStr.length,
                        schema: 1,
                        keyHint: hint,
                        keyHash: String(kh || ''),
                        note: ''
                      };
                      if (unsafeFlag) item.unsafeKey = pass;
                      if (BL.Backup.history && BL.Backup.history.add) BL.Backup.history.add(item);
                    } catch (_) { }
                    ctx.notify('[[BlackLampa]] Exported: ' + shortId(storedId));
                  });
                });
              }).catch(function (e) {
                if (e && e.code === 'CORS') ctx.notify('[[BlackLampa]] Provider blocked by CORS on this device');
                else ctx.notify('[[BlackLampa]] Export failed: ' + String((e && e.message) ? e.message : e));
                throw e;
              });
            });
          }
        });
      } catch (_) { }

      // Import mode
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_import_mode_v1', type: 'select', values: { merge: 'Merge (default)', replace: 'Replace' }, default: 'merge' },
          field: { name: 'Import mode', description: 'Merge — обновляет/добавляет ключи. Replace — очищает BL-prefix ключи и импортирует.' }
        });
      } catch (_) { }

      function doImport(provider, idOrUrl, pass, mode) {
        provider = String(provider || '');
        idOrUrl = String(idOrUrl || '').trim();
        pass = String(pass || '').trim();
        mode = (mode === 'replace') ? 'replace' : 'merge';

        if (!idOrUrl) {
          ctx.notify('[[BlackLampa]] Set paste id/url');
          return Promise.reject(new Error('no id'));
        }
        if (!pass) {
          ctx.notify('[[BlackLampa]] Set encryption key');
          return Promise.reject(new Error('no key'));
        }

        return BL.Backup.download(provider, idOrUrl).then(function (payloadStr) {
          return BL.Backup.decrypt(payloadStr, pass);
        }).then(function (cfgObj) {
          BL.Backup.applyConfig(cfgObj, mode);
          ctx.notify('[[BlackLampa]] Imported, reloading…');
          setTimeout(function () { try { location.reload(); } catch (_) { } }, 0);
        }).catch(function (e) {
          if (e && e.code === 'CORS') ctx.notify('[[BlackLampa]] Provider blocked by CORS on this device');
          else ctx.notify('[[BlackLampa]] Import failed: ' + String((e && e.message) ? e.message : e));
          throw e;
        });
      }

      // Import from history (last N)
      try {
        var max = 15;
        if (!hist.length) {
          Lampa.SettingsApi.addParam({
            component: ctx.componentId,
            param: { name: 'bl_backup_hist_empty', type: 'static', default: true },
            field: { name: 'No exports yet', description: '' }
          });
        } else {
          for (var hi = 0; hi < hist.length && hi < max; hi++) {
            (function (it, idx) {
              var label = fmtTs(it.ts) + ' | ' + String(it.provider || '') + ' | ' + shortId(it.id) + (it.keyHint ? (' | ' + String(it.keyHint || '')) : '');
              Lampa.SettingsApi.addParam({
                component: ctx.componentId,
                param: { name: 'bl_backup_hist_' + String(idx) + '_' + String(it.ts || idx), type: 'static', default: true },
                field: { name: label, description: 'OK — import (uses key input; unsafeKey if saved).' },
                onRender: function (item) {
                  try {
                    if (!item || !item.on) return;
                    item.on('hover:enter', function () {
                      var mode = String(sGet('bl_backup_import_mode_v1', 'merge') || 'merge');
                      var pass = String(sGet('bl_backup_key_input_v1', '') || '').trim();
                      if (!pass && it.unsafeKey) pass = String(it.unsafeKey || '').trim();
                      ctx.runAsync('Importing...', function () { return doImport(String(it.provider || cfg.provider || 'paste_rs'), String(it.id || ''), pass, mode); });
                    });
                  } catch (_) { }
                }
              });
            })(hist[hi] || {}, hi);
          }
        }
      } catch (_) { }

      // Import manual (id/url)
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_import_id_v1', type: 'input', values: '', default: '', placeholder: 'id-or-url' },
          field: { name: 'Import: paste id/url', description: '' }
        });
      } catch (_) { }

      // Import button
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_import_btn', type: 'button' },
          field: { name: 'Import', description: 'Скачивает → расшифровывает → применяет → reload.' },
          onChange: function () {
            var provider = String(sGet('bl_backup_provider_v1', cfg.provider || 'paste_rs') || cfg.provider || 'paste_rs');
            var id = String(sGet('bl_backup_import_id_v1', '') || '').trim();
            var pass = String(sGet('bl_backup_key_input_v1', '') || '').trim();
            var mode = String(sGet('bl_backup_import_mode_v1', 'merge') || 'merge');

            if (!id) {
              ctx.notify('[[BlackLampa]] Set paste id/url');
              return;
            }
            if (!pass) {
              ctx.notify('[[BlackLampa]] Set encryption key');
              return;
            }

            ctx.runAsync('Importing...', function () { return doImport(provider, id, pass, mode); });
          }
        });
      } catch (_) { }

      // Clear history
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_history_clear_btn', type: 'button' },
          field: { name: 'Clear history', description: 'Удаляет только history экспортов. Настройки BlackLampa не трогает.' },
          onChange: function () {
            try { if (BL.Backup.history && BL.Backup.history.clear) BL.Backup.history.clear(); } catch (_) { }
            ctx.notify('[[BlackLampa]] History cleared');
            ctx.refresh();
          }
        });
      } catch (_) { }
    } catch (_) { }
  }

})();
