(function () {
  'use strict';

  var BL = window.BL = window.BL || {};
  BL.ExtFilters = BL.ExtFilters || {};

  var API = BL.ExtFilters;
  if (API.__blExtFiltersLoaded) return;
  API.__blExtFiltersLoaded = true;

  var LS_KEY = 'bl_ext_filters';

  var KEY_ORIG_RATING = '__bl_ext_filters_v1_orig_rating';
  var KEY_PATCHED_RATING = '__bl_ext_filters_v1_patched_rating';
  var KEY_ORIG_SORT = '__bl_ext_filters_v1_orig_sort';
  var KEY_PATCHED_SORT = '__bl_ext_filters_v1_patched_sort';

  var KEY_SELECT_WRAPPED = '__bl_ext_filters_v1_select_wrapped';
  var KEY_REQ_HOOKED = '__bl_ext_filters_v1_req_hooked';

  function safe(fn, fallback) { try { return fn(); } catch (_) { return fallback; } }

  function lsGet(k) { try { return localStorage.getItem(String(k)); } catch (_) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(String(k), String(v)); } catch (_) { } }

  function isEnabled() {
    var v = lsGet(LS_KEY);
    if (v === null || v === undefined) return false;
    v = String(v || '').trim();
    return v === '1' || v.toLowerCase() === 'true' || v.toLowerCase() === 'on';
  }

  function t(str) {
    str = String(str || '');
    try { if (window.Lampa && Lampa.Lang && typeof Lampa.Lang.translate === 'function') return String(Lampa.Lang.translate(str) || str); } catch (_) { }
    return str;
  }

  function setHidden(obj, key, val) {
    try { Object.defineProperty(obj, key, { configurable: true, enumerable: false, writable: true, value: val }); }
    catch (_) { try { obj[key] = val; } catch (_) { } }
  }

  function getHidden(obj, key) {
    try { return obj ? obj[key] : undefined; } catch (_) { return undefined; }
  }

  function looksLikeRatingItems(items) {
    if (!Array.isArray(items) || !items.length) return false;
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      // Use the original upstream typo "voite" as a fingerprint (reduces false positives).
      if (it && it.voite !== undefined) return true;
    }
    return false;
  }

  function looksLikeSortItems(items) {
    if (!Array.isArray(items) || !items.length) return false;
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      if (it && it.sort !== undefined) {
        var s = String(it.sort || '');
        // Fingerprint: "now_playing" exists in the built-in CUB sort list.
        if (s.indexOf('now_playing') !== -1) return true;
      }
    }
    return false;
  }

  function findIndexByStart(items, val) {
    var sv = String(val);
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      if (!it || it.start === undefined) continue;
      if (String(it.start) === sv) return i;
    }
    return -1;
  }

  function findIndexByVoite(items, val) {
    var sv = String(val);
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      if (!it || it.voite === undefined) continue;
      if (String(it.voite) === sv) return i;
    }
    return -1;
  }

  function hasStart(items, val) { return findIndexByStart(items, val) >= 0; }
  function hasVoite(items, val) { return findIndexByVoite(items, val) >= 0; }

  function mkRatingFrom(val) {
    return { title: t('#{filter_rating_from} ' + String(val)), start: val };
  }

  function mkRatingRange(a, b) {
    return { title: t('#{filter_rating_from} ' + String(a) + ' #{filter_rating_to} ' + String(b)), voite: String(a) + '-' + String(b) };
  }

  function patchRatingItems(items) {
    if (!Array.isArray(items) || !items.length) return;
    if (getHidden(items, KEY_PATCHED_RATING)) return;

    if (!getHidden(items, KEY_ORIG_RATING)) {
      setHidden(items, KEY_ORIG_RATING, items.slice());
    }

    // Add thresholds: 9, 8.5, 7.5, 7.2, 7 (keep existing ones)
    var i8 = findIndexByStart(items, 8);
    var i6 = findIndexByStart(items, 6);

    var before8 = [];
    if (!hasStart(items, 9)) before8.push(mkRatingFrom(9));
    if (!hasStart(items, 8.5)) before8.push(mkRatingFrom(8.5));

    if (before8.length) {
      var at = i8 >= 0 ? i8 : 1;
      items.splice.apply(items, [at, 0].concat(before8));
    }

    // Recompute after splice
    i6 = findIndexByStart(items, 6);
    var between8and6 = [];
    if (!hasStart(items, 7.5)) between8and6.push(mkRatingFrom(7.5));
    if (!hasStart(items, 7.2)) between8and6.push(mkRatingFrom(7.2));
    if (!hasStart(items, 7)) between8and6.push(mkRatingFrom(7));

    if (between8and6.length) {
      var at2 = i6 >= 0 ? i6 : items.length;
      items.splice.apply(items, [at2, 0].concat(between8and6));
    }

    // Add ranges: 7-8, 7-9 (8-9 already exists in upstream)
    var i68 = findIndexByVoite(items, '6-8');
    var ranges = [];
    if (!hasVoite(items, '7-8')) ranges.push(mkRatingRange(7, 8));
    if (!hasVoite(items, '7-9')) ranges.push(mkRatingRange(7, 9));

    if (ranges.length) {
      var at3 = i68 >= 0 ? i68 + 1 : items.length;
      items.splice.apply(items, [at3, 0].concat(ranges));
    }

    setHidden(items, KEY_PATCHED_RATING, true);
  }

  function unpatchRatingItems(items) {
    if (!Array.isArray(items) || !items.length) return;
    if (!getHidden(items, KEY_PATCHED_RATING)) return;
    var orig = getHidden(items, KEY_ORIG_RATING);
    if (Array.isArray(orig) && orig.length) {
      items.length = 0;
      for (var i = 0; i < orig.length; i++) items.push(orig[i]);
    }
    setHidden(items, KEY_PATCHED_RATING, false);
  }

  function mkSortItem(title, sort) {
    return { title: title, sort: sort };
  }

  function hasBlSort(items, id) {
    id = String(id || '');
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      if (!it || !it.sort) continue;
      if (String(it.sort).indexOf('__bl_sort=' + id) !== -1) return true;
    }
    return false;
  }

  function patchSortItems(items) {
    if (!Array.isArray(items) || !items.length) return;
    if (getHidden(items, KEY_PATCHED_SORT)) return;

    if (!getHidden(items, KEY_ORIG_SORT)) {
      setHidden(items, KEY_ORIG_SORT, items.slice());
    }

    // Only for CUB-like sort menu: extend with client-safe sort markers.
    var titleRating = t('#{title_rating}');
    var titleYear = t('#{title_year}');

    var add = [];
    if (!hasBlSort(items, 'rating_desc')) add.push(mkSortItem(titleRating + ' ↓', 'latest&results=100&__bl_sort=rating_desc'));
    if (!hasBlSort(items, 'rating_asc')) add.push(mkSortItem(titleRating + ' ↑', 'latest&results=100&__bl_sort=rating_asc'));
    if (!hasBlSort(items, 'year_desc')) add.push(mkSortItem(titleYear + ' ↓', 'latest&results=100&__bl_sort=year_desc'));
    if (!hasBlSort(items, 'year_asc')) add.push(mkSortItem(titleYear + ' ↑', 'latest&results=100&__bl_sort=year_asc'));

    if (add.length) {
      var at = 1;
      items.splice.apply(items, [at, 0].concat(add));
    }

    setHidden(items, KEY_PATCHED_SORT, true);
  }

  function unpatchSortItems(items) {
    if (!Array.isArray(items) || !items.length) return;
    if (!getHidden(items, KEY_PATCHED_SORT)) return;
    var orig = getHidden(items, KEY_ORIG_SORT);
    if (Array.isArray(orig) && orig.length) {
      items.length = 0;
      for (var i = 0; i < orig.length; i++) items.push(orig[i]);
    }
    setHidden(items, KEY_PATCHED_SORT, false);
  }

  function walkAndPatch(items, enable) {
    if (!Array.isArray(items)) return;

    // direct list
    if (looksLikeRatingItems(items)) enable ? patchRatingItems(items) : unpatchRatingItems(items);
    if (looksLikeSortItems(items)) enable ? patchSortItems(items) : unpatchSortItems(items);

    // one level down
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      if (!it || !it.items || !Array.isArray(it.items)) continue;
      if (looksLikeRatingItems(it.items)) enable ? patchRatingItems(it.items) : unpatchRatingItems(it.items);
      if (looksLikeSortItems(it.items)) enable ? patchSortItems(it.items) : unpatchSortItems(it.items);
    }
  }

  function parseQuery(url) {
    var out = {};
    try {
      var q = '';
      var qi = String(url || '').indexOf('?');
      if (qi >= 0) q = String(url || '').slice(qi + 1);
      if (!q) return out;
      var hash = q.indexOf('#');
      if (hash >= 0) q = q.slice(0, hash);
      var parts = q.split('&');
      for (var i = 0; i < parts.length; i++) {
        var kv = parts[i];
        if (!kv) continue;
        var eq = kv.indexOf('=');
        var k = eq >= 0 ? kv.slice(0, eq) : kv;
        var v = eq >= 0 ? kv.slice(eq + 1) : '';
        try { k = decodeURIComponent(k); } catch (_) { }
        try { v = decodeURIComponent(v); } catch (_) { }
        if (!k) continue;
        out[String(k)] = String(v);
      }
    } catch (_) { }
    return out;
  }

  function replaceQueryParam(url, key, val) {
    try {
      url = String(url || '');
      key = String(key || '');
      val = String(val === undefined || val === null ? '' : val);
      if (!key) return url;
      var qi = url.indexOf('?');
      if (qi < 0) return url + '?' + encodeURIComponent(key) + '=' + encodeURIComponent(val);
      var base = url.slice(0, qi);
      var q = url.slice(qi + 1);
      var hash = '';
      var hi = q.indexOf('#');
      if (hi >= 0) { hash = q.slice(hi); q = q.slice(0, hi); }
      var parts = q ? q.split('&') : [];
      var next = [];
      var found = false;
      for (var i = 0; i < parts.length; i++) {
        var p = parts[i];
        if (!p) continue;
        var eq = p.indexOf('=');
        var k = eq >= 0 ? p.slice(0, eq) : p;
        try { k = decodeURIComponent(k); } catch (_) { }
        if (String(k) === key) {
          found = true;
          next.push(encodeURIComponent(key) + '=' + encodeURIComponent(val));
        } else {
          next.push(p);
        }
      }
      if (!found) next.push(encodeURIComponent(key) + '=' + encodeURIComponent(val));
      return base + '?' + next.join('&') + hash;
    } catch (_) {
      return String(url || '');
    }
  }

  function ensureQueryParam(url, key, val) {
    try {
      var q = parseQuery(url);
      if (q && q[key] !== undefined) return url;
      return replaceQueryParam(url, key, val);
    } catch (_) {
      return String(url || '');
    }
  }

  function rewriteCubVoteDecimals(url) {
    try {
      url = String(url || '');
      if (url.indexOf('://tmdb.') === -1) return url;
      var q = parseQuery(url);
      if (!q || !q.vote) return url;
      var vote = String(q.vote || '');
      if (vote.indexOf('-') !== -1) return url; // range is already supported only as ints
      if (vote.indexOf('.') === -1) return url; // int threshold is supported natively

      var f = parseFloat(vote);
      if (isNaN(f)) return url;
      var flo = Math.floor(f);
      if (!isFinite(flo)) return url;

      url = replaceQueryParam(url, 'vote', String(flo));
      url = ensureQueryParam(url, '__bl_vote_min', String(f));
      url = ensureQueryParam(url, 'results', '100');
      return url;
    } catch (_) {
      return String(url || '');
    }
  }

  function getVote(item) {
    try {
      var v = item && (item.vote_average !== undefined ? item.vote_average : item.vote);
      if (v === undefined || v === null) return null;
      if (typeof v === 'string') v = parseFloat(v);
      if (typeof v !== 'number' || isNaN(v) || !isFinite(v)) return null;
      if (v <= 0) return null;
      return v;
    } catch (_) {
      return null;
    }
  }

  function getYear(item) {
    try {
      var d = '';
      try { d = String(item.release_date || item.first_air_date || ''); } catch (_) { d = ''; }
      if (d && d.length >= 4) {
        var y = parseInt(d.slice(0, 4), 10);
        if (!isNaN(y) && isFinite(y)) return y;
      }
    } catch (_) { }
    return null;
  }

  function sortResults(results, mode) {
    mode = String(mode || '');
    if (!Array.isArray(results) || results.length < 2) return;

    try {
      results.sort(function (a, b) {
        if (!a && !b) return 0;
        if (!a) return 1;
        if (!b) return -1;

        if (mode === 'rating_desc' || mode === 'rating_asc') {
          var va = getVote(a);
          var vb = getVote(b);
          if (va === null && vb === null) return 0;
          if (va === null) return 1;
          if (vb === null) return -1;
          if (va !== vb) return mode === 'rating_asc' ? (va - vb) : (vb - va);
          var ca = safe(function () { return Number(a.vote_count || 0); }, 0);
          var cb = safe(function () { return Number(b.vote_count || 0); }, 0);
          if (ca !== cb) return mode === 'rating_asc' ? (ca - cb) : (cb - ca);
          return 0;
        }

        if (mode === 'year_desc' || mode === 'year_asc') {
          var ya = getYear(a);
          var yb = getYear(b);
          if (ya === null && yb === null) return 0;
          if (ya === null) return 1;
          if (yb === null) return -1;
          if (ya !== yb) return mode === 'year_asc' ? (ya - yb) : (yb - ya);
          var va2 = getVote(a);
          var vb2 = getVote(b);
          if (va2 === null && vb2 === null) return 0;
          if (va2 === null) return 1;
          if (vb2 === null) return -1;
          if (va2 !== vb2) return vb2 - va2; // keep higher-rated first within same year
          return 0;
        }

        return 0;
      });
    } catch (_) { }
  }

  function filterByVoteMin(results, minStr) {
    if (!Array.isArray(results) || !results.length) return;
    var min = parseFloat(String(minStr || ''));
    if (isNaN(min) || !isFinite(min)) return;

    var out = [];
    for (var i = 0; i < results.length; i++) {
      var it = results[i];
      var v = getVote(it);
      if (v === null) continue;
      if (v >= min) out.push(it);
    }
    results.length = 0;
    for (var j = 0; j < out.length; j++) results.push(out[j]);
  }

  function installRequestHooksOnce() {
    if (getHidden(API, KEY_REQ_HOOKED)) return true;
    if (!window.Lampa || !Lampa.Listener) return false;
    try {
      if (Lampa.Listener && typeof Lampa.Listener.follow === 'function') {
        // Rewrite URL before request
        Lampa.Listener.follow('request', function (e) {
          try {
            if (!isEnabled()) return;
            if (!e || !e.params) return;
            if (!e.params.url) return;
            e.params.url = rewriteCubVoteDecimals(e.params.url);
          } catch (_) { }
        });

        // Post-process response
        Lampa.Listener.follow('request_secuses', function (e) {
          try {
            if (!isEnabled()) return;
            if (!e || !e.params || !e.params.url || !e.data) return;
            var url = String(e.params.url || '');
            if (url.indexOf('://tmdb.') === -1) return;
            var q = parseQuery(url);
            if (!q) return;

            var data = e.data;
            if (!data || !data.results || !Array.isArray(data.results)) return;

            if (q.__bl_vote_min !== undefined) filterByVoteMin(data.results, q.__bl_vote_min);
            if (q.__bl_sort !== undefined) sortResults(data.results, q.__bl_sort);
          } catch (_) { }
        });

        setHidden(API, KEY_REQ_HOOKED, true);
        return true;
      }
    } catch (_) { }
    return false;
  }

  function installSelectHookOnce() {
    if (getHidden(API, KEY_SELECT_WRAPPED)) return true;
    if (!window.Lampa || !Lampa.Select || typeof Lampa.Select.show !== 'function') return false;

    try {
      var orig = Lampa.Select.show;
      if (orig && orig.__blExtFiltersWrapped) {
        setHidden(API, KEY_SELECT_WRAPPED, true);
        return true;
      }

      function wrapped() {
        try {
          var opts = arguments && arguments.length ? arguments[0] : null;
          if (opts && opts.items) walkAndPatch(opts.items, isEnabled());
        } catch (_) { }
        return orig.apply(this, arguments);
      }
      setHidden(wrapped, '__blExtFiltersWrapped', true);
      Lampa.Select.show = wrapped;

      setHidden(API, KEY_SELECT_WRAPPED, true);
      return true;
    } catch (_) {
      return false;
    }
  }

  function waitLampaAndInstall() {
    var tries = 0;
    var max = 160; // 40s @ 250ms
    var tmr = setInterval(function () {
      tries++;
      var ok = false;
      try {
        ok = !!(window.Lampa && Lampa.Listener && Lampa.Select && typeof Lampa.Select.show === 'function');
      } catch (_) { ok = false; }
      if (ok) {
        clearInterval(tmr);
        safe(installRequestHooksOnce);
        safe(installSelectHookOnce);
        return;
      }
      if (tries >= max) {
        clearInterval(tmr);
      }
    }, 250);
  }

  API.isEnabled = isEnabled;
  API.setEnabled = function (on) { lsSet(LS_KEY, on ? '1' : '0'); };
  API.refresh = function () { safe(installRequestHooksOnce); safe(installSelectHookOnce); };

  waitLampaAndInstall();
})();
