(function () {
  'use strict';

  var BL = window.BL = window.BL || {};
  BL.MenuRegistry = BL.MenuRegistry || {};

  var API = BL.MenuRegistry;
  if (API.__blMenuRegistryLoaded) return;
  API.__blMenuRegistryLoaded = true;

  function safe(fn, fallback) { try { return fn(); } catch (_) { return fallback; } }
  function isPlainObject(x) { try { return !!x && typeof x === 'object' && !Array.isArray(x); } catch (_) { return false; } }

  // ---------------------------------------------------------------------------
  // Registry
  // ---------------------------------------------------------------------------
  var routes = API.routes = API.routes || {};
  var rootItems = API.rootItems = API.rootItems || [];

  function has(route) {
    try { return !!routes[String(route || '')]; } catch (_) { return false; }
  }

  function get(route) {
    try { return routes[String(route || '')] || null; } catch (_) { return null; }
  }

  function t(ctx, key, vars) {
    try { return ctx && typeof ctx.t === 'function' ? String(ctx.t(String(key || ''), vars) || '') : String(key || ''); } catch (_) { return String(key || ''); }
  }

  function addRoute(def) {
    try {
      if (!def || !def.id) return;
      routes[String(def.id)] = def;
    } catch (_) { }
  }

  function addRootItem(item) {
    try { rootItems.push(item); } catch (_) { }
  }

  API.has = has;
  API.get = get;

  API.defaultFocus = function (route, payload, ctx) {
    try {
      var def = get(route);
      if (def && typeof def.defaultFocus === 'function') return def.defaultFocus(ctx || null, payload || null) || 0;
    } catch (_) { }
    return 0;
  };

  API.build = function (route, ctx) {
    route = String(route || 'root');
    var def = get(route);
    if (!def) def = get('root');
    if (!def) return;

    // Guard (optional)
    try {
      if (def.guard && typeof def.guard === 'function') {
        if (!def.guard(ctx || null)) def = get('root');
      }
    } catch (_) { def = get('root'); }

    if (!def) return;
    try { def.build && def.build(ctx || null); } catch (_) { }
  };

  // ---------------------------------------------------------------------------
  // Root menu items (single source of truth)
  // ---------------------------------------------------------------------------
  addRootItem({
    id: 'plugins',
    route: 'plugins',
    param: { name: 'bl_pi_root_plugins', type: 'static', default: true },
    titleKey: 'menu.root.plugins.title',
    descKey: 'menu.root.plugins.desc'
  });

  addRootItem({
    id: 'network',
    route: 'network',
    param: { name: 'bl_pi_root_network', type: 'static', default: true },
    titleKey: 'menu.root.network.title',
    descKey: 'menu.root.network.desc'
  });

  addRootItem({
    id: 'ua',
    route: 'ua',
    param: { name: 'bl_pi_root_ua', type: 'static', default: true },
    titleKey: 'menu.root.ua.title',
    descKey: 'menu.root.ua.desc'
  });

  addRootItem({
    id: 'logs',
    route: 'logs',
    param: { name: 'bl_pi_root_logs', type: 'static', default: true },
    titleKey: 'menu.root.logs.title',
    descKey: 'menu.root.logs.desc'
  });

  addRootItem({
    id: 'backup',
    route: 'backup',
    param: { name: 'bl_pi_root_backup', type: 'static', default: true },
    titleKey: 'menu.root.backup.title',
    descKey: 'menu.root.backup.desc'
  });

  addRootItem({
    id: 'filescan',
    route: null,
    param: { name: 'bl_pi_root_filesystem_scan', type: 'static', default: true },
    titleKey: 'menu.root.filescan.title',
    descKey: 'menu.root.filescan.desc',
    onEnter: function (ctx) {
      safe(function () {
        if (window.BL && BL.FileScanner && typeof BL.FileScanner.open === 'function') BL.FileScanner.open();
      });
    }
  });

  addRootItem({
    id: 'query_params',
    route: 'query_params',
    param: { name: 'bl_pi_root_query_params', type: 'static', default: true },
    titleKey: 'menu.root.query_params.title',
    descKey: 'menu.root.query_params.desc'
  });

  addRootItem({
    id: 'danger',
    route: 'danger',
    param: { name: 'bl_pi_root_danger', type: 'static', default: true },
    titleKey: 'menu.root.danger.title',
    descKey: 'menu.root.danger.desc'
  });

  addRootItem({
    id: 'ui',
    route: 'ui',
    param: { name: 'bl_pi_root_ui', type: 'static', default: true },
    titleKey: 'menu.root.ui.title',
    descKey: 'menu.root.ui.desc'
  });

  addRootItem({
    id: 'status',
    route: 'status',
    param: { name: 'bl_pi_root_status', type: 'static', values: '', default: '' },
    titleKey: 'menu.root.status.title',
    descKey: '',
    onRender: function (ctx, item) {
      try {
        if (!window.$ || !item) return;
        var ss = null;
        try { ss = (ctx && ctx.opts && typeof ctx.opts.statusStrings === 'function') ? (ctx.opts.statusStrings() || null) : null; } catch (_) { ss = null; }

        var raw = ss && ss.raw ? String(ss.raw) : '';
        var help = ss && ss.help ? String(ss.help) : '';
        var short = ss && ss.short ? String(ss.short) : '';

        var $d = item.find('.settings-param__descr');
        if (!$d.length) {
          item.append('<div class="settings-param__descr"></div>');
          $d = item.find('.settings-param__descr');
        }
        $d.empty();
        if (short) $d.append($('<div></div>').text(short));
        if (raw && raw !== short) $d.append($('<div></div>').text(raw));
        if (help) $d.append($('<div style="opacity:0.85;margin-top:0.35em;white-space:pre-wrap;"></div>').text(help));
      } catch (_) { }
    }
  });

  function buildRootScreen(ctx) {
    try {
      if (!window.Lampa || !Lampa.SettingsApi || !Lampa.SettingsApi.addParam) return;

      for (var i = 0; i < rootItems.length; i++) {
        (function (it, idx) {
          try {
            var fieldName = it.titleKey ? t(ctx, it.titleKey) : String(it.name || '');
            var fieldDesc = it.descKey ? t(ctx, it.descKey) : String(it.description || '');

            Lampa.SettingsApi.addParam({
              component: ctx.componentId,
              param: it.param || { name: 'bl_root_' + String(it.id || idx), type: 'static', default: true },
              field: { name: fieldName, description: fieldDesc },
              onRender: function (item) {
                try {
                  if (item && item.on) {
                    item.on('hover:enter', function () {
                      try {
                        if (typeof it.onEnter === 'function') return it.onEnter(ctx, idx, item);
                        if (it.route) return ctx.push(String(it.route), it.payload || null, 0, idx);
                      } catch (_) { }
                    });
                  }
                } catch (_) { }

                try { if (typeof it.onRender === 'function') it.onRender(ctx, item, idx); } catch (_) { }
              }
            });
          } catch (_) { }
        })(rootItems[i], i);
      }
    } catch (_) { }
  }

  // ---------------------------------------------------------------------------
  // Non-installer screens (kept mostly as-is, but routed through registry/core)
  // ---------------------------------------------------------------------------
  function buildNetworkMenuScreen(ctx) {
    try {
      Lampa.SettingsApi.addParam({
        component: ctx.componentId,
        param: { name: 'bl_pi_network_blocklist', type: 'static', default: true },
        field: { name: 'Blocklist', description: 'URL Blocklist (BlackLampa network policy).' },
        onRender: function (item) {
          try { if (item && item.on) item.on('hover:enter', function () { ctx.push('blocklist', null, 0, 0); }); } catch (_) { }
        }
      });

      Lampa.SettingsApi.addParam({
        component: ctx.componentId,
        param: { name: 'bl_pi_network_status', type: 'static', default: true },
        field: { name: 'Interceptors Status', description: 'Coverage matrix + lastBlocked.' },
        onRender: function (item) {
          try { if (item && item.on) item.on('hover:enter', function () { ctx.push('network_status', null, 0, 1); }); } catch (_) { }
        }
      });

      Lampa.SettingsApi.addParam({
        component: ctx.componentId,
        param: { name: 'bl_pi_network_jsqp', type: 'static', default: true },
        field: { name: 'JS query rewrite (JSQP)', description: 'Подмена/удаление GET параметров (origin/logged/reset) в запросах на *.js' },
        onRender: function (item) {
          try { if (item && item.on) item.on('hover:enter', function () { ctx.push('jsqp', null, 0, 2); }); } catch (_) { }
        }
      });
    } catch (_) { }
  }

  function buildNetworkStatusScreen(ctx) {
    try {
      function yn(v) { return v ? 'yes' : 'no'; }
      function shortStr(s, max) {
        s = String(s || '');
        max = Number(max || 160);
        if (s.length <= max) return s;
        return s.slice(0, max - 1) + '…';
      }

      var st = null;
      try { st = (window.BL && BL.PolicyNetwork && typeof BL.PolicyNetwork.getStatus === 'function') ? BL.PolicyNetwork.getStatus() : null; } catch (_) { st = null; }
      st = st || {};
      var m = st.interceptors || {};

      var keys = [
        { k: 'fetch', title: 'fetch' },
        { k: 'xhr', title: 'xhr' },
        { k: 'ws', title: 'ws' },
        { k: 'eventsource', title: 'eventsource' },
        { k: 'beacon', title: 'beacon' },
        { k: 'iframe_src', title: 'iframe/src' },
        { k: 'img_src', title: 'img/src' },
        { k: 'script_src', title: 'script/src' },
        { k: 'link_href', title: 'link/href' },
        { k: 'open', title: 'window.open' },
        { k: 'location', title: 'location redirects' }
      ];

      for (var i = 0; i < keys.length; i++) {
        (function (row) {
          try {
            var active = false;
            try { active = !!m[row.k]; } catch (_) { active = false; }
            var line = yn(active);
            Lampa.SettingsApi.addParam({
              component: ctx.componentId,
              param: { name: 'bl_pi_net_matrix_' + row.k, type: 'static', values: line, default: line },
              field: { name: row.title, description: line }
            });
          } catch (_) { }
        })(keys[i]);
      }

      var lb = st.lastBlocked || null;
      var lbLine = '—';
      var ruleLine = '—';
      try {
        if (lb && lb.url) {
          lbLine = String(lb.channel || '') + ' | ' + shortStr(String(lb.url || ''), 220);
          ruleLine = String(lb.ruleId || '') + (lb.ruleLabel ? (' | ' + shortStr(String(lb.ruleLabel || ''), 160)) : '');
        }
      } catch (_) { }

      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_net_last_blocked', type: 'static', values: lbLine, default: lbLine },
          field: { name: 'Last blocked', description: lbLine }
        });
      } catch (_) { }

      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_net_rule', type: 'static', values: ruleLine, default: ruleLine },
          field: { name: 'Rule matched', description: ruleLine }
        });
      } catch (_) { }
    } catch (_) { }
  }

  function buildLogsMenuScreen(ctx) {
    try {
      // 0) View logs
      Lampa.SettingsApi.addParam({
        component: ctx.componentId,
        param: { name: 'bl_pi_logs_view', type: 'static', default: true },
        field: { name: 'View logs', description: 'Открывает viewer логов BlackLampa.' },
        onRender: function (item) {
          try {
            if (!item || !item.on) return;
            item.on('hover:enter', function () {
              try { if (window.BL && BL.Log && typeof BL.Log.openViewer === 'function') BL.Log.openViewer(); } catch (_) { }
            });
          } catch (_) { }
        }
      });

      // 1) Log mode
      Lampa.SettingsApi.addParam({
        component: ctx.componentId,
        param: { name: 'bl_pi_logs_mode', type: 'static', default: true },
        field: { name: 'Log mode', description: 'silent / popup (не влияет на блокировки).' },
        onRender: function (item) {
          try { if (item && item.on) item.on('hover:enter', function () { ctx.push('logging', null, 0, 1); }); } catch (_) { }
        }
      });
    } catch (_) { }
  }

  function buildQueryParamsScreen(ctx) {
    try {
      var raw = '';
      try { raw = String(location.search || ''); } catch (_) { raw = ''; }

      try {
        var head = raw ? raw : '(empty)';
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_qp_raw', type: 'static', values: head, default: head },
          field: { name: 'location.search', description: head }
        });
      } catch (_) { }

      var qs = raw;
      if (qs && qs.charAt(0) === '?') qs = qs.slice(1);
      if (!qs) return;

      var parts = [];
      try { parts = qs.split('&'); } catch (_) { parts = []; }
      for (var i = 0; i < parts.length; i++) {
        try {
          var kv = String(parts[i] || '');
          if (!kv) continue;
          var eq = kv.indexOf('=');
          var k = eq >= 0 ? kv.slice(0, eq) : kv;
          var v = eq >= 0 ? kv.slice(eq + 1) : '';
          try { k = decodeURIComponent(k); } catch (_) { }
          try { v = decodeURIComponent(v); } catch (_) { }
          k = String(k || '').trim();
          if (!k) continue;
          v = String(v || '');

          Lampa.SettingsApi.addParam({
            component: ctx.componentId,
            param: { name: 'bl_pi_qp_' + String(i), type: 'static', values: v, default: v },
            field: { name: k, description: v || '(empty)' }
          });
        } catch (_) { }
      }
    } catch (_) { }
  }

  function buildStatusScreen(ctx) {
    try {
      function yn(v) { return v ? 'yes' : 'no'; }
      function shortStr(s, max) {
        s = String(s || '');
        max = Number(max || 220);
        if (s.length <= max) return s;
        return s.slice(0, max - 1) + '…';
      }

      // Lampa version/build (best-effort)
      try {
        var av = '';
        var cv = '';
        try { av = (window.Lampa && Lampa.Manifest && Lampa.Manifest.app_version) ? String(Lampa.Manifest.app_version) : ''; } catch (_) { av = ''; }
        try { cv = (window.Lampa && Lampa.Manifest && Lampa.Manifest.css_version) ? String(Lampa.Manifest.css_version) : ''; } catch (_) { cv = ''; }
        var ver = (av ? ('app ' + av) : '') + (cv ? (' | css ' + cv) : '');
        if (ver) {
          Lampa.SettingsApi.addParam({
            component: ctx.componentId,
            param: { name: 'bl_pi_status_lampa_ver', type: 'static', values: ver, default: ver },
            field: { name: 'Lampa version', description: ver }
          });
        }
      } catch (_) { }

      // AutoPlugin status strings (legacy)
      try {
        var ss = null;
        try { ss = (ctx && ctx.opts && typeof ctx.opts.statusStrings === 'function') ? (ctx.opts.statusStrings() || null) : null; } catch (_) { ss = null; }
        var raw = ss && ss.raw ? String(ss.raw) : '';
        var help = ss && ss.help ? String(ss.help) : '';
        var short = ss && ss.short ? String(ss.short) : '';
        var sline = short || raw || '';
        if (sline) {
          Lampa.SettingsApi.addParam({
            component: ctx.componentId,
            param: { name: 'bl_pi_status_autoplugin', type: 'static', values: sline, default: sline },
            field: { name: 'AutoPlugin', description: sline }
          });
        }
        if (help) {
          Lampa.SettingsApi.addParam({
            component: ctx.componentId,
            param: { name: 'bl_pi_status_help', type: 'static', values: help, default: help },
            field: { name: 'Help', description: help }
          });
        }
      } catch (_) { }

      // Log mode
      try {
        var mode = 'silent';
        try { mode = (window.BL && BL.Log && typeof BL.Log.getMode === 'function') ? String(BL.Log.getMode() || 'silent') : 'silent'; } catch (_) { mode = 'silent'; }
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_status_log_mode', type: 'static', values: mode, default: mode },
          field: { name: 'Log mode', description: mode }
        });
      } catch (_) { }

      // UA preset
      try {
        var uaId = '';
        var uaTitle = '';
        try { uaId = (window.BL && BL.UA && typeof BL.UA.getSelectedPresetId === 'function') ? String(BL.UA.getSelectedPresetId() || '') : ''; } catch (_) { uaId = ''; }
        try { uaTitle = (window.BL && BL.UA && BL.UA.effective && BL.UA.effective.title) ? String(BL.UA.effective.title || '') : ''; } catch (_) { uaTitle = ''; }
        var uaLine = (uaId ? uaId : 'unknown') + (uaTitle ? (' — ' + uaTitle) : '');
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_status_ua', type: 'static', values: uaLine, default: uaLine },
          field: { name: 'UA preset', description: uaLine }
        });
      } catch (_) { }

      // Network interceptors summary
      try {
        var st = null;
        try { st = (window.BL && BL.PolicyNetwork && typeof BL.PolicyNetwork.getStatus === 'function') ? BL.PolicyNetwork.getStatus() : null; } catch (_) { st = null; }
        st = st || {};
        var m = st.interceptors || {};
        var sum = 'fetch=' + yn(!!m.fetch)
          + ' xhr=' + yn(!!m.xhr)
          + ' ws=' + yn(!!m.ws)
          + ' iframe=' + yn(!!m.iframe_src);
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_status_net', type: 'static', values: sum, default: sum },
          field: { name: 'Network', description: sum }
        });
      } catch (_) { }

      // FS concurrency (config)
      try {
        var conc = '';
        try { conc = window.localStorage ? String(localStorage.getItem('bl_fs_concurrency_v1') || '') : ''; } catch (_) { conc = ''; }
        if (!conc) conc = '(default)';
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_status_fs_conc', type: 'static', values: conc, default: conc },
          field: { name: 'FS concurrency', description: 'bl_fs_concurrency_v1 = ' + conc }
        });
      } catch (_) { }

      // Effective UA string (short)
      try {
        var effUa = '';
        try { effUa = String(navigator && navigator.userAgent ? navigator.userAgent : '') || ''; } catch (_) { effUa = ''; }
        effUa = shortStr(effUa, 180);
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_status_ua_eff', type: 'static', values: effUa, default: effUa },
          field: { name: 'UA effective', description: effUa }
        });
      } catch (_) { }
    } catch (_) { }
  }

  function buildUiScreen(ctx) {
    try {
      Lampa.SettingsApi.addParam({
        component: ctx.componentId,
        param: { name: 'bl_ext_filters', type: 'select', values: { 0: 'OFF', 1: 'ON' }, default: 0 },
        field: {
          name: t(ctx, 'ui.extfilters.title'),
          description: t(ctx, 'ui.extfilters.desc')
        },
        onChange: function () {
          try {
            if (window.BL && BL.ModuleExtFilters && typeof BL.ModuleExtFilters.refresh === 'function') return BL.ModuleExtFilters.refresh();
            if (window.BL && BL.ExtFilters && typeof BL.ExtFilters.refresh === 'function') return BL.ExtFilters.refresh();
          } catch (_) { }
        }
      });
    } catch (_) { }
  }

  function buildLoggingScreen(ctx) {
    try {
      var mode = 'silent';
      try { mode = (window.BL && BL.Log && typeof BL.Log.getMode === 'function') ? String(BL.Log.getMode() || 'silent') : 'silent'; } catch (_) { mode = 'silent'; }
      if (mode !== 'popup') mode = 'silent';

      // 0) No popup (default)
      Lampa.SettingsApi.addParam({
        component: ctx.componentId,
        param: { name: 'bl_pi_logging_silent', type: 'static', default: true },
        field: { name: (mode === 'silent' ? '✓ No popup (default)' : 'No popup (default)'), description: 'Popup не открывается автоматически. Логи всё равно пишутся в память.' },
        onRender: function (item) {
          try {
            if (!item || !item.on) return;
            item.on('hover:enter', function () {
              try { if (window.BL && BL.Log && typeof BL.Log.setMode === 'function') BL.Log.setMode('silent'); } catch (_) { }
              try { ctx.refresh(); } catch (_) { }
            });
          } catch (_) { }
        }
      });

      // 1) Auto popup
      Lampa.SettingsApi.addParam({
        component: ctx.componentId,
        param: { name: 'bl_pi_logging_popup', type: 'static', default: true },
        field: { name: (mode === 'popup' ? '✓ Auto popup' : 'Auto popup'), description: 'Разрешает авто-показ popup при логах/ошибках.' },
        onRender: function (item) {
          try {
            if (!item || !item.on) return;
            item.on('hover:enter', function () {
              try { if (window.BL && BL.Log && typeof BL.Log.setMode === 'function') BL.Log.setMode('popup'); } catch (_) { }
              try { ctx.refresh(); } catch (_) { }
            });
          } catch (_) { }
        }
      });
    } catch (_) { }
  }

  function buildJsqpScreen(ctx) {
    try {
      var DEF = {
        bl_jsqp_enabled: '1',
        bl_jsqp_force: '0',
        bl_jsqp_origin_mode: 'remove',
        bl_jsqp_origin_value: '',
        bl_jsqp_logged_mode: 'remove',
        bl_jsqp_logged_value: 'false',
        bl_jsqp_reset_mode: 'remove',
        bl_jsqp_reset_value: '0',
        bl_jsqp_match: '\\\\.js(\\\\?|$)',
        bl_jsqp_params: 'origin,logged,reset'
      };

      function sGet(k, fallback) {
        var v = null;
        try { if (window.Lampa && Lampa.Storage && Lampa.Storage.get) v = Lampa.Storage.get(String(k)); } catch (_) { v = null; }
        if (v === undefined || v === null) {
          try { if (window.localStorage) v = localStorage.getItem(String(k)); } catch (_) { v = null; }
        }
        if (v === undefined || v === null) return fallback;
        return v;
      }

      function sSet(k, v) {
        try { if (window.Lampa && Lampa.Storage && Lampa.Storage.set) return Lampa.Storage.set(String(k), String(v)); } catch (_) { }
        try { if (window.localStorage) localStorage.setItem(String(k), String(v)); } catch (_) { }
      }

      function sEnsure(k, def) {
        try {
          var v = sGet(k, null);
          if (v === undefined || v === null) sSet(k, def);
        } catch (_) { }
      }

      // Seed defaults
      try {
        sEnsure('bl_jsqp_enabled', DEF.bl_jsqp_enabled);
        sEnsure('bl_jsqp_force', DEF.bl_jsqp_force);
        sEnsure('bl_jsqp_origin_mode', DEF.bl_jsqp_origin_mode);
        sEnsure('bl_jsqp_origin_value', DEF.bl_jsqp_origin_value);
        sEnsure('bl_jsqp_logged_mode', DEF.bl_jsqp_logged_mode);
        sEnsure('bl_jsqp_logged_value', DEF.bl_jsqp_logged_value);
        sEnsure('bl_jsqp_reset_mode', DEF.bl_jsqp_reset_mode);
        sEnsure('bl_jsqp_reset_value', DEF.bl_jsqp_reset_value);
        sEnsure('bl_jsqp_match', DEF.bl_jsqp_match);
        sEnsure('bl_jsqp_params', DEF.bl_jsqp_params);
      } catch (_) { }

      var resetMode = String(sGet('bl_jsqp_reset_mode', DEF.bl_jsqp_reset_mode) || DEF.bl_jsqp_reset_mode);
      resetMode = resetMode.toLowerCase();
      if (resetMode !== 'remove' && resetMode !== 'set' && resetMode !== 'random') resetMode = DEF.bl_jsqp_reset_mode;

      function shortStr(s, max) {
        s = String(s || '');
        max = Number(max || 220);
        if (s.length <= max) return s;
        return s.slice(0, max - 1) + '…';
      }

      // Info
      try {
        var info = 'Подмена/удаление GET параметров (origin/logged/reset) в запросах на *.js';
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_jsqp_info', type: 'static', values: info, default: info },
          field: { name: 'JS query params', description: info }
        });
      } catch (_) { }

      // Enabled
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_jsqp_enabled', type: 'select', values: { 0: 'OFF', 1: 'ON' }, default: 1 },
          field: { name: 'Enabled', description: 'Включить переписывание URL для *.js.' }
        });
      } catch (_) { }

      // Force apply
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_jsqp_force', type: 'select', values: { 0: 'OFF', 1: 'ON' }, default: 0 },
          field: { name: 'Force apply', description: 'Переписывать даже если params отсутствуют в URL.' }
        });
      } catch (_) { }

      // Match regex
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_jsqp_match', type: 'input', values: '', default: DEF.bl_jsqp_match, placeholder: DEF.bl_jsqp_match },
          field: { name: 'Match regex', description: 'RegExp (string) для матчинга URL. По умолчанию: \\\\.js(\\\\?|$)' }
        });
      } catch (_) { }

      // Params list
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_jsqp_params', type: 'input', values: '', default: DEF.bl_jsqp_params, placeholder: DEF.bl_jsqp_params },
          field: { name: 'Params list (csv)', description: 'Список управляемых параметров (origin,logged,reset).' }
        });
      } catch (_) { }

      // Origin mode
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_jsqp_origin_mode', type: 'select', values: { remove: 'remove', set: 'set', set_b64: 'set (base64)' }, default: DEF.bl_jsqp_origin_mode },
          field: { name: 'Origin mode', description: 'remove => удалить | set => задать значение | set (base64) => btoa(utf8).' }
        });
      } catch (_) { }

      // Origin value
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_jsqp_origin_value', type: 'input', values: '', default: DEF.bl_jsqp_origin_value, placeholder: 'example.com' },
          field: { name: 'Origin value', description: 'Если origin_mode=set: ставим как есть (без base64).' }
        });
      } catch (_) { }

      // Logged mode
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_jsqp_logged_mode', type: 'select', values: { remove: 'remove', set: 'set' }, default: DEF.bl_jsqp_logged_mode },
          field: { name: 'Logged mode', description: 'remove => удалить | set => задать значение.' }
        });
      } catch (_) { }

      // Logged value
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_jsqp_logged_value', type: 'input', values: '', default: DEF.bl_jsqp_logged_value, placeholder: 'false' },
          field: { name: 'Logged value', description: 'Если logged_mode=set (строка, например 0/false).' }
        });
      } catch (_) { }

      // Reset mode
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_jsqp_reset_mode', type: 'select', values: { remove: 'remove', set: 'set', random: 'random' }, default: DEF.bl_jsqp_reset_mode },
          field: { name: 'Reset mode', description: 'remove => удалить | set => value | random => Math.random().' },
          onChange: function () {
            ctx.go('jsqp', null, ctx.getFocusIndex());
          }
        });
      } catch (_) { }

      // Reset value (hidden when random)
      if (resetMode !== 'random') {
        try {
          Lampa.SettingsApi.addParam({
            component: ctx.componentId,
            param: { name: 'bl_jsqp_reset_value', type: 'input', values: '', default: DEF.bl_jsqp_reset_value, placeholder: '0' },
            field: { name: 'Reset value', description: 'Если reset_mode=set.' }
          });
        } catch (_) { }
      }

      // Test URL (optional)
      try {
        var ex = '/x.js?logged=false&reset=0.123&origin=YmxhY2tsYW1wYS5naXRodWIuaW8%3D';
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_jsqp_test_url', type: 'input', values: '', default: ex, placeholder: ex },
          field: { name: 'Test URL', description: 'URL для теста (опционально).' }
        });
      } catch (_) { }

      // Test rewrite
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_jsqp_test', type: 'button' },
          field: { name: 'Test rewrite', description: 'Показывает результат BL.Net.rewriteJsQuery().' },
          onChange: function () {
            try {
              var sample = '';
              try { sample = String(sGet('bl_jsqp_test_url', '') || ''); } catch (_) { sample = ''; }
              sample = String(sample || '').trim();
              if (!sample) sample = String(location.href || '');

              var after = sample;
              try {
                if (window.BL && BL.Net && typeof BL.Net.rewriteJsQuery === 'function') after = BL.Net.rewriteJsQuery(sample);
              } catch (_) { after = sample; }

              if (String(after) === String(sample)) ctx.notify('[[BlackLampa]] JSQP: no change');
              else ctx.notify('[[BlackLampa]] JSQP: ' + shortStr(after, 240));
            } catch (_) { }
          }
        });
      } catch (_) { }

      // Reset to defaults
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_jsqp_reset_defaults', type: 'button' },
          field: { name: 'Reset to defaults', description: 'Сбрасывает настройки JSQP.' },
          onChange: function () {
            try {
              sSet('bl_jsqp_enabled', DEF.bl_jsqp_enabled);
              sSet('bl_jsqp_force', DEF.bl_jsqp_force);
              sSet('bl_jsqp_origin_mode', DEF.bl_jsqp_origin_mode);
              sSet('bl_jsqp_origin_value', DEF.bl_jsqp_origin_value);
              sSet('bl_jsqp_logged_mode', DEF.bl_jsqp_logged_mode);
              sSet('bl_jsqp_logged_value', DEF.bl_jsqp_logged_value);
              sSet('bl_jsqp_reset_mode', DEF.bl_jsqp_reset_mode);
              sSet('bl_jsqp_reset_value', DEF.bl_jsqp_reset_value);
              sSet('bl_jsqp_match', DEF.bl_jsqp_match);
              sSet('bl_jsqp_params', DEF.bl_jsqp_params);
            } catch (_) { }
            ctx.notify('[[BlackLampa]] JSQP: defaults restored');
            ctx.go('jsqp', null, ctx.getFocusIndex());
          }
        });
      } catch (_) { }
    } catch (_) { }
  }

  function buildUaScreen(ctx) {
    try {
      Lampa.SettingsApi.addParam({
        component: ctx.componentId,
        param: { name: 'bl_pi_ua_presets', type: 'static', default: true },
        field: { name: 'Presets', description: 'Выбор пресета UA. Включает Original(system).' },
        onRender: function (item) {
          try { if (item && item.on) item.on('hover:enter', function () { ctx.push('ua_presets', null, 0, 0); }); } catch (_) { }
        }
      });

      Lampa.SettingsApi.addParam({
        component: ctx.componentId,
        param: { name: 'bl_pi_ua_effective', type: 'static', default: true },
        field: { name: 'Effective (now)', description: 'Показывает текущий effective UA и поддержку подмены заголовка.' },
        onRender: function (item) {
          try { if (item && item.on) item.on('hover:enter', function () { ctx.push('ua_effective', null, 0, 1); }); } catch (_) { }
        }
      });
    } catch (_) { }
  }

  function buildUaPresetsScreen(ctx) {
    try {
      function shortStr(s, max) {
        s = String(s || '');
        max = Number(max || 120);
        if (s.length <= max) return s;
        return s.slice(0, max - 1) + '…';
      }

      var uaApi = null;
      try { uaApi = (window.BL && BL.UA) ? BL.UA : null; } catch (_) { uaApi = null; }
      try { if (uaApi && uaApi.ensureOriginalStored) uaApi.ensureOriginalStored(); } catch (_) { }

      var selectedId = '';
      try { if (uaApi && typeof uaApi.getSelectedPresetId === 'function') selectedId = String(uaApi.getSelectedPresetId() || ''); } catch (_) { selectedId = ''; }
      if (!selectedId) {
        try { selectedId = window.localStorage ? String(localStorage.getItem('bl_ua_preset_id_v1') || '') : ''; } catch (_) { selectedId = ''; }
      }

      var presets = [];
      try { if (uaApi && typeof uaApi.getPresets === 'function') presets = uaApi.getPresets() || []; } catch (_) { presets = []; }
      if (!Array.isArray(presets)) presets = [];

      for (var i = 0; i < presets.length; i++) {
        (function (p) {
          try {
            if (!p || !p.id) return;
            var id = String(p.id || '');
            var title = String(p.title || id);
            var desc = String(p.desc || '');
            var ua = String(p.ua || '');
            var isSel = (id === selectedId);

            var d = desc || '';
            if (ua) d = d ? (d + '\n' + shortStr(ua, 120)) : shortStr(ua, 120);
            if (!d) d = ' ';

            Lampa.SettingsApi.addParam({
              component: ctx.componentId,
              param: { name: 'bl_pi_ua_preset_' + id, type: 'static', default: true },
              field: { name: (isSel ? '✓ ' : '') + title, description: d },
              onRender: function (item) {
                try {
                  if (!item || !item.on) return;
                  item.on('hover:enter', function () {
                    try {
                      if (uaApi && typeof uaApi.setSelectedPresetId === 'function') uaApi.setSelectedPresetId(id);
                      else if (window.localStorage) localStorage.setItem('bl_ua_preset_id_v1', id);
                    } catch (_) { }

                    try { if (uaApi && typeof uaApi.apply === 'function') uaApi.apply(); } catch (_) { }
                    ctx.notify('[[BlackLampa]] UA preset: ' + title);
                    ctx.refresh();
                  });
                } catch (_) { }
              }
            });
          } catch (_) { }
        })(presets[i]);
      }

      // Custom UA input (only when custom selected)
      if (String(selectedId || '') === 'custom') {
        var curCustom = '';
        try { if (uaApi && typeof uaApi.getCustomUa === 'function') curCustom = String(uaApi.getCustomUa() || ''); } catch (_) { curCustom = ''; }

        try {
          Lampa.SettingsApi.addParam({
            component: ctx.componentId,
            param: { name: 'bl_ua_custom_v1', type: 'input', values: '', default: curCustom, placeholder: 'Mozilla/5.0 ...' },
            field: { name: 'Custom UA', description: 'Используется только когда выбран preset=Custom.' },
            onChange: function () {
              try {
                var v = '';
                try { v = (window.Lampa && Lampa.Storage && Lampa.Storage.get) ? String(Lampa.Storage.get('bl_ua_custom_v1') || '') : ''; } catch (_) { v = ''; }
                v = String(v || '').trim();

                if (uaApi && typeof uaApi.setCustomUa === 'function') uaApi.setCustomUa(v);
                else try { if (window.localStorage) localStorage.setItem('bl_ua_custom_v1', v); } catch (_) { }

                try { if (uaApi && typeof uaApi.apply === 'function') uaApi.apply(); } catch (_) { }
                ctx.notify('[[BlackLampa]] UA: custom applied');
              } catch (_) { }
            }
          });
        } catch (_) { }
      }
    } catch (_) { }
  }

  function buildUaEffectiveScreen(ctx) {
    try {
      var uaApi = null;
      try { uaApi = (window.BL && BL.UA) ? BL.UA : null; } catch (_) { uaApi = null; }

      var original = '';
      try { if (uaApi && typeof uaApi.getOriginalUa === 'function') original = String(uaApi.getOriginalUa() || ''); } catch (_) { original = ''; }
      if (!original) {
        try { original = window.localStorage ? String(localStorage.getItem('bl_ua_original_v1') || '') : ''; } catch (_) { original = ''; }
      }

      var selectedId = '';
      var selectedTitle = '';
      try { if (uaApi && typeof uaApi.getSelectedPresetId === 'function') selectedId = String(uaApi.getSelectedPresetId() || ''); } catch (_) { selectedId = ''; }
      try { if (uaApi && uaApi.effective && uaApi.effective.title) selectedTitle = String(uaApi.effective.title || ''); } catch (_) { selectedTitle = ''; }

      var effUa = '';
      try { effUa = String(navigator && navigator.userAgent ? navigator.userAgent : '') || ''; } catch (_) { effUa = ''; }

      // Header override support (best-effort + cached)
      try { if (uaApi && typeof uaApi.ensureHeaderSupport === 'function') uaApi.ensureHeaderSupport(); } catch (_) { }
      var hdrFlag = '';
      try { hdrFlag = window.localStorage ? String(localStorage.getItem('bl_ua_header_override_supported_v1') || '') : ''; } catch (_) { hdrFlag = ''; }
      var hdrLine = (hdrFlag === '0') ? 'UA header override: unsupported' : 'UA header override: supported';

      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_ua_eff_orig', type: 'static', values: original, default: original },
          field: { name: 'Original UA (stored)', description: original }
        });
      } catch (_) { }

      try {
        var selLine = (selectedId ? selectedId : 'unknown') + (selectedTitle ? (' — ' + selectedTitle) : '');
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_ua_eff_sel', type: 'static', values: selLine, default: selLine },
          field: { name: 'Selected preset', description: selLine }
        });
      } catch (_) { }

      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_ua_eff_now', type: 'static', values: effUa, default: effUa },
          field: { name: 'Effective navigator.userAgent', description: effUa }
        });
      } catch (_) { }

      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_ua_eff_hdr', type: 'static', values: hdrLine, default: hdrLine },
          field: { name: 'UA header override', description: hdrLine }
        });
      } catch (_) { }

      try {
        var note = 'Some channels cannot override UA headers in browser environment.';
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_ua_eff_note', type: 'static', values: note, default: note },
          field: { name: 'Note', description: note }
        });
      } catch (_) { }
    } catch (_) { }
  }

  function buildBackupScreen(ctx) {
    try {
      if (!window.BL || !BL.Backup) {
        var na = 'BL.Backup missing (bl.backup.js not loaded).';
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_na', type: 'static', values: na, default: na },
          field: { name: 'Backup / Transfer', description: na }
        });
        return;
      }

      var CFG_KEY = 'bl_backup_cfg_v1';

      function normPrefixes(arr) {
        var out = [];
        try {
          if (!Array.isArray(arr)) arr = [];
          for (var i = 0; i < arr.length; i++) {
            var p = String(arr[i] || '').trim();
            if (p) out.push(p);
          }
        } catch (_) { }
        if (!out.length) out = ['bl_'];
        return out;
      }

      function parsePrefixesString(str) {
        var out = [];
        try {
          var parts = String(str || '').split(',');
          for (var i = 0; i < parts.length; i++) {
            var p = String(parts[i] || '').trim();
            if (p) out.push(p);
          }
        } catch (_) { }
        if (!out.length) out = ['bl_'];
        return out;
      }

      function loadCfgSafe() {
        var def = { prefixes: ['bl_'], provider: 'paste_rs', keyHint: '', unsafe_store_key: 0 };
        var raw = safe(function () { return window.localStorage ? localStorage.getItem(CFG_KEY) : ''; }, '');
        if (!raw) return def;
        var obj = safe(function () { return JSON.parse(String(raw || '')); }, null);
        if (!isPlainObject(obj)) return def;
        def.prefixes = normPrefixes(obj.prefixes);
        def.provider = String(obj.provider || def.provider) || def.provider;
        def.keyHint = String(obj.keyHint || '');
        def.unsafe_store_key = (String(obj.unsafe_store_key || '0') === '1') ? 1 : 0;
        return def;
      }

      function saveCfgSafe(cfg) {
        try {
          if (!window.localStorage) return;
          localStorage.setItem(CFG_KEY, JSON.stringify(cfg || {}));
        } catch (_) { }
      }

      function sGet(k, fallback) {
        var v = fallback;
        try { if (window.Lampa && Lampa.Storage && Lampa.Storage.get) v = Lampa.Storage.get(String(k)); } catch (_) { v = fallback; }
        if (typeof v === 'undefined' || v === null) return fallback;
        return v;
      }

      function pad2(n) { n = Number(n || 0); return (n < 10 ? '0' : '') + String(n); }

      function fmtTs(ms) {
        try {
          var d = new Date(Number(ms) || 0);
          return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
        } catch (_) { return ''; }
      }

      function shortId(idOrUrl) {
        var s = String(idOrUrl || '');
        try {
          if (s.indexOf('://') > 0) {
            var u = new URL(s, location.href);
            var p = String(u.pathname || '');
            var segs = p.split('/');
            var last = segs[segs.length - 1] || '';
            var prev = segs.length > 1 ? (segs[segs.length - 2] || '') : '';
            var id = last || prev || '';
            return id || s;
          }
        } catch (_) { }
        return s;
      }

      function syncCfgFromUi(currentCfg) {
        var provider = String(sGet('bl_backup_provider_v1', currentCfg.provider) || currentCfg.provider);
        var keyHint = String(sGet('bl_backup_key_hint_v1', currentCfg.keyHint) || '');
        var unsafe = String(sGet('bl_backup_unsafe_store_key_v1', currentCfg.unsafe_store_key ? '1' : '0') || '0');
        var prefixesStr = String(sGet('bl_backup_prefixes_v1', (currentCfg.prefixes || ['bl_']).join(',')) || '');
        var prefixes = parsePrefixesString(prefixesStr);
        var cfg = { prefixes: prefixes, provider: provider, keyHint: keyHint, unsafe_store_key: (unsafe === '1') ? 1 : 0 };
        saveCfgSafe(cfg);
        return cfg;
      }

      var cfg = loadCfgSafe();
      saveCfgSafe(cfg);

      var hist = [];
      try { hist = (BL.Backup.history && BL.Backup.history.list) ? (BL.Backup.history.list() || []) : []; } catch (_) { hist = []; }
      if (!Array.isArray(hist)) hist = [];

      // Status
      try {
        var st = 'history: ' + String(hist.length) + ' | prefixes: ' + String((cfg.prefixes || ['bl_']).join(','));
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_status', type: 'static', values: st, default: st },
          field: { name: 'Backup / Transfer', description: 'Экспорт/импорт настроек BlackLampa (localStorage) + шифрование + history.' }
        });
      } catch (_) { }

      // Encryption key (input)
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_key_input_v1', type: 'input', values: '', default: '', placeholder: 'Enter key / PIN' },
          field: { name: 'Encryption key', description: 'Используется для AES-GCM. Не хранится в history по умолчанию.' }
        });
      } catch (_) { }

      // Key label / hint (input)
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_key_hint_v1', type: 'input', values: '', default: String(cfg.keyHint || ''), placeholder: 'home-tv / phone / test' },
          field: { name: 'Key label / hint', description: '' },
          onChange: function () { cfg = syncCfgFromUi(cfg); }
        });
      } catch (_) { }

      // Prefixes (input)
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_prefixes_v1', type: 'input', values: '', default: String((cfg.prefixes || ['bl_']).join(',')), placeholder: 'bl_' },
          field: { name: 'Prefixes', description: 'Какие ключи localStorage экспортировать (prefix list, через ,).' },
          onChange: function () { cfg = syncCfgFromUi(cfg); }
        });
      } catch (_) { }

      // Provider (select)
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_provider_v1', type: 'select', values: { paste_rs: 'paste.rs', dpaste_org: 'dpaste.org' }, default: String(cfg.provider || 'paste_rs') },
          field: { name: 'Provider', description: '' },
          onChange: function () { cfg = syncCfgFromUi(cfg); }
        });
      } catch (_) { }

      // Unsafe: store key in history (select)
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_unsafe_store_key_v1', type: 'select', values: { 0: 'OFF (safe)', 1: 'ON (unsafe)' }, default: (cfg.unsafe_store_key ? 1 : 0) },
          field: { name: 'Unsafe: store key in history', description: 'Если ON — ключ сохранится вместе с paste ID в history.' },
          onChange: function () { cfg = syncCfgFromUi(cfg); }
        });
      } catch (_) { }

      function keyHash(pass) {
        try {
          if (window.BL && BL.Backup && typeof BL.Backup.__keyHash === 'function') return BL.Backup.__keyHash(String(pass || ''));
        } catch (_) { }
        return Promise.resolve('');
      }

      // Export button
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_export_btn', type: 'button' },
          field: { name: 'Export', description: 'Шифрует конфиг и загружает в выбранный provider. Запись добавляется в history.' },
          onChange: function () {
            var pass = String(sGet('bl_backup_key_input_v1', '') || '').trim();
            if (!pass) {
              ctx.notify('[[BlackLampa]] Set encryption key');
              return;
            }
            ctx.runAsync('Exporting...', function () {
              cfg = syncCfgFromUi(cfg);

              var cfgObj = null;
              try { cfgObj = BL.Backup.collectConfig(); } catch (_) { cfgObj = { meta: {}, data: {} }; }

              var provider = String(cfg.provider || 'paste_rs');
              var hint = String(cfg.keyHint || '');
              var unsafeFlag = !!cfg.unsafe_store_key;

              return BL.Backup.encrypt(cfgObj, pass).then(function (payloadStr) {
                return BL.Backup.upload(provider, payloadStr).then(function (up) {
                  var storedId = '';
                  try { storedId = (up && up.url) ? String(up.url || '') : String(up && up.id ? up.id : ''); } catch (_) { storedId = ''; }
                  if (!storedId) storedId = String(up && up.id ? up.id : '');

                  return keyHash(pass).then(function (kh) {
                    try {
                      var item = {
                        ts: Date.now(),
                        provider: provider,
                        id: storedId,
                        bytes: payloadStr.length,
                        schema: 1,
                        keyHint: hint,
                        keyHash: String(kh || ''),
                        note: ''
                      };
                      if (unsafeFlag) item.unsafeKey = pass;
                      if (BL.Backup.history && BL.Backup.history.add) BL.Backup.history.add(item);
                    } catch (_) { }
                    ctx.notify('[[BlackLampa]] Exported: ' + shortId(storedId));
                  });
                });
              }).catch(function (e) {
                if (e && e.code === 'CORS') ctx.notify('[[BlackLampa]] Provider blocked by CORS on this device');
                else ctx.notify('[[BlackLampa]] Export failed: ' + String((e && e.message) ? e.message : e));
                throw e;
              });
            });
          }
        });
      } catch (_) { }

      // Import mode
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_import_mode_v1', type: 'select', values: { merge: 'Merge (default)', replace: 'Replace' }, default: 'merge' },
          field: { name: 'Import mode', description: 'Merge — обновляет/добавляет ключи. Replace — очищает BL-prefix ключи и импортирует.' }
        });
      } catch (_) { }

      function doImport(provider, idOrUrl, pass, mode) {
        provider = String(provider || '');
        idOrUrl = String(idOrUrl || '').trim();
        pass = String(pass || '').trim();
        mode = (mode === 'replace') ? 'replace' : 'merge';

        if (!idOrUrl) {
          ctx.notify('[[BlackLampa]] Set paste id/url');
          return Promise.reject(new Error('no id'));
        }
        if (!pass) {
          ctx.notify('[[BlackLampa]] Set encryption key');
          return Promise.reject(new Error('no key'));
        }

        return BL.Backup.download(provider, idOrUrl).then(function (payloadStr) {
          return BL.Backup.decrypt(payloadStr, pass);
        }).then(function (cfgObj) {
          BL.Backup.applyConfig(cfgObj, mode);
          ctx.notify('[[BlackLampa]] Imported, reloading…');
          setTimeout(function () { try { location.reload(); } catch (_) { } }, 0);
        }).catch(function (e) {
          if (e && e.code === 'CORS') ctx.notify('[[BlackLampa]] Provider blocked by CORS on this device');
          else ctx.notify('[[BlackLampa]] Import failed: ' + String((e && e.message) ? e.message : e));
          throw e;
        });
      }

      // Import from history (last N)
      try {
        var max = 15;
        if (!hist.length) {
          Lampa.SettingsApi.addParam({
            component: ctx.componentId,
            param: { name: 'bl_backup_hist_empty', type: 'static', default: true },
            field: { name: 'No exports yet', description: '' }
          });
        } else {
          for (var hi = 0; hi < hist.length && hi < max; hi++) {
            (function (it, idx) {
              var label = fmtTs(it.ts) + ' | ' + String(it.provider || '') + ' | ' + shortId(it.id) + (it.keyHint ? (' | ' + String(it.keyHint || '')) : '');
              Lampa.SettingsApi.addParam({
                component: ctx.componentId,
                param: { name: 'bl_backup_hist_' + String(idx) + '_' + String(it.ts || idx), type: 'static', default: true },
                field: { name: label, description: 'OK — import (uses key input; unsafeKey if saved).' },
                onRender: function (item) {
                  try {
                    if (!item || !item.on) return;
                    item.on('hover:enter', function () {
                      var mode = String(sGet('bl_backup_import_mode_v1', 'merge') || 'merge');
                      var pass = String(sGet('bl_backup_key_input_v1', '') || '').trim();
                      if (!pass && it.unsafeKey) pass = String(it.unsafeKey || '').trim();
                      ctx.runAsync('Importing...', function () { return doImport(String(it.provider || cfg.provider || 'paste_rs'), String(it.id || ''), pass, mode); });
                    });
                  } catch (_) { }
                }
              });
            })(hist[hi] || {}, hi);
          }
        }
      } catch (_) { }

      // Import manual (id/url)
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_import_id_v1', type: 'input', values: '', default: '', placeholder: 'id-or-url' },
          field: { name: 'Import: paste id/url', description: '' }
        });
      } catch (_) { }

      // Import button
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_import_btn', type: 'button' },
          field: { name: 'Import', description: 'Скачивает → расшифровывает → применяет → reload.' },
          onChange: function () {
            var provider = String(sGet('bl_backup_provider_v1', cfg.provider || 'paste_rs') || cfg.provider || 'paste_rs');
            var id = String(sGet('bl_backup_import_id_v1', '') || '').trim();
            var pass = String(sGet('bl_backup_key_input_v1', '') || '').trim();
            var mode = String(sGet('bl_backup_import_mode_v1', 'merge') || 'merge');

            if (!id) {
              ctx.notify('[[BlackLampa]] Set paste id/url');
              return;
            }
            if (!pass) {
              ctx.notify('[[BlackLampa]] Set encryption key');
              return;
            }

            ctx.runAsync('Importing...', function () { return doImport(provider, id, pass, mode); });
          }
        });
      } catch (_) { }

      // Clear history
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_backup_history_clear_btn', type: 'button' },
          field: { name: 'Clear history', description: 'Удаляет только history экспортов. Настройки BlackLampa не трогает.' },
          onChange: function () {
            try { if (BL.Backup.history && BL.Backup.history.clear) BL.Backup.history.clear(); } catch (_) { }
            ctx.notify('[[BlackLampa]] History cleared');
            ctx.refresh();
          }
        });
      } catch (_) { }
    } catch (_) { }
  }

  // ============================================================================
  // URL Blocklist UI
  // ============================================================================
  var BL_RULE_ADD_PATTERN = 'bl_net_rule_add_pattern';
  var BL_RULE_ADD_TYPE = 'bl_net_rule_add_type';
  var BL_RULE_ADD_CT = 'bl_net_rule_add_ct';
  var BL_RULE_ADD_BODY = 'bl_net_rule_add_body';

  function getBlocklistApi() {
    try {
      if (window.BL && BL.PolicyNetwork && BL.PolicyNetwork.blocklist) return BL.PolicyNetwork.blocklist;
    } catch (_) { }
    return null;
  }

  function ensureStatusDot(item) {
    try {
      if (!window.$ || !item) return null;
      if (item.find('.settings-param__status').length === 0) item.append('<div class="settings-param__status one"></div>');
      return item.find('.settings-param__status');
    } catch (_) {
      return null;
    }
  }

  function setStatusDotBlocklist($st, enabled) {
    try {
      if (!$st || !$st.length) return;
      if (enabled) $st.css('background-color', '').removeClass('error').addClass('active');
      else $st.removeClass('active error').css('background-color', 'rgba(255,255,255,0.35)');
    } catch (_) { }
  }

  function buildBlocklistScreen(ctx) {
    try {
      var api2 = getBlocklistApi();

      // Built-in
      Lampa.SettingsApi.addParam({
        component: ctx.componentId,
        param: { name: 'bl_pi_blocklist_builtin', type: 'static', default: true },
        field: { name: 'Built-in', description: 'Встроенные правила (readonly).' },
        onRender: function (item) {
          try { if (item && item.on) item.on('hover:enter', function () { ctx.push('blocklist_builtin', null, 0, 0); }); } catch (_) { }
        }
      });

      // User rules
      Lampa.SettingsApi.addParam({
        component: ctx.componentId,
        param: { name: 'bl_pi_blocklist_user', type: 'static', default: true },
        field: { name: 'User rules', description: 'Пользовательские правила (persist).' },
        onRender: function (item) {
          try { if (item && item.on) item.on('hover:enter', function () { ctx.push('blocklist_user', null, 0, 1); }); } catch (_) { }
        }
      });

      // Add rule
      Lampa.SettingsApi.addParam({
        component: ctx.componentId,
        param: { name: 'bl_pi_blocklist_add', type: 'static', default: true },
        field: { name: 'Add rule', description: 'Добавить правило блокировки.' },
        onRender: function (item) {
          try { if (item && item.on) item.on('hover:enter', function () { ctx.push('blocklist_add', null, 0, 2); }); } catch (_) { }
        }
      });

      // Status
      try {
        var enabled = false;
        try { enabled = !!(api2 && api2.enabled); } catch (_) { enabled = false; }
        var line = enabled ? 'enabled' : 'disabled';
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_blocklist_status', type: 'static', values: line, default: line },
          field: { name: 'Status', description: line },
          onRender: function (item) {
            try {
              var $st = ensureStatusDot(item);
              setStatusDotBlocklist($st, enabled);
            } catch (_) { }
          }
        });
      } catch (_) { }
    } catch (_) { }
  }

  function buildBlocklistBuiltinScreen(ctx) {
    try {
      var api2 = getBlocklistApi();
      if (!api2 || !api2.builtin || !Array.isArray(api2.builtin.rules)) {
        var na = 'No built-in rules';
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_blocklist_builtin_na', type: 'static', values: na, default: na },
          field: { name: 'Built-in', description: na }
        });
        return;
      }

      for (var i = 0; i < api2.builtin.rules.length; i++) {
        (function (r, idx) {
          try {
            var pat = String(r && r.pattern ? r.pattern : '');
            if (!pat) return;
            var type = String(r && r.type ? r.type : 'simple');
            var enabled = (r && r.enabled !== undefined) ? !!r.enabled : true;

            var line = (enabled ? '✓ ' : '') + pat;
            var desc = 'type=' + type + (enabled ? '' : ' | disabled');

            Lampa.SettingsApi.addParam({
              component: ctx.componentId,
              param: { name: 'bl_pi_blocklist_builtin_' + String(idx), type: 'static', default: true },
              field: { name: line, description: desc }
            });
          } catch (_) { }
        })(api2.builtin.rules[i], i);
      }
    } catch (_) { }
  }

  function buildBlocklistUserRulesScreen(ctx) {
    try {
      var api2 = getBlocklistApi();
      if (!api2 || !api2.user || !Array.isArray(api2.user.rules)) {
        var na = 'No user rules';
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_blocklist_user_na', type: 'static', values: na, default: na },
          field: { name: 'User rules', description: na }
        });
        return;
      }

      if (!api2.user.rules.length) {
        var none = '—';
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_blocklist_user_empty', type: 'static', values: none, default: none },
          field: { name: 'User rules', description: 'No rules' }
        });
        return;
      }

      for (var i = 0; i < api2.user.rules.length; i++) {
        (function (r, idx) {
          try {
            if (!r || !r.id) return;
            var id = String(r.id || '');
            var pat = String(r.pattern || '');
            var enabled = (r.enabled !== undefined) ? !!r.enabled : true;
            var type = String(r.type || 'simple');

            var name = (enabled ? '✓ ' : '') + (pat || id);
            var desc = 'type=' + type + ' | id=' + id;

            Lampa.SettingsApi.addParam({
              component: ctx.componentId,
              param: { name: 'bl_pi_blocklist_user_' + id, type: 'static', default: true },
              field: { name: name, description: desc },
              onRender: function (item) {
                try {
                  if (!item || !item.on) return;
                  item.on('hover:enter', function () {
                    ctx.push('blocklist_user_detail', { id: id }, 0, idx);
                  });
                } catch (_) { }
              }
            });
          } catch (_) { }
        })(api2.user.rules[i], i);
      }
    } catch (_) { }
  }

  function buildBlocklistUserRuleDetailScreen(ctx) {
    try {
      var id = '';
      try { id = (ctx && ctx.payload && ctx.payload.id) ? String(ctx.payload.id) : ''; } catch (_) { id = ''; }

      var api2 = getBlocklistApi();
      if (!id || !api2 || !api2.user || !Array.isArray(api2.user.rules)) {
        var na = 'Rule not found';
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_blocklist_user_detail_na', type: 'static', values: na, default: na },
          field: { name: 'User rule', description: na }
        });
        return;
      }

      var rule = null;
      for (var i = 0; i < api2.user.rules.length; i++) {
        var r = api2.user.rules[i];
        if (r && String(r.id || '') === id) { rule = r; break; }
      }
      if (!rule) {
        var na2 = 'Rule not found';
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_blocklist_user_detail_na2', type: 'static', values: na2, default: na2 },
          field: { name: 'User rule', description: na2 }
        });
        return;
      }

      var pat = String(rule.pattern || '');
      var type = String(rule.type || 'simple');
      var enabled = (rule.enabled !== undefined) ? !!rule.enabled : true;
      var head = (pat ? pat : id) + ' | type=' + type + (enabled ? '' : ' | disabled');

      // Info
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_blocklist_user_detail_info', type: 'static', values: head, default: head },
          field: { name: 'Rule', description: head }
        });
      } catch (_) { }

      // Toggle enabled
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_blocklist_user_detail_toggle', type: 'button' },
          field: { name: enabled ? 'Disable' : 'Enable', description: 'Включить/выключить правило.' },
          onChange: function () {
            ctx.runOnce('Rule', (enabled ? 'Disable rule?' : 'Enable rule?') + '\n\n' + pat, function () {
              try {
                if (api2 && api2.user && typeof api2.user.toggle === 'function') api2.user.toggle(id, !enabled);
              } catch (_) { }
            });
          }
        });
      } catch (_) { }

      // Remove rule
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_blocklist_user_detail_remove', type: 'button' },
          field: { name: 'Remove', description: 'Удалить правило.' },
          onChange: function () {
            ctx.runOnce('Rule', 'Remove rule?\n\n' + pat, function () {
              try {
                if (api2 && api2.user && typeof api2.user.remove === 'function') api2.user.remove(id);
              } catch (_) { }
              ctx.go('blocklist_user', null, 0);
            });
          }
        });
      } catch (_) { }

      // Advanced info (optional)
      if (type === 'advanced') {
        try {
          var adv = rule.advanced || {};
          var ct = String(adv.contentType || '');
          var bm = String(adv.bodyMode || '');
          var line = 'contentType=' + (ct || 'any') + ' | bodyMode=' + (bm || 'any');
          Lampa.SettingsApi.addParam({
            component: ctx.componentId,
            param: { name: 'bl_pi_blocklist_user_detail_adv', type: 'static', values: line, default: line },
            field: { name: 'Advanced', description: line }
          });
        } catch (_) { }
      }
    } catch (_) { }
  }

  function buildBlocklistAddScreen(ctx) {
    try {
      // Pattern
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: BL_RULE_ADD_PATTERN, type: 'input', values: '', default: '', placeholder: 'example.com | /regexp/' },
          field: { name: 'Pattern', description: 'URL / domain / regexp.' }
        });
      } catch (_) { }

      // Type
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: BL_RULE_ADD_TYPE, type: 'select', values: { simple: 'Простое (simple)', advanced: 'Расширенное (advanced)' }, default: 'simple' },
          field: { name: 'Type', description: '' },
          onChange: function () {
            ctx.go('blocklist_add', null, ctx.getFocusIndex());
          }
        });
      } catch (_) { }

      var type = 'simple';
      try { type = (window.Lampa && Lampa.Storage && Lampa.Storage.get) ? String(Lampa.Storage.get(BL_RULE_ADD_TYPE) || 'simple') : 'simple'; } catch (_) { type = 'simple'; }
      if (type !== 'advanced') type = 'simple';

      if (type === 'advanced') {
        // Content-Type filter
        try {
          Lampa.SettingsApi.addParam({
            component: ctx.componentId,
            param: { name: BL_RULE_ADD_CT, type: 'input', values: '', default: '', placeholder: 'application/json' },
            field: { name: 'Content-Type (optional)', description: 'Фильтр по content-type ответа.' }
          });
        } catch (_) { }

        // Body match mode
        try {
          Lampa.SettingsApi.addParam({
            component: ctx.componentId,
            param: { name: BL_RULE_ADD_BODY, type: 'input', values: '', default: '', placeholder: 'contains:token' },
            field: { name: 'Body mode (optional)', description: 'Например: contains:token | regex:/.../.' }
          });
        } catch (_) { }
      }

      // Add button
      try {
        Lampa.SettingsApi.addParam({
          component: ctx.componentId,
          param: { name: 'bl_pi_blocklist_add_btn', type: 'button' },
          field: { name: 'Add', description: 'Добавить правило.' },
          onChange: function () {
            try {
              var pat = '';
              try { pat = (window.Lampa && Lampa.Storage && Lampa.Storage.get) ? String(Lampa.Storage.get(BL_RULE_ADD_PATTERN) || '') : ''; } catch (_) { pat = ''; }
              pat = String(pat || '').trim();
              if (!pat) {
                ctx.notify('[[BlackLampa]] Укажите URL / Pattern');
                return;
              }

              var t2 = 'simple';
              try { t2 = (window.Lampa && Lampa.Storage && Lampa.Storage.get) ? String(Lampa.Storage.get(BL_RULE_ADD_TYPE) || 'simple') : 'simple'; } catch (_) { t2 = 'simple'; }
              if (t2 !== 'advanced') t2 = 'simple';

              var rule = { pattern: pat, type: t2, enabled: true };
              if (t2 === 'advanced') {
                var ct = '';
                var bm = '';
                try { ct = (window.Lampa && Lampa.Storage && Lampa.Storage.get) ? String(Lampa.Storage.get(BL_RULE_ADD_CT) || '') : ''; } catch (_) { ct = ''; }
                try { bm = (window.Lampa && Lampa.Storage && Lampa.Storage.get) ? String(Lampa.Storage.get(BL_RULE_ADD_BODY) || '') : ''; } catch (_) { bm = ''; }
                rule.advanced = { contentType: ct, bodyMode: bm };
              }

              var api2 = getBlocklistApi();
              if (api2 && api2.user && typeof api2.user.add === 'function') {
                api2.user.add(rule);
                ctx.notify('[[BlackLampa]] Правило добавлено');
                ctx.go('blocklist_user', null, 0);
              } else {
                ctx.notify('[[BlackLampa]] Network policy missing');
              }
            } catch (_) { }
          }
        });
      } catch (_) { }
    } catch (_) { }
  }

  // ---------------------------------------------------------------------------
  // Route definitions
  // ---------------------------------------------------------------------------
  addRoute({
    id: 'root',
    titleKey: 'menu.root.title',
    build: function (ctx) { buildRootScreen(ctx); }
  });

  addRoute({
    id: 'plugins',
    titleKey: 'menu.plugins.title',
    parent: 'root',
    build: function (ctx) {
      try { if (window.BL && BL.ModuleInstaller && typeof BL.ModuleInstaller.buildPluginsMenuScreen === 'function') return BL.ModuleInstaller.buildPluginsMenuScreen(ctx); } catch (_) { }
      try { Lampa.SettingsApi.addParam({ component: ctx.componentId, param: { name: 'bl_mod_installer_missing', type: 'static', values: 'Installer module missing', default: 'Installer module missing' }, field: { name: 'Plugins', description: 'Installer module missing' } }); } catch (_) { }
    }
  });

  addRoute({
    id: 'managed',
    titleKey: 'menu.plugins.managed',
    parent: 'plugins',
    build: function (ctx) {
      try { if (window.BL && BL.ModuleInstaller && typeof BL.ModuleInstaller.buildManagedScreen === 'function') return BL.ModuleInstaller.buildManagedScreen(ctx); } catch (_) { }
    }
  });

  addRoute({
    id: 'extras',
    titleKey: 'menu.plugins.extras',
    parent: 'plugins',
    build: function (ctx) {
      try { if (window.BL && BL.ModuleInstaller && typeof BL.ModuleInstaller.buildExtrasScreen === 'function') return BL.ModuleInstaller.buildExtrasScreen(ctx); } catch (_) { }
    }
  });

  addRoute({
    id: 'plugin_detail',
    titleKey: 'menu.plugins.detail',
    parent: 'plugins',
    defaultFocus: function (ctx, payload) {
      try { if (window.BL && BL.ModuleInstaller && typeof BL.ModuleInstaller.defaultFocusPluginDetail === 'function') return BL.ModuleInstaller.defaultFocusPluginDetail(ctx, payload || null) || 0; } catch (_) { }
      return 0;
    },
    build: function (ctx) {
      try { if (window.BL && BL.ModuleInstaller && typeof BL.ModuleInstaller.buildPluginDetailScreen === 'function') return BL.ModuleInstaller.buildPluginDetailScreen(ctx); } catch (_) { }
    }
  });

  addRoute({
    id: 'danger',
    titleKey: 'menu.danger.title',
    parent: 'root',
    build: function (ctx) {
      try { if (window.BL && BL.ModuleInstaller && typeof BL.ModuleInstaller.buildDangerScreen === 'function') return BL.ModuleInstaller.buildDangerScreen(ctx); } catch (_) { }
    }
  });

  addRoute({
    id: 'network',
    titleKey: 'menu.network.title',
    parent: 'root',
    build: function (ctx) { buildNetworkMenuScreen(ctx); }
  });

  addRoute({
    id: 'network_status',
    titleKey: 'menu.network.status',
    parent: 'network',
    build: function (ctx) { buildNetworkStatusScreen(ctx); }
  });

  addRoute({
    id: 'blocklist',
    titleKey: 'menu.network.blocklist',
    parent: 'network',
    build: function (ctx) { buildBlocklistScreen(ctx); }
  });

  addRoute({
    id: 'blocklist_builtin',
    titleKey: 'menu.network.blocklist_builtin',
    parent: 'blocklist',
    build: function (ctx) { buildBlocklistBuiltinScreen(ctx); }
  });

  addRoute({
    id: 'blocklist_user',
    titleKey: 'menu.network.blocklist_user',
    parent: 'blocklist',
    build: function (ctx) { buildBlocklistUserRulesScreen(ctx); }
  });

  addRoute({
    id: 'blocklist_user_detail',
    titleKey: 'menu.network.blocklist_user_detail',
    parent: 'blocklist_user',
    build: function (ctx) { buildBlocklistUserRuleDetailScreen(ctx); }
  });

  addRoute({
    id: 'blocklist_add',
    titleKey: 'menu.network.blocklist_add',
    parent: 'blocklist',
    build: function (ctx) { buildBlocklistAddScreen(ctx); }
  });

  addRoute({
    id: 'jsqp',
    titleKey: 'menu.network.jsqp',
    parent: 'network',
    build: function (ctx) { buildJsqpScreen(ctx); }
  });

  addRoute({
    id: 'logs',
    titleKey: 'menu.logs.title',
    parent: 'root',
    build: function (ctx) { buildLogsMenuScreen(ctx); }
  });

  addRoute({
    id: 'logging',
    titleKey: 'menu.logs.logging',
    parent: 'logs',
    build: function (ctx) { buildLoggingScreen(ctx); }
  });

  addRoute({
    id: 'ui',
    titleKey: 'menu.ui.title',
    parent: 'root',
    build: function (ctx) { buildUiScreen(ctx); }
  });

  addRoute({
    id: 'query_params',
    titleKey: 'menu.query_params.title',
    parent: 'root',
    build: function (ctx) { buildQueryParamsScreen(ctx); }
  });

  addRoute({
    id: 'status',
    titleKey: 'menu.status.title',
    parent: 'root',
    build: function (ctx) { buildStatusScreen(ctx); }
  });

  addRoute({
    id: 'ua',
    titleKey: 'menu.ua.title',
    parent: 'root',
    build: function (ctx) { buildUaScreen(ctx); }
  });

  addRoute({
    id: 'ua_presets',
    titleKey: 'menu.ua.presets',
    parent: 'ua',
    build: function (ctx) { buildUaPresetsScreen(ctx); }
  });

  addRoute({
    id: 'ua_effective',
    titleKey: 'menu.ua.effective',
    parent: 'ua',
    build: function (ctx) { buildUaEffectiveScreen(ctx); }
  });

  addRoute({
    id: 'backup',
    titleKey: 'menu.backup.title',
    parent: 'root',
    build: function (ctx) { buildBackupScreen(ctx); }
  });
})();

